/// Pass TMD circuit data to UMAC for TX scheduling
#[derive(Debug)]
pub struct TmdCircuitDataReq {
    // call_id: CallId,
    pub ts: u8,
    pub data: Vec<u8>,
}

/// Rx'ed traffic from UL TCH.
/// `crc_ok` is false when the speech decoder detected a Bad Frame (BFI) —
/// typically because the MS is no longer transmitting or is in a deep fade.
#[derive(Debug)]
pub struct TmdCircuitDataInd {
    // call_id: CallId,
    pub ts: u8,
    pub data: Vec<u8>,
    /// False = Bad Frame Indicator (BFI): CRC failed, likely off-air MS.
    pub crc_ok: bool,
}
