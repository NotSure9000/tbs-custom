use std::collections::HashMap;
use std::panic;

use crate::{MessageQueue, TetraEntityTrait};
use tetra_config::bluestation::SharedConfig;
use tetra_core::tetra_entities::TetraEntity;
use tetra_core::{BitBuffer, Sap, SsiType, TdmaTime, TetraAddress, TxReporter, unimplemented_log};
use tetra_saps::lcmc::enums::alloc_type::ChanAllocType;
use tetra_saps::lcmc::enums::ul_dl_assignment::UlDlAssignment;
use tetra_saps::lcmc::fields::chan_alloc_req::CmceChanAllocReq;
use tetra_saps::tla::{TlaTlDataIndBl, TlaTlUnitdataIndBl};
use tetra_saps::tma::TmaUnitdataReq;
use tetra_saps::{SapMsg, SapMsgInner};

use crate::llc::components::fcs;
use tetra_pdus::llc::enums::llc_pdu_type::LlcPduType;
use tetra_pdus::llc::pdus::bl_ack::BlAck;
use tetra_pdus::llc::pdus::bl_adata::BlAdata;
use tetra_pdus::llc::pdus::bl_data::BlData;
use tetra_pdus::llc::pdus::bl_udata::BlUdata;

/// Struct that maintains state expected acknowledgement data for a transmitted message.
/// Aka, we still expect an ack for this.
pub struct ExpectedInAck {
    pub addr: TetraAddress,
    pub t_start: TdmaTime,
    pub n: u8,
    /// Timeslot on which the original message was received
    pub ts: u8,
    /// Optional TxReporter, used to acknowledge reception by target MS
    pub tx_reporter: Option<TxReporter>,
    // Optional retransmission buffer, to allow for automatic retransmission of the PDU if no acknowledgement is received
    pub retransmission_buf: Option<BitBuffer>,
}

/// Struct that maintains state for an ACK we still need to send back.
pub struct ScheduledOutAck {
    pub addr: TetraAddress,
    pub t_start: TdmaTime,
    pub n: u8,
    /// Timeslot on which the original message was received
    pub ts: u8,
    pub air_interface_encryption: i32,
}

pub struct Llc {
    dltime: TdmaTime,
    config: SharedConfig,
    scheduled_out_acks: Vec<ScheduledOutAck>,
    expected_in_acks: Vec<ExpectedInAck>,

    /// Per-link send sequence variable V(S), keyed by SSI/GSSI address.
    /// Each link starts at 0 and alternates 0,1,0,1,...
    link_send_seq: HashMap<u32, u8>,
}

impl Llc {
    pub fn new(config: SharedConfig) -> Self {
        Self {
            dltime: TdmaTime::default(),
            config,
            // bl_links: BlLinkManager::new(),
            scheduled_out_acks: Vec::new(),
            expected_in_acks: Vec::new(),
            link_send_seq: HashMap::new(),
        }
    }

    /// Schedule an ACK to be sent at a later time
    pub fn schedule_outgoing_ack(&mut self, dltime: TdmaTime, addr: TetraAddress, ns: u8, air_interface_encryption: i32) {
        self.scheduled_out_acks.push(ScheduledOutAck {
            t_start: dltime,
            n: ns,
            addr,
            ts: dltime.t,
            air_interface_encryption,
        });
    }

    /// Returns details for outstanding to-be-sent ACK, if any. Returned u8 is the sequence number
    fn get_out_ack_n_if_any(&mut self, tn: u8, addr: TetraAddress) -> Option<u8> {
        for i in 0..self.scheduled_out_acks.len() {
            if self.scheduled_out_acks[i].t_start.t == tn && self.scheduled_out_acks[i].addr.ssi == addr.ssi {
                let n = self.scheduled_out_acks[i].n;
                self.scheduled_out_acks.remove(i);
                return Some(n);
            }
        }
        None
    }

    /// Returns the next send sequence number V(S) for this link, then toggles it.
    /// Each link independently starts at 0 and alternates 0,1,0,1,...
    fn get_next_send_seq(&mut self, addr: &TetraAddress) -> u8 {
        let vs = self.link_send_seq.entry(addr.ssi).or_insert(0);
        let ns = *vs;
        *vs ^= 1;
        ns
    }

    /// Register that we expect an ACK for this link (acknowledged mode only)
    fn register_expected_ack(&mut self, t: TdmaTime, addr: TetraAddress, n: u8, tx_reporter: Option<TxReporter>) {
        self.expected_in_acks.push(ExpectedInAck {
            t_start: t,
            n,
            addr,
            ts: t.t,
            tx_reporter,
            retransmission_buf: None,
        });
    }

    fn summarize_expected_in_acks_for_ssi(&self, ssi: u32) -> String {
        let mut entries = Vec::new();
        for ack in &self.expected_in_acks {
            if ack.addr.ssi == ssi {
                entries.push(format!("t_start={} ts={} ns={}", ack.t_start, ack.ts, ack.n));
            }
        }
        if entries.is_empty() {
            "none".to_string()
        } else {
            entries.join("; ")
        }
    }

    fn summarize_scheduled_out_acks_for_ssi(&self, ssi: u32) -> String {
        let mut entries = Vec::new();
        for ack in &self.scheduled_out_acks {
            if ack.addr.ssi == ssi {
                entries.push(format!("t_start={} ts={} nr={}", ack.t_start, ack.ts, ack.n));
            }
        }
        if entries.is_empty() {
            "none".to_string()
        } else {
            entries.join("; ")
        }
    }

    /// Process incoming ACK. Remove outstanding ACK expectation. We ignore unexpected ones, might be a retransmission
    fn process_incoming_ack(&mut self, tn: u8, addr: TetraAddress, nr: u8) {
        for i in 0..self.expected_in_acks.len() {
            if self.expected_in_acks[i].t_start.t == tn && self.expected_in_acks[i].addr.ssi == addr.ssi {
                let expected_ns = self.expected_in_acks[i].n;
                let expected_t_start = self.expected_in_acks[i].t_start;
                let pending_expected_total = self.expected_in_acks.len();
                let pending_expected_ssi = self.summarize_expected_in_acks_for_ssi(addr.ssi);
                let pending_out_ssi = self.summarize_scheduled_out_acks_for_ssi(addr.ssi);
                let next_vs = self.link_send_seq.get(&addr.ssi).copied().unwrap_or(0);

                if expected_ns != nr {
                    tracing::warn!(
                        "LLC ACK mismatch: dltime={} ul_tn={} ssi={} got_nr={} expected_ns={} expected_t_start={} pending_expected_total={} pending_expected_ssi=[{}] pending_out_ack_ssi=[{}] next_vs={}",
                        self.dltime,
                        tn,
                        addr.ssi,
                        nr,
                        expected_ns,
                        expected_t_start,
                        pending_expected_total,
                        pending_expected_ssi,
                        pending_out_ssi,
                        next_vs
                    );
                } else {
                    tracing::debug!(
                        "LLC ACK matched: dltime={} ul_tn={} ssi={} nr={} expected_t_start={} pending_expected_total={} pending_expected_ssi=[{}] pending_out_ack_ssi=[{}] next_vs={}",
                        self.dltime,
                        tn,
                        addr.ssi,
                        nr,
                        expected_t_start,
                        pending_expected_total,
                        pending_expected_ssi,
                        pending_out_ssi,
                        next_vs
                    );
                }

                // Remove this expected ACK from the list, and if it has a TxReporter, mark it as acknowledged
                let ack = self.expected_in_acks.remove(i);
                if let Some(tx_reporter) = ack.tx_reporter {
                    tx_reporter.mark_acknowledged();
                }
                return;
            }
        }

        let pending_expected_total = self.expected_in_acks.len();
        let pending_expected_ssi = self.summarize_expected_in_acks_for_ssi(addr.ssi);
        let pending_out_ssi = self.summarize_scheduled_out_acks_for_ssi(addr.ssi);
        let next_vs = self.link_send_seq.get(&addr.ssi).copied().unwrap_or(0);
        tracing::warn!(
            "LLC ACK without outstanding expectation: dltime={} ul_tn={} ssi={} got_nr={} pending_expected_total={} pending_expected_ssi=[{}] pending_out_ack_ssi=[{}] next_vs={}",
            self.dltime,
            tn,
            addr.ssi,
            nr,
            pending_expected_total,
            pending_expected_ssi,
            pending_out_ssi,
            next_vs
        );
    }

    fn rx_tma_prim(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        tracing::trace!("rx_tma_prim");
        match message.msg {
            SapMsgInner::TmaUnitdataInd(_) => {
                self.rx_tma_unitdata_ind(queue, message);
            }
            SapMsgInner::TmaReportInd(_) => {
                self.rx_tma_report_ind(queue, message);
            }
            _ => {
                panic!();
            }
        }
    }

    fn rx_tla_tlunitdata_req_bl(&mut self, _queue: &mut MessageQueue, message: SapMsg) {
        tracing::trace!("rx_tla_tlunitdata_req_bl");
        let SapMsgInner::TlaTlUnitdataReqBl(_prim) = message.msg else {
            panic!()
        };

        unimplemented_log!("rx_tla_tlunitdata_req_bl");
    }

    /// See Clause 22.3.2.3 for Acknowledged data transmission in basic link
    fn rx_tla_tldata_req_bl(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        tracing::trace!("rx_tla_tldata_req_bl");
        let SapMsgInner::TlaTlDataReqBl(mut prim) = message.msg else {
            panic!()
        };

        // Use unacknowledged mode (BL-UDATA) when:
        // 1. STCH (stolen half-slot) — no established LLC link on STCH.
        // 2. GSSI-addressed messages — per ETSI EN 300 392-2, group-addressed
        //    signaling on SCH/F must use BL-UDATA because there is no
        //    established LLC link with individual group members. Using BL-DATA
        //    causes radios (e.g. Sepura) to silently discard frames when the
        //    ns sequence number doesn't match their V(R).
        if prim.stealing_permission || prim.main_address.ssi_type == SsiType::Gssi {
            let mut pdu_buf = BitBuffer::new_autoexpand(32);
            let pdu = BlUdata { has_fcs: false };
            pdu.to_bitbuf(&mut pdu_buf);
            let sdu_len = prim.tl_sdu.get_len_remaining();
            pdu_buf.copy_bits(&mut prim.tl_sdu, sdu_len);
            pdu_buf.seek(0);
            tracing::debug!("-> {:?} sdu {}", pdu, pdu_buf.dump_bin());

            let sapmsg = SapMsg {
                sap: Sap::TmaSap,
                src: self.entity(),
                dest: TetraEntity::Umac,
                dltime: message.dltime,
                msg: SapMsgInner::TmaUnitdataReq(TmaUnitdataReq {
                    req_handle: prim.req_handle,
                    pdu: pdu_buf,
                    main_address: prim.main_address,
                    link_id: prim.link_id,
                    endpoint_id: prim.endpoint_id,
                    stealing_permission: prim.stealing_permission,
                    subscriber_class: prim.subscriber_class,
                    air_interface_encryption: prim.air_interface_encryption,
                    stealing_repeats_flag: prim.stealing_repeats_flag,
                    data_category: prim.data_class_info,
                    chan_alloc: prim.chan_alloc,
                    tx_reporter: prim.tx_reporter.take(),
                }),
            };
            queue.push_back(sapmsg);
            return;
        }

        // If an ack still needs to be sent, get the relevant expected sequence number
        let out_ack_n = self.get_out_ack_n_if_any(message.dltime.t, prim.main_address);

        // Get per-link send sequence number N(S) = V(S), then toggle V(S)
        let ns = self.get_next_send_seq(&prim.main_address);

        // Construct PDU, write header
        let mut pdu_buf = BitBuffer::new_autoexpand(32);

        // Determine message type and build
        if let Some(out_ack_n) = out_ack_n {
            // BL-ADATA (acknowledged, with or without FCS)
            let pdu = BlAdata {
                has_fcs: prim.fcs_flag,
                nr: out_ack_n,
                ns,
            };
            pdu.to_bitbuf(&mut pdu_buf);
            // Append SDU
            let sdu_len = prim.tl_sdu.get_len_remaining();
            pdu_buf.copy_bits(&mut prim.tl_sdu, sdu_len);
            pdu_buf.seek(0);
            tracing::debug!("-> {:?} sdu {}", pdu, pdu_buf.dump_bin());
            // Register that we expect an ACK back (acknowledged mode only)
            self.register_expected_ack(message.dltime, prim.main_address, ns, prim.tx_reporter.clone());
        } else {
            // BL-DATA (unacknowledged, with or without FCS)
            let pdu = BlData {
                has_fcs: prim.fcs_flag,
                ns,
            };
            pdu.to_bitbuf(&mut pdu_buf);
            // Append SDU
            let sdu_len = prim.tl_sdu.get_len_remaining();
            pdu_buf.copy_bits(&mut prim.tl_sdu, sdu_len);
            pdu_buf.seek(0);
            tracing::debug!("-> {:?} sdu {}", pdu, pdu_buf.dump_bin());
            // No ACK expected for unacknowledged BL-DATA
        }

        let sapmsg = SapMsg {
            sap: Sap::TmaSap,
            src: self.entity(),
            dest: TetraEntity::Umac,
            dltime: message.dltime,
            msg: SapMsgInner::TmaUnitdataReq(TmaUnitdataReq {
                req_handle: prim.req_handle,
                pdu: pdu_buf,
                main_address: prim.main_address,
                link_id: prim.link_id,
                endpoint_id: prim.endpoint_id,
                stealing_permission: prim.stealing_permission,
                subscriber_class: prim.subscriber_class,
                air_interface_encryption: prim.air_interface_encryption,
                stealing_repeats_flag: prim.stealing_repeats_flag,
                data_category: prim.data_class_info,
                chan_alloc: prim.chan_alloc,
                tx_reporter: prim.tx_reporter.take(),
            }),
        };
        queue.push_back(sapmsg);
    }

    fn rx_tla_prim(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        tracing::trace!("rx_tla_prim");
        match &message.msg {
            SapMsgInner::TlaTlDataReqBl(_) => {
                self.rx_tla_tldata_req_bl(queue, message);
            }
            SapMsgInner::TlaTlUnitdataReqBl(_) => {
                self.rx_tla_tlunitdata_req_bl(queue, message);
            }
            _ => panic!(),
        }
    }

    fn rx_tma_report_ind(&mut self, _queue: &mut MessageQueue, mut _message: SapMsg) {
        tracing::trace!("rx_tma_report_ind, ignoring");
    }

    /// Clause 20.4.1.1.4 TMA-UNITDATA primitive
    /// TMA-UNITDATA indication: this primitive shall be used by the MAC to deliver a received TM-SDU. This primitive
    /// may also be used with no TM-SDU if the MAC needs to inform the higher layers of a channel allocation received
    /// without an associated TM-SDU.
    fn rx_tma_unitdata_ind(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_tma_unitdata_ind");

        // Determine which type of TL-SDU we have
        let pdu_type = if let SapMsgInner::TmaUnitdataInd(prim) = &mut message.msg {
            let Some(pdu) = prim.pdu.as_ref() else {
                panic!("no pdu");
            };
            let Some(bits) = pdu.peek_bits(4) else {
                tracing::warn!("insufficient bits: {}", pdu.dump_bin());
                return;
            };
            let Ok(pdu_type) = LlcPduType::try_from(bits) else {
                tracing::warn!("invalid pdu type: {} in {}", bits, pdu.dump_bin());
                return;
            };

            pdu_type
        } else {
            panic!();
        };

        // Call handler function
        match pdu_type {
            // All Basic Link types can be handled by the same function
            LlcPduType::BlAdata
            | LlcPduType::BlAdataFcs
            | LlcPduType::BlData
            | LlcPduType::BlDataFcs
            | LlcPduType::BlUdata
            | LlcPduType::BlUdataFcs
            | LlcPduType::BlAck
            | LlcPduType::BlAckFcs => {
                self.rx_tma_unitdata_ind_bl(queue, message);
            }

            LlcPduType::AlSetup
            | LlcPduType::AlDataAlFinal
            | LlcPduType::AlAlUdataAlUfinal
            | LlcPduType::AlAckAlRnr
            | LlcPduType::AlReconnect
            | LlcPduType::AlDisc => {
                unimplemented_log!("LlcPduType Advanced Link: {}", pdu_type);
            }

            _ => {
                panic!();
            }
        }
    }

    fn rx_tma_unitdata_ind_bl(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_tma_unitdata_ind_bl");

        // Get header bits (again) and prepare MLE message
        let SapMsgInner::TmaUnitdataInd(prim) = &mut message.msg else {
            panic!();
        };
        let Some(mut pdu) = prim.pdu.take() else {
            panic!("no pdu");
        };
        let Some(bits) = pdu.peek_bits(4) else {
            tracing::warn!("insufficient bits: {}", pdu.dump_bin());
            return;
        };
        let Ok(pdu_type) = LlcPduType::try_from(bits) else {
            tracing::warn!("invalid pdu type: {} in {}", bits, pdu.dump_bin());
            return;
        };

        let (has_fcs, ns, nr) = match pdu_type {
            LlcPduType::BlAdata | LlcPduType::BlAdataFcs => match BlAdata::from_bitbuf(&mut pdu) {
                Ok(pdu) => {
                    tracing::debug!("<- {:?}", pdu);
                    (pdu.has_fcs, Some(pdu.ns), Some(pdu.nr))
                }
                Err(e) => {
                    tracing::warn!("Failed parsing BlAdata: {:?} {}", e, pdu.dump_bin());
                    return;
                }
            },

            LlcPduType::BlData | LlcPduType::BlDataFcs => match BlData::from_bitbuf(&mut pdu) {
                Ok(pdu) => {
                    tracing::debug!("<- {:?}", pdu);
                    (pdu.has_fcs, Some(pdu.ns), None)
                }
                Err(e) => {
                    tracing::warn!("Failed parsing BlData: {:?} {}", e, pdu.dump_bin());
                    return;
                }
            },
            LlcPduType::BlAck | LlcPduType::BlAckFcs => match BlAck::from_bitbuf(&mut pdu) {
                Ok(pdu) => {
                    tracing::debug!("<- {:?}", pdu);
                    (pdu.has_fcs, None, Some(pdu.nr))
                }
                Err(e) => {
                    tracing::warn!("Failed parsing BlAck: {:?} {}", e, pdu.dump_bin());
                    return;
                }
            },
            LlcPduType::BlUdata | LlcPduType::BlUdataFcs => match BlUdata::from_bitbuf(&mut pdu) {
                Ok(pdu) => {
                    tracing::debug!("<- {:?}", pdu);
                    (pdu.has_fcs, None, None)
                }
                Err(e) => {
                    tracing::warn!("Failed parsing BlUdata: {:?} {}", e, pdu.dump_bin());
                    return;
                }
            },
            _ => {
                panic!();
            }
        };

        // If FCS is present, check it. If wrong, we bail here
        if has_fcs && !fcs::check_fcs(&pdu) {
            tracing::warn!("FCS check failed");
            return;
        }

        // If ns is present, we need to send an ACK
        if let Some(ns) = ns {
            // Send ACK
            self.schedule_outgoing_ack(message.dltime, prim.main_address, ns, prim.air_interface_encryption);
        }

        // if nr is present, we have received an ACK on a previous message
        if let Some(nr) = nr {
            // let ul_time = message.dltime.add_timeslots(-2);
            self.process_incoming_ack(message.dltime.t, prim.main_address, nr);
        }

        if pdu_type == LlcPduType::BlAck || pdu_type == LlcPduType::BlAckFcs {
            // No need to do anything further
            // TODO FIXME: flag sent sdu as acked
            return;
        }

        // If unacknowledged data transfer service, we send a TL-UNITDATA indication
        // to MLE. If acknowledged data transfer service, we send a TL-DATA indication

        pdu.set_raw_start(pdu.get_raw_pos());
        // tracing::info!("got sdu: {:}", sdu.dump_bin());
        let s = if pdu_type == LlcPduType::BlUdata || pdu_type == LlcPduType::BlUdataFcs {
            // Unacknowledged data transfer service
            let m = TlaTlUnitdataIndBl {
                // address_type: 0, // TODO FIXME
                main_address: prim.main_address,
                link_id: message.dltime.add_timeslots(-2).t as u32,
                endpoint_id: prim.endpoint_id,
                new_endpoint_id: prim.new_endpoint_id,
                css_endpoint_id: prim.css_endpoint_id,
                tl_sdu: if pdu.get_len_remaining() > 0 { Some(pdu) } else { None },
                scrambling_code: prim.scrambling_code,
                fcs_flag: has_fcs,
                air_interface_encryption: prim.air_interface_encryption,
                chan_change_resp_req: prim.chan_change_response_req,
                chan_change_handle: prim.chan_change_handle,
                chan_info: prim.chan_info,
                report: None, // TODO FIXME
            };
            SapMsg {
                sap: Sap::TlaSap,
                src: TetraEntity::Llc,
                dest: TetraEntity::Mle,
                dltime: message.dltime,
                msg: SapMsgInner::TlaTlUnitdataIndBl(m),
            }
        } else {
            // Acknowledged data transfer service
            let m = TlaTlDataIndBl {
                // address_type: 0, // TODO FIXME
                main_address: prim.main_address,
                link_id: message.dltime.add_timeslots(-2).t as u32,
                endpoint_id: prim.endpoint_id,
                new_endpoint_id: prim.new_endpoint_id,
                css_endpoint_id: prim.css_endpoint_id,
                tl_sdu: if pdu.get_len_remaining() > 0 { Some(pdu) } else { None },
                scrambling_code: prim.scrambling_code,
                fcs_flag: has_fcs,
                air_interface_encryption: prim.air_interface_encryption,
                chan_change_resp_req: prim.chan_change_response_req,
                chan_change_handle: prim.chan_change_handle,
                chan_info: prim.chan_info,
                req_handle: 0, // TODO FIXME
            };
            SapMsg {
                sap: Sap::TlaSap,
                src: TetraEntity::Llc,
                dest: TetraEntity::Mle,
                dltime: message.dltime,
                msg: SapMsgInner::TlaTlDataIndBl(m),
            }
        };

        queue.push_back(s);
    }

    fn format_expected_ack_list(ack_list: &Vec<ExpectedInAck>) -> String {
        let mut ret = String::new();
        ret.push_str("Expected in acks:\n");
        for ack in ack_list {
            ret.push_str(&format!("  t: {}, ssi: {}, n: {}\n", ack.t_start.t, ack.addr.ssi, ack.n));
        }
        ret
    }

    fn format_scheduled_ack_list(ack_list: &Vec<ScheduledOutAck>) -> String {
        let mut ret = String::new();
        ret.push_str("Scheduled out acks:\n");
        for ack in ack_list {
            ret.push_str(&format!("  t: {}, ssi: {}, n: {}\n", ack.t_start.t, ack.addr.ssi, ack.n));
        }
        ret
    }
}

impl TetraEntityTrait for Llc {
    fn entity(&self) -> TetraEntity {
        TetraEntity::Llc
    }

    fn set_config(&mut self, config: SharedConfig) {
        self.config = config;
    }

    fn rx_prim(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        tracing::debug!("rx_prim: {:?}", message);
        // tracing::debug!(ts=%message.dltime, "rx_prim: {:?}", message);

        match message.sap {
            Sap::TmaSap => {
                self.rx_tma_prim(queue, message);
            }

            // TMB-SAP and TMC-SAP are skipped and passed straight between MAC and MLE
            Sap::TlaSap => {
                self.rx_tla_prim(queue, message);
            }
            _ => panic!(),
        }
    }

    fn tick_start(&mut self, _queue: &mut MessageQueue, ts: TdmaTime) {
        self.dltime = ts;
    }

    fn tick_end(&mut self, queue: &mut MessageQueue, _ts: TdmaTime) -> bool {
        // Check if any unsent ACKs are still here
        // Take oldest element from scheduled_out_acks, and remove it from the list
        let ret = !self.scheduled_out_acks.is_empty();
        while let Some(ack) = self.scheduled_out_acks.first() {
            tracing::debug!("tick_end: auto-ack for ssi: {}, n: {}, ts: {}", ack.addr.ssi, ack.n, ack.ts);

            // Send BL-ACK via FACCH (stealing) on the traffic timeslot if the original
            // message arrived on a traffic channel (TS2-4), otherwise via MCCH (TS1).
            let steal = matches!(ack.ts, 2..=4);
            let mut pdu_buf = BitBuffer::new_autoexpand(5);
            let pdu = BlAck { has_fcs: false, nr: ack.n };
            pdu.to_bitbuf(&mut pdu_buf);
            pdu_buf.seek(0);
            tracing::debug!("-> {:?} {}", pdu, pdu_buf.dump_bin());

            // We're sending an ACK for a received uplink message, however, we don't have that message here
            // Since DL is two slots ahead of UL, we will correct that. We now have the dltime for reception
            // of the original message.
            let dltime = self.dltime.add_timeslots(-2);
            let chan_alloc = match steal {
                true => {
                    let mut timeslots = [false; 4];
                    timeslots[(ack.ts - 1) as usize] = true;
                    Some(CmceChanAllocReq {
                        usage: None,
                        timeslots,
                        alloc_type: ChanAllocType::Replace,
                        ul_dl_assigned: UlDlAssignment::Both,
                        carrier: None,
                    })
                }
                false => None,
            };
            let sapmsg = SapMsg {
                sap: Sap::TmaSap,
                src: TetraEntity::Llc,
                dest: TetraEntity::Umac,
                dltime,
                msg: SapMsgInner::TmaUnitdataReq(TmaUnitdataReq {
                    req_handle: 0, // TODO FIXME
                    pdu: pdu_buf,
                    main_address: ack.addr,
                    link_id: 0,
                    // scrambling_code: self.config.config().scrambling_code(),
                    endpoint_id: 0, // todo fixme
                    stealing_permission: steal,
                    subscriber_class: 0,            // TODO FIXME
                    air_interface_encryption: if ack.air_interface_encryption > 0 {
                        Some(ack.air_interface_encryption)
                    } else {
                        None
                    },
                    stealing_repeats_flag: None,    // TODO FIXME
                    data_category: None,            // TODO FIXME
                    chan_alloc,
                    tx_reporter: None, // By definition, no higher layer entity is interested
                }),
            };
            queue.push_back(sapmsg);
            self.scheduled_out_acks.remove(0);
        }

        ret
    }
}
