Logo colour: #265396

Logo may still be slightly updated, not a guaranteed final version