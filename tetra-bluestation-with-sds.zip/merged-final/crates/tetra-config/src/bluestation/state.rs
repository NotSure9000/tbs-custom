use tetra_core::TimeslotAllocator;

/// Mutable, stack-editable state (mutex-protected).
#[derive(Debug, Clone)]
pub struct StackState {
    pub timeslot_alloc: TimeslotAllocator,
    /// Backhaul/network connection to SwMI (e.g., Brew/TetraPack). False -> fallback mode.
    pub network_connected: bool,
    /// Cell load indicator (2-bit, 0 = info unavailable). Broadcast in D-NWRK-BROADCAST.
    pub cell_load_ca: u8,
}

impl Default for StackState {
    fn default() -> Self {
        Self {
            timeslot_alloc: TimeslotAllocator::default(),
            network_connected: false,
            cell_load_ca: 0,
        }
    }
}
