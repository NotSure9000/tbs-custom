use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};

use crate::{EndpointId, LinkId, MleHandle};

/// Routing entry for a registered MS: enough to address a downlink LcmcMleUnitdataReq to it.
#[derive(Debug, Clone, Copy)]
pub struct MsRouteEntry {
    pub handle: MleHandle,
    pub link_id: LinkId,
    pub endpoint_id: EndpointId,
}

static REGISTRY: OnceLock<Mutex<HashMap<u32, MsRouteEntry>>> = OnceLock::new();

fn registry() -> &'static Mutex<HashMap<u32, MsRouteEntry>> {
    REGISTRY.get_or_init(|| Mutex::new(HashMap::new()))
}

/// Register (or refresh) the route for an SSI.
/// Called by MM when a D-LOCATION-UPDATE-ACCEPT is sent.
pub fn register(ssi: u32, entry: MsRouteEntry) {
    let mut map = registry().lock().unwrap();
    tracing::debug!("MsRouteRegistry: register ssi={} {:?}", ssi, entry);
    map.insert(ssi, entry);
}

/// Remove a registered MS (deregistration / ITSI detach).
pub fn deregister(ssi: u32) {
    let mut map = registry().lock().unwrap();
    if map.remove(&ssi).is_some() {
        tracing::debug!("MsRouteRegistry: deregister ssi={}", ssi);
    }
}

/// Look up a route. Returns `None` if the MS is not currently registered.
pub fn get(ssi: u32) -> Option<MsRouteEntry> {
    registry().lock().unwrap().get(&ssi).copied()
}
