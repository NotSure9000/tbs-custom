/// ETSI EN 300 392-7 A.8.6 Authentication sub-type
/// Bits: 2
/// 00 = Demand, 01 = Result, 10 = Reject, 11 = Response
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum AuthenticationSubType {
    Demand = 0,
    Result = 1,
    Reject = 2,
    Response = 3,
}

impl std::convert::TryFrom<u64> for AuthenticationSubType {
    type Error = ();

    fn try_from(x: u64) -> Result<Self, Self::Error> {
        match x {
            0 => Ok(AuthenticationSubType::Demand),
            1 => Ok(AuthenticationSubType::Result),
            2 => Ok(AuthenticationSubType::Reject),
            3 => Ok(AuthenticationSubType::Response),
            _ => Err(()),
        }
    }
}

impl AuthenticationSubType {
    pub fn into_raw(self) -> u64 {
        match self {
            AuthenticationSubType::Demand => 0,
            AuthenticationSubType::Result => 1,
            AuthenticationSubType::Reject => 2,
            AuthenticationSubType::Response => 3,
        }
    }
}

impl From<AuthenticationSubType> for u64 {
    fn from(e: AuthenticationSubType) -> Self {
        e.into_raw()
    }
}

impl core::fmt::Display for AuthenticationSubType {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            AuthenticationSubType::Demand => write!(f, "Demand"),
            AuthenticationSubType::Response => write!(f, "Response"),
            AuthenticationSubType::Result => write!(f, "Result"),
            AuthenticationSubType::Reject => write!(f, "Reject"),
        }
    }
}
