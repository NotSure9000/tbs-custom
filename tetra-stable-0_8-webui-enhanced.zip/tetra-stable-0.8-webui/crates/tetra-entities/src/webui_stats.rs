use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

use serde::Serialize;

/// Status of a provisioned MS (radio)
#[derive(Clone, Debug, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum MsStatus {
    /// Not registered on the network
    Offline,
    /// Registered and idle
    Online,
    /// Currently in a call (group or individual)
    OnCall,
    /// Authentication or other error state
    Error,
}

impl Default for MsStatus {
    fn default() -> Self {
        MsStatus::Offline
    }
}

/// A provisioned radio with ISSI and key presence indicator
#[derive(Clone, Debug, Default, Serialize)]
pub struct ProvisionedRadio {
    pub issi: u32,
    pub has_key: bool,
    pub status: MsStatus,
}

/// A single call log entry
#[derive(Clone, Debug, Serialize)]
pub struct CallLogEntry {
    pub timestamp_unix_ms: u64,
    pub entry_type: String,  // "group_call_start", "group_call_end", "individual_call_start", "individual_call_end", "sds"
    pub from_issi: u32,
    pub to_issi_or_gssi: u32,
    pub call_type: String,   // "group", "individual", "sds"
    pub duration_ms: Option<u64>,
    pub is_live: bool,
    pub gssi: Option<u32>,   // For group calls, the GSSI
    pub call_id: Option<u64>, // Internal call id for tracking live calls
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiStatsSnapshot {
    pub registered_issi_count: u64,
    pub registered_issis: Vec<u32>,
    pub affiliated_group_links: u64,
    pub groups_with_listeners: u64,
    pub active_group_calls: u64,
    pub active_individual_calls: u64,
    pub total_group_call_setups: u64,
    pub total_individual_call_setups: u64,
    pub updated_unix_ms: u64,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiExtendedSnapshot {
    /// All provisioned radios (from config ISSI-K pairs) with live status
    pub provisioned_radios: Vec<ProvisionedRadio>,
    /// Recent call and SDS log (newest first, capped at 200 entries)
    pub call_log: Vec<CallLogEntry>,
    /// GSSIs that currently have at least one listener
    pub active_talkgroups: Vec<u32>,
    /// Number of SDS messages sent (downlink)
    pub sds_sent: u64,
    /// Number of SDS messages delivered (delivery report received)
    pub sds_delivered: u64,
    pub updated_unix_ms: u64,
}

#[derive(Default)]
struct WebUiStatsState {
    snapshot: WebUiStatsSnapshot,
    extended: WebUiExtendedSnapshot,
}

fn state() -> &'static Mutex<WebUiStatsState> {
    static STATE: OnceLock<Mutex<WebUiStatsState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(WebUiStatsState::default()))
}

fn now_unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

pub fn reset() {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        s.snapshot = WebUiStatsSnapshot {
            updated_unix_ms: now,
            ..WebUiStatsSnapshot::default()
        };
        // Preserve provisioned radios list but reset all statuses to Offline.
        // The list comes from config and must not be erased by stack re-init.
        for radio in s.extended.provisioned_radios.iter_mut() {
            radio.status = MsStatus::Offline;
        }
        let preserved_radios = std::mem::take(&mut s.extended.provisioned_radios);
        s.extended = WebUiExtendedSnapshot {
            updated_unix_ms: now,
            provisioned_radios: preserved_radios,
            ..WebUiExtendedSnapshot::default()
        };
    }
}

/// Set the provisioned radios list (called once at startup or on config reload).
/// `radios` is a vec of (issi, has_key) pairs.
pub fn set_provisioned_radios(radios: Vec<(u32, bool)>) {
    if let Ok(mut s) = state().lock() {
        // Preserve existing statuses
        let old_statuses: HashMap<u32, MsStatus> = s.extended.provisioned_radios
            .iter()
            .map(|r| (r.issi, r.status.clone()))
            .collect();
        s.extended.provisioned_radios = radios.into_iter().map(|(issi, has_key)| {
            ProvisionedRadio {
                issi,
                has_key,
                status: old_statuses.get(&issi).cloned().unwrap_or(MsStatus::Offline),
            }
        }).collect();
        s.extended.provisioned_radios.sort_by_key(|r| r.issi);
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Update the status of a single MS
pub fn set_ms_status(issi: u32, status: MsStatus) {
    if let Ok(mut s) = state().lock() {
        if let Some(radio) = s.extended.provisioned_radios.iter_mut().find(|r| r.issi == issi) {
            radio.status = status;
            s.extended.updated_unix_ms = now_unix_ms();
        }
    }
}

/// Append a call log entry. The log is capped at 200 entries (oldest removed).
pub fn append_call_log(entry: CallLogEntry) {
    if let Ok(mut s) = state().lock() {
        s.extended.call_log.insert(0, entry);
        if s.extended.call_log.len() > 200 {
            s.extended.call_log.truncate(200);
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Mark a live call as ended: find by call_id, set duration and clear live flag.
pub fn finalize_call_log(call_id: u64, ended_at_unix_ms: u64) {
    if let Ok(mut s) = state().lock() {
        for entry in s.extended.call_log.iter_mut() {
            if entry.call_id == Some(call_id) && entry.is_live {
                entry.is_live = false;
                entry.duration_ms = Some(ended_at_unix_ms.saturating_sub(entry.timestamp_unix_ms));
                break;
            }
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Update the active talkgroups list
pub fn set_active_talkgroups(mut gssis: Vec<u32>) {
    gssis.sort_unstable();
    gssis.dedup();
    if let Ok(mut s) = state().lock() {
        s.extended.active_talkgroups = gssis;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Increment the SDS sent counter
pub fn inc_sds_sent() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_sent += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Increment the SDS delivered counter
pub fn inc_sds_delivered() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_delivered += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

#[allow(clippy::too_many_arguments)]
pub fn publish(
    mut registered_issis: Vec<u32>,
    affiliated_group_links: usize,
    groups_with_listeners: usize,
    active_group_calls: usize,
    active_individual_calls: usize,
    total_group_call_setups: u64,
    total_individual_call_setups: u64,
) {
    registered_issis.sort_unstable();
    registered_issis.dedup();

    let snapshot = WebUiStatsSnapshot {
        registered_issi_count: registered_issis.len() as u64,
        registered_issis,
        affiliated_group_links: affiliated_group_links as u64,
        groups_with_listeners: groups_with_listeners as u64,
        active_group_calls: active_group_calls as u64,
        active_individual_calls: active_individual_calls as u64,
        total_group_call_setups,
        total_individual_call_setups,
        updated_unix_ms: now_unix_ms(),
    };

    if let Ok(mut s) = state().lock() {
        s.snapshot = snapshot;
    }
}

pub fn snapshot() -> WebUiStatsSnapshot {
    if let Ok(s) = state().lock() {
        return s.snapshot.clone();
    }
    WebUiStatsSnapshot {
        updated_unix_ms: now_unix_ms(),
        ..WebUiStatsSnapshot::default()
    }
}

pub fn snapshot_json() -> String {
    match serde_json::to_string(&snapshot()) {
        Ok(s) => s,
        Err(_) => "{}".to_string(),
    }
}

pub fn extended_snapshot() -> WebUiExtendedSnapshot {
    if let Ok(s) = state().lock() {
        return s.extended.clone();
    }
    WebUiExtendedSnapshot {
        updated_unix_ms: now_unix_ms(),
        ..WebUiExtendedSnapshot::default()
    }
}

pub fn extended_snapshot_json() -> String {
    match serde_json::to_string(&extended_snapshot()) {
        Ok(s) => s,
        Err(_) => "{}".to_string(),
    }
}
