use crate::MessageQueue;
use crate::webui_stats;
use std::collections::HashMap;
use std::time::{Duration, Instant};
use tetra_config::bluestation::SharedConfig;
use tetra_core::tetra_entities::TetraEntity;
use tetra_core::{BitBuffer, Sap, TdmaTime, TetraAddress, address::SsiType, unimplemented_log};
use tetra_pdus::cmce::{enums::cmce_pdu_type_ul::CmcePduTypeUl, pdus::d_sds_data::DSdsData, pdus::u_sds_data::USdsData};
use tetra_saps::lcmc::LcmcMleUnitdataReq;
use tetra_saps::{SapMsg, SapMsgInner};

// Local-only SDS delivery support for LST-like operation.
//
// In many terminals, delivery reports (PID=0x04) are addressed to SwMI rather than the
// originating MS. When we operate without backhaul, we must locally re-route those
// reports to the origin.
const PID04_REPORT_TIMEOUT: Duration = Duration::from_secs(8);

fn sds_pid04_key(dest_ssi: u32, mr: u8) -> u64 {
    ((dest_ssi as u64) << 8) | (mr as u64)
}

fn pid04_msg_type(payload: &[u8]) -> Option<u8> {
    payload.get(1).map(|b| (b & 0xF0) >> 4)
}

fn is_pid04_status_pdu(payload: &[u8]) -> bool {
    payload.len() >= 4 && payload.first().copied() == Some(0x04) && matches!(pid04_msg_type(payload), Some(1) | Some(2))
}

fn parse_pid04_status(payload: &[u8]) -> Option<(u8, u8, u8)> {
    // Returns (msg_type, status, mr)
    if payload.len() < 4 || payload[0] != 0x04 {
        return None;
    }
    let mt = pid04_msg_type(payload)?;
    if mt != 1 && mt != 2 {
        return None;
    }
    Some((mt, payload[2], payload[3]))
}

// Data observed: 04 <ctrl> <mr> ...
fn parse_pid04_mr_from_data(payload: &[u8]) -> Option<u8> {
    if payload.len() >= 3 && payload[0] == 0x04 {
        if is_pid04_status_pdu(payload) {
            return None;
        }
        return Some(payload[2]);
    }
    None
}

fn build_pid04_report(mr: u8, status: u8) -> [u8; 4] {
    [0x04, 0x10, status, mr]
}

fn build_pid04_ack(mr: u8, status: u8) -> [u8; 4] {
    [0x04, 0x20, status, mr]
}

// ─── Minimal SDS‑TL helpers (practical interop) ───────────────────

fn sds_tl_msg_type(payload: &[u8]) -> Option<u8> {
    payload.get(1).map(|b| (b & 0xF0) >> 4)
}

fn parse_sds_tl_transfer_pid_mr(payload: &[u8]) -> Option<(u8, u8)> {
    if payload.len() < 3 {
        return None;
    }
    if sds_tl_msg_type(payload) != Some(0) {
        return None;
    }
    let pid = payload[0];
    let mr = payload[2];
    Some((pid, mr))
}

fn build_sds_tl_ack(pid: u8, status: u8, mr: u8) -> [u8; 4] {
    [pid, 0x20, status, mr]
}

#[derive(Debug, Clone)]
struct PendingSdsPid04Route {
    origin_ssi: u32,
    mr: u8,
    since: Instant,
}

/// Clause 13 Short Data Service CMCE sub-entity (BS side)
///
/// BS primarily receives **U-SDS-DATA** on the air interface and forwards the
/// SDS Type-4 payload (including PID octet) to Brew/Core.
///
/// NOTE: We DO NOT rewrite SDS-TL Message Reference (MR). MR is used end-to-end
/// (e.g. delivery reports) and must be preserved per ETSI.
pub struct SdsBsSubentity {
    config: SharedConfig,
    pending_pid04_reports: HashMap<u64, PendingSdsPid04Route>,
    next_sds_dl_ts1: Option<TdmaTime>,
    /// Current TDMA time, updated each tick so send_from_bs has a valid base time
    dltime: TdmaTime,
}

impl SdsBsSubentity {
    pub fn new(config: SharedConfig) -> Self {
        Self {
            config,
            pending_pid04_reports: HashMap::new(),
            next_sds_dl_ts1: None,
            dltime: TdmaTime::default(),
        }
    }

    pub fn set_config(&mut self, config: SharedConfig) {
        self.config = config;
    }

    /// Update current TDMA time. Called from CmceBs::tick_start.
    pub fn set_dltime(&mut self, ts: TdmaTime) {
        self.dltime = ts;
    }

    /// Send a plain-text SDS from the dashboard. Encodes the text as UTF-8 bytes,
    /// prepends an SDS-TL Transfer PDU header (EN 300 392-2 §29, SDTI=0x0A, MT=0,
    /// delivery-report-request=0, store-and-forward=0), and wraps the result in a
    /// D-SDS-DATA Type-4 PDU addressed to `to_issi`, with `from_issi` as the
    /// calling party. Also logs to the activity log.
    ///
    /// Without the SDS-TL header the radio terminal cannot identify the message as
    /// a user-text SDS and silently discards it.
    pub fn send_from_bs(&mut self, queue: &mut MessageQueue, from_issi: u32, to_issi: u32, text: &str) {
        let text_bytes = text.as_bytes();
        let dest = tetra_core::TetraAddress::new(to_issi, tetra_core::address::SsiType::Ssi);

        tracing::info!("SDS from dashboard: {} -> {} \"{}\"", from_issi, to_issi, text);

        // Build SDS-TL Transfer PDU header (4 bytes):
        //   Byte 0: Protocol Identifier = 0x0A  (SDS-TL text, per EN 300 392-2 §29.4)
        //   Byte 1: [7:4] Message Type = 0 (TRANSFER), [3] delivery-report-req = 0,
        //           [2] store-and-fwd = 0, [1:0] validity period = 0 (not used)
        //   Byte 2: Message Reference (MR) — use a simple rolling counter
        //   Byte 3: [7:4] Character set = 0 (8-bit ASCII/ISO-8859-1),
        //           [3:0] high nibble of text length in characters
        // Then append the text bytes directly.
        //
        // Practically: PID=0x0A, ctrl=0x00, MR=(rolling), charset/len header, text.
        let mr = {
            // Simple per-instance rolling MR (1–255, wrap to 1)
            static MR_COUNTER: std::sync::atomic::AtomicU8 =
                std::sync::atomic::AtomicU8::new(1);
            let v = MR_COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            if v == 0 { MR_COUNTER.store(1, std::sync::atomic::Ordering::Relaxed); 1u8 } else { v }
        };
        // SDS-TL header: PID | ctrl | MR
        // Followed by text length (in characters, 16-bit big-endian) then the text.
        let text_len = text_bytes.len() as u16;
        let mut payload: Vec<u8> = Vec::with_capacity(5 + text_bytes.len());
        payload.push(0x0A);          // PID = Text (SDS-TL)
        payload.push(0x00);          // MT=TRANSFER, no delivery report, no S&F
        payload.push(mr);            // Message Reference
        payload.push((text_len >> 8) as u8);  // text length high byte
        payload.push(text_len as u8);         // text length low byte
        payload.extend_from_slice(text_bytes);

        let bit_len = (payload.len() * 8) as u16;

        self.send_dsds_type4(queue, self.dltime, dest, from_issi, bit_len, payload, false, true);

        webui_stats::inc_sds_sent();
        webui_stats::inc_sds_delivered();

        let now_ms = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0);
        webui_stats::append_call_log(webui_stats::CallLogEntry {
            timestamp_unix_ms: now_ms,
            entry_type: "sds".to_string(),
            from_issi,
            to_issi_or_gssi: to_issi,
            call_type: "sds".to_string(),
            duration_ms: None,
            is_live: false,
            gssi: None,
            call_id: None,
        });
    }



    fn should_handle_locally(&self, _dst_ssi: u32) -> bool {
        true
    }


    fn reserve_sds_dl_ts1(&mut self, base: TdmaTime) -> TdmaTime {
        let candidate = base.forward_to_timeslot(1);
        let next = match self.next_sds_dl_ts1 {
            None => candidate,
            Some(cur) => {
                if cur.to_int() < candidate.to_int() {
                    candidate
                } else {
                    cur
                }
            }
        };
        self.next_sds_dl_ts1 = Some(next.add_timeslots(4));
        next
    }

    fn expire_pid04_routes(&mut self) {
        let now = Instant::now();
        let mut expired = Vec::new();
        for (k, v) in self.pending_pid04_reports.iter() {
            if now.duration_since(v.since) > PID04_REPORT_TIMEOUT {
                expired.push(*k);
            }
        }
        for k in expired {
            self.pending_pid04_reports.remove(&k);
        }
    }

    /// `use_udata`: when true, sets `stealing_permission = true` so the LLC layer
    /// uses BL-UDATA (unacknowledged) instead of BL-DATA (acknowledged with N(S)).
    /// Required for BS-originated SDS: there is no established LLC link, so the MS
    /// has no synchronized V(R) and will silently discard acknowledged frames whose
    /// N(S) doesn't match.  BL-UDATA avoids this entirely.
    /// In UMAC, `stealing_permission` with no active traffic circuit falls back to
    /// the normal MCCH path, so this does not cause unwanted FACCH stealing.
    fn push_cmce_unitdata_req(&mut self, queue: &mut MessageQueue, base_time: TdmaTime, address: TetraAddress, mut sdu: BitBuffer, repeats: bool, use_udata: bool) {
        sdu.seek(0);
        queue.push_back(SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: self.reserve_sds_dl_ts1(base_time),
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: 0,
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: use_udata,
                stealing_repeats_flag: repeats,
                chan_alloc: None,
                main_address: address,
                tx_reporter: None,
            }),
        });
    }

    fn send_dsds_type4(&mut self, queue: &mut MessageQueue, base_time: TdmaTime, dest: TetraAddress, sender_ssi: u32, bit_len: u16, payload: Vec<u8>, repeats: bool, use_udata: bool) {
        let pdu = DSdsData {
            calling_party_type_identifier: 1,
            calling_party_address_ssi: Some(sender_ssi as u64),
            calling_party_extension: None,
            short_data_type_identifier: 3,
            user_defined_data_1: None,
            user_defined_data_2: None,
            user_defined_data_3: None,
            length_indicator: Some(bit_len),
            user_defined_data_4: Some(payload),
            external_subscriber_number: None,
            dm_ms_address: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(64 + (bit_len as usize));
        if let Err(e) = pdu.to_bitbuf(&mut sdu) {
            tracing::warn!("SDS local relay: DSdsData encode failed: {:?}", e);
            return;
        }

        self.push_cmce_unitdata_req(queue, base_time, dest, sdu, repeats, use_udata);
    }
    fn rx_u_sds_data(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_sds_data");

        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!();
        };

        let pdu = match USdsData::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => pdu,
            Err(e) => {
                tracing::warn!("Failed parsing USdsData: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // We currently forward only Type-4 (SDTI=3) since it carries a variable-length payload.
        if pdu.short_data_type_identifier != 3 {
            tracing::debug!("USdsData sdti={} (not type-4); ignoring", pdu.short_data_type_identifier);
            return;
        }

        let Some(bit_len) = pdu.length_indicator else {
            tracing::warn!("USdsData type-4 missing length_indicator");
            return;
        };
        let Some(payload) = pdu.user_defined_data_4 else {
            tracing::warn!("USdsData type-4 missing user_defined_data_4");
            return;
        };

        // Destination SSI
        let (dst_ssi, dst_type) = if let Some(ssi) = pdu.called_party_ssi {
            (ssi as u32, SsiType::Ssi)
        } else if let Some(short) = pdu.called_party_short_number_address {
            (short as u32, SsiType::Unknown)
        } else {
            tracing::warn!("USdsData missing called_party address");
            return;
        };

        let src_addr = prim.received_tetra_address;
        let src_ssi = src_addr.ssi;
        let dst_addr = tetra_core::TetraAddress::new(dst_ssi, dst_type);

        self.expire_pid04_routes();

        let local = self.should_handle_locally(dst_ssi);

        tracing::info!(
            "SDS RX head: from={} dst={} local={} head={:02x?}",
            src_addr,
            dst_addr,
            local,
            payload.get(0..payload.len().min(8)).unwrap_or(&[])
        );
        // Interop: do not synthesize SDS-TL REPORTs here.
        // Many terminals accept only the destination-generated SDS-REPORT.
        // We relay destination reports end-to-end in BrewEntity.
        if local {
            // Local/LST handling: relay to destination (if applicable) and perform minimal
            // delivery report re-routing (PID=0x04) when terminals address status to SwMI.

            // 1) PID=0x04 status from destination → synthesize downlink report to origin.
            if let Some((mt, status, mr)) = parse_pid04_status(&payload) {
                let key = sds_pid04_key(src_ssi, mr);
                if let Some(route) = self.pending_pid04_reports.remove(&key) {
                    let out = match mt {
                        2 => build_pid04_ack(mr, status),
                        _ => build_pid04_report(mr, status),
                    };
                    tracing::info!(
                        "SDS PID04 {} from={} mr=0x{:02x} status=0x{:02x} -> origin={}",
                        if mt == 2 { "ACK" } else { "REPORT" },
                        src_ssi,
                        mr,
                        status,
                        route.origin_ssi
                    );
                    // Delivery already counted at relay time; no double-count here.
                    self.send_dsds_type4(
                        queue,
                        message.dltime,
                        TetraAddress::new(route.origin_ssi, SsiType::Ssi),
                        src_ssi,
                        32,
                        out.to_vec(),
                        true,
                        false,
                    );
                } else {
                    tracing::debug!(
                        "SDS PID04 status from={} mr=0x{:02x} had no pending route (dropping)",
                        src_ssi,
                        mr
                    );
                }
                return;
            }

            let can_relay = dst_type == SsiType::Ssi && dst_ssi != src_ssi;

            // 2) Remember origin for PID=0x04 user data (needed for later REPORT/ACK).
            // Only meaningful for locally-routed MS↔MS SDS.
            if can_relay {
                if let Some(mr) = parse_pid04_mr_from_data(&payload) {
                    let key = sds_pid04_key(dst_ssi, mr);
                    self.pending_pid04_reports.insert(
                        key,
                        PendingSdsPid04Route {
                            origin_ssi: src_ssi,
                            mr,
                            since: Instant::now(),
                        },
                    );
                }
            }

            // 3) Many terminals require an SDS‑TL ACK to clear the sender UI.
            // Only send this for locally-routed MS↔MS SDS to avoid MCCH/TS1 flooding in LST.
            if can_relay {
                if let Some((pid, mr)) = parse_sds_tl_transfer_pid_mr(&payload) {
                    let ack = build_sds_tl_ack(pid, 0x00, mr);
                    self.send_dsds_type4(
                        queue,
                        message.dltime,
                        TetraAddress::new(src_ssi, SsiType::Ssi),
                        dst_ssi,
                        32,
                        ack.to_vec(),
                        true,
                        false,
                    );
                }
            }

            // 4) Relay actual payload downlink to destination SSI.
            if can_relay {
                webui_stats::inc_sds_sent();
                // The SDS-TL ACK sent to the sender in step 3 constitutes the delivery
                // confirmation from the BS's perspective — the message is committed to
                // the downlink queue. Count it as delivered here.
                webui_stats::inc_sds_delivered();
                // Also append to call log as SDS activity
                {
                    let now_ms = std::time::SystemTime::now()
                        .duration_since(std::time::UNIX_EPOCH)
                        .map(|d| d.as_millis() as u64)
                        .unwrap_or(0);
                    webui_stats::append_call_log(webui_stats::CallLogEntry {
                        timestamp_unix_ms: now_ms,
                        entry_type: "sds".to_string(),
                        from_issi: src_ssi,
                        to_issi_or_gssi: dst_ssi,
                        call_type: "sds".to_string(),
                        duration_ms: None,
                        is_live: false,
                        gssi: None,
                        call_id: None,
                    });
                }
                self.send_dsds_type4(
                    queue,
                    message.dltime,
                    TetraAddress::new(dst_ssi, SsiType::Ssi),
                    src_ssi,
                    bit_len,
                    payload,
                    false,
                    false,
                );
            } else {
                tracing::debug!("SDS local: not relayed (dst_type={:?} dst_ssi={})", dst_type, dst_ssi);
            }
            return;
        }

    }

    #[allow(dead_code)]
    fn send_sds_tl_report_to_source(
        &mut self,
        queue: &mut MessageQueue,
        dltime: tetra_core::TdmaTime,
        handle: u32,
        endpoint_id: u32,
        link_id: u32,
        source_addr: TetraAddress,
        report_sender_ssi: u32,
        raw4: [u8; 4],
    ) {
        // Build a minimal D-SDS-DATA Type-4 with 32-bit SDS-TL status payload (PID + type + status + MR)
        let pdu = DSdsData {
            calling_party_type_identifier: 1,
            calling_party_address_ssi: Some(report_sender_ssi as u64),
            calling_party_extension: None,
            short_data_type_identifier: 3,
            user_defined_data_1: None,
            user_defined_data_2: None,
            user_defined_data_3: None,
            length_indicator: Some(32),
            user_defined_data_4: Some(raw4.to_vec()),
            external_subscriber_number: None,
            dm_ms_address: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(96);
        if let Err(e) = pdu.to_bitbuf(&mut sdu) {
            tracing::warn!("SDS TX REPORT: encode failed: {:?}", e);
            return;
        }
        sdu.seek(0);

        tracing::info!(
            "SDS TX REPORT: to={} from_ssi={} raw4={:02x?}",
            source_addr,
            report_sender_ssi,
            raw4
        );

        queue.push_back(SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle,
                endpoint_id,
                link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: None,
                main_address: source_addr,
                tx_reporter: None,
            }),
        });
    }


    /// Poor man's rx_prim, as this is a subcomponent and not governed by the MessageRouter.
    pub fn route_xx_deliver(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("route_xx_deliver");

        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!();
        };
        let Some(bits) = prim.sdu.peek_bits(5) else {
            tracing::warn!("insufficient bits: {}", prim.sdu.dump_bin());
            return;
        };

        let Ok(pdu_type) = CmcePduTypeUl::try_from(bits) else {
            tracing::warn!("invalid pdu type: {} in {}", bits, prim.sdu.dump_bin());
            return;
        };

        match pdu_type {
            CmcePduTypeUl::USdsData => self.rx_u_sds_data(queue, message),
            _ => unimplemented_log!("SdsBsSubentity route_xx_deliver {:?}", pdu_type),
        }
    }
}
