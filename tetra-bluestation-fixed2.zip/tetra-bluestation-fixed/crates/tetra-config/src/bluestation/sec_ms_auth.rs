use std::collections::HashMap;

use serde::Deserialize;
use toml::Value;

/// Optional MS authentication settings for BS mode.
#[derive(Debug, Clone)]
pub struct CfgMsAuth {
    /// Enable MS authentication.
    pub enabled: bool,
    /// Log full K value during authentication attempts.
    pub log_plain_k: bool,
    /// Maximum challenge age (timeslots) before it is considered stale.
    pub challenge_ttl_slots: i32,
    /// Per-subscriber K values, keyed by ISSI.
    pub subscribers: HashMap<u32, Vec<u8>>,
}

#[derive(Default, Deserialize)]
pub struct CfgMsAuthDto {
    /// Enable MS authentication.
    #[serde(default = "default_ms_auth_enabled")]
    pub enabled: bool,
    /// Log full K value during authentication attempts.
    #[serde(default = "default_ms_auth_log_plain_k")]
    pub log_plain_k: bool,
    /// Maximum challenge age (timeslots) before it is considered stale.
    #[serde(default = "default_ms_auth_challenge_ttl_slots")]
    pub challenge_ttl_slots: i32,
    /// Per-subscriber K values.
    #[serde(default)]
    pub subscribers: Vec<CfgMsAuthSubscriberDto>,

    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

#[derive(Default, Deserialize)]
pub struct CfgMsAuthSubscriberDto {
    pub issi: u32,
    /// Hex-encoded K value (16 bytes / 128-bit).
    pub k: String,

    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

fn default_ms_auth_enabled() -> bool {
    true
}

fn default_ms_auth_challenge_ttl_slots() -> i32 {
    4 * 18 * 60
}

fn default_ms_auth_log_plain_k() -> bool {
    false
}

fn parse_hex_k(input: &str) -> Result<Vec<u8>, String> {
    let mut compact = String::with_capacity(input.len());
    let trimmed = input.trim();
    let trimmed = trimmed
        .strip_prefix("0x")
        .or_else(|| trimmed.strip_prefix("0X"))
        .unwrap_or(trimmed);

    for ch in trimmed.chars() {
        if ch.is_ascii_hexdigit() {
            compact.push(ch);
        } else if matches!(ch, ':' | '-' | '_' | ' ') {
            continue;
        } else {
            return Err(format!("K contains invalid character '{}': {}", ch, input));
        }
    }

    if compact.is_empty() {
        return Err("K value cannot be empty".to_string());
    }
    if compact.len() % 2 != 0 {
        return Err(format!("K hex length must be even, got {}", compact.len()));
    }

    let mut out = Vec::with_capacity(compact.len() / 2);
    for i in (0..compact.len()).step_by(2) {
        let byte = u8::from_str_radix(&compact[i..i + 2], 16).map_err(|e| format!("invalid K hex byte at {}: {}", i, e))?;
        out.push(byte);
    }

    Ok(out)
}

/// Convert a CfgMsAuthDto (from TOML) into a CfgMsAuth (used in stack config)
pub fn apply_ms_auth_patch(src: CfgMsAuthDto) -> Result<CfgMsAuth, String> {
    if src.challenge_ttl_slots <= 0 {
        return Err("ms_auth.challenge_ttl_slots must be > 0".to_string());
    }

    let mut subscribers = HashMap::with_capacity(src.subscribers.len());
    for sub in src.subscribers {
        let k_bytes = parse_hex_k(&sub.k).map_err(|e| format!("invalid K for ISSI {}: {}", sub.issi, e))?;
        if k_bytes.len() != 16 {
            return Err(format!(
                "invalid K for ISSI {}: expected 16 bytes (128-bit), got {} bytes",
                sub.issi,
                k_bytes.len()
            ));
        }
        if subscribers.insert(sub.issi, k_bytes).is_some() {
            return Err(format!("duplicate ms_auth subscriber entry for ISSI {}", sub.issi));
        }
    }

    if src.enabled && subscribers.is_empty() {
        return Err("ms_auth is enabled but no subscribers are configured".to_string());
    }

    Ok(CfgMsAuth {
        enabled: src.enabled,
        log_plain_k: src.log_plain_k,
        challenge_ttl_slots: src.challenge_ttl_slots,
        subscribers,
    })
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use super::*;

    #[test]
    fn parse_hex_k_accepts_common_formats() {
        let parsed = parse_hex_k("0xAA:bb-cc_dd 01").expect("hex parse failed");
        assert_eq!(parsed, vec![0xAA, 0xBB, 0xCC, 0xDD, 0x01]);
    }

    #[test]
    fn parse_hex_k_rejects_odd_length() {
        let err = parse_hex_k("abc").expect_err("expected parse error");
        assert!(err.contains("even"));
    }

    #[test]
    fn apply_ms_auth_patch_rejects_duplicates() {
        let src = CfgMsAuthDto {
            enabled: true,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![
                CfgMsAuthSubscriberDto {
                    issi: 1001,
                    k: "0011".to_string(),
                    extra: HashMap::new(),
                },
                CfgMsAuthSubscriberDto {
                    issi: 1001,
                    k: "0022".to_string(),
                    extra: HashMap::new(),
                },
            ],
            extra: HashMap::new(),
        };

        let err = apply_ms_auth_patch(src).expect_err("expected duplicate parse error");
        assert!(err.contains("duplicate"));
    }

    #[test]
    fn apply_ms_auth_patch_rejects_non_128_bit_k() {
        let src = CfgMsAuthDto {
            enabled: true,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233".to_string(),
                extra: HashMap::new(),
            }],
            extra: HashMap::new(),
        };

        let err = apply_ms_auth_patch(src).expect_err("expected K length parse error");
        assert!(err.contains("expected 16 bytes"));
    }
}
