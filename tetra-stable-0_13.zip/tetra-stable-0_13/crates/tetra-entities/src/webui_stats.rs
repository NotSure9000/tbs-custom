use std::collections::{HashMap, VecDeque};
use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

use serde::Serialize;

/// Status of a provisioned MS (radio)
#[derive(Clone, Debug, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum MsStatus {
    Offline,
    Online,
    OnCall,
    Error,
}

impl Default for MsStatus {
    fn default() -> Self {
        MsStatus::Offline
    }
}

/// A provisioned radio with ISSI and key presence indicator
#[derive(Clone, Debug, Default, Serialize)]
pub struct ProvisionedRadio {
    pub issi: u32,
    pub has_key: bool,
    pub status: MsStatus,
}

/// A single call/SDS log entry
#[derive(Clone, Debug, Serialize)]
pub struct CallLogEntry {
    pub timestamp_unix_ms: u64,
    pub entry_type: String,
    pub from_issi: u32,
    pub to_issi_or_gssi: u32,
    pub call_type: String,
    pub duration_ms: Option<u64>,
    pub is_live: bool,
    pub gssi: Option<u32>,
    pub call_id: Option<u64>,
}

/// Air interface statistics (rolling + all-time)
#[derive(Clone, Debug, Default, Serialize)]
pub struct AirStats {
    /// Total UL control-channel frames received (all-time)
    pub ul_ctrl_frames_total: u64,
    /// UL control-channel frames with CRC error (all-time)
    pub ul_ctrl_frames_crc_err: u64,
    /// Total UL traffic-channel frames received (all-time)
    pub ul_traffic_frames_total: u64,
    /// UL traffic-channel frames with Bad Frame Indicator (all-time)
    pub ul_traffic_frames_bfi: u64,
    /// Control-channel CRC error rate over last 1000 frames (0.0–1.0)
    pub ctrl_crc_error_rate: f32,
    /// Traffic BFI rate over last 1000 frames (0.0–1.0)
    pub traffic_bfi_rate: f32,
}

/// 24-hour MS online history — one slot per hour, tracking the *maximum*
/// registered MS count seen within that hour.  Slot 0 is the oldest (23h ago),
/// slot 23 is the current (most recent) hour.
#[derive(Clone, Debug, Serialize)]
pub struct MsOnlineHistory {
    /// Max online count per hour slot [0..24], oldest-first
    pub slots: [u32; 24],
    /// Unix timestamp (seconds) of the start of the current (slot 23) hour
    pub current_hour_ts: u64,
}

impl Default for MsOnlineHistory {
    fn default() -> Self {
        Self { slots: [0u32; 24], current_hour_ts: 0 }
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiStatsSnapshot {
    pub registered_issi_count: u64,
    pub registered_issis: Vec<u32>,
    pub affiliated_group_links: u64,
    pub groups_with_listeners: u64,
    pub active_group_calls: u64,
    pub active_individual_calls: u64,
    pub total_group_call_setups: u64,
    pub total_individual_call_setups: u64,
    pub updated_unix_ms: u64,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiExtendedSnapshot {
    pub provisioned_radios: Vec<ProvisionedRadio>,
    pub call_log: Vec<CallLogEntry>,
    /// GSSIs that have at least one affiliated listener
    pub active_talkgroups: Vec<u32>,
    /// Subset of active_talkgroups: GSSIs with an ongoing group call right now
    pub active_call_talkgroups: Vec<u32>,
    pub sds_sent: u64,
    pub sds_delivered: u64,
    pub air: AirStats,
    /// 24-hour MS online history (max per hour, 1-hour granularity)
    pub ms_online_history: MsOnlineHistory,
    pub updated_unix_ms: u64,
}

// ─── Rolling-window frame counter ─────────────────────────────────────────────

const ROLLING_WINDOW: usize = 1000;

#[derive(Default)]
struct FrameStats {
    total_alltime: u64,
    err_alltime: u64,
    /// Ring buffer tracking errors in the last ROLLING_WINDOW frames
    window: VecDeque<bool>,
    window_err_count: usize,
}

impl FrameStats {
    fn record(&mut self, is_error: bool) {
        self.total_alltime += 1;
        if is_error {
            self.err_alltime += 1;
        }
        self.window.push_back(is_error);
        if is_error {
            self.window_err_count += 1;
        }
        if self.window.len() > ROLLING_WINDOW {
            if let Some(evicted) = self.window.pop_front() {
                if evicted {
                    self.window_err_count = self.window_err_count.saturating_sub(1);
                }
            }
        }
    }

    fn error_rate(&self) -> f32 {
        let n = self.window.len();
        if n == 0 { 0.0 } else { self.window_err_count as f32 / n as f32 }
    }
}

// ─── 24-hour MS online history ────────────────────────────────────────────────

/// Returns the start-of-hour Unix timestamp (seconds) for a given Unix ms timestamp.
fn hour_start_secs(unix_ms: u64) -> u64 {
    (unix_ms / 1000) / 3600 * 3600
}

// ─── Global state ─────────────────────────────────────────────────────────────

#[derive(Default)]
struct WebUiStatsState {
    snapshot: WebUiStatsSnapshot,
    extended: WebUiExtendedSnapshot,
    ctrl_frames: FrameStats,
    traffic_frames: FrameStats,
}

fn state() -> &'static Mutex<WebUiStatsState> {
    static STATE: OnceLock<Mutex<WebUiStatsState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(WebUiStatsState::default()))
}

fn now_unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

// ─── Public API ───────────────────────────────────────────────────────────────

/// Called by CcBsSubentity::new() on stack init. Preserves the provisioned radio
/// list (which comes from config) but resets all other state.
pub fn reset() {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        s.snapshot = WebUiStatsSnapshot { updated_unix_ms: now, ..Default::default() };
        let reset_radios: Vec<ProvisionedRadio> = std::mem::take(&mut s.extended.provisioned_radios)
            .into_iter()
            .map(|mut r| { r.status = MsStatus::Offline; r })
            .collect();
        // Air stats (FrameStats) are intentionally not reset — they are cumulative
        // and survive stack re-init.
        // ms_online_history is also preserved across resets so the chart isn't wiped.
        let preserved_history = s.extended.ms_online_history.clone();
        s.extended = WebUiExtendedSnapshot {
            updated_unix_ms: now,
            provisioned_radios: reset_radios,
            ms_online_history: preserved_history,
            ..Default::default()
        };
    }
}

pub fn set_provisioned_radios(radios: Vec<(u32, bool)>) {
    if let Ok(mut s) = state().lock() {
        let old_statuses: HashMap<u32, MsStatus> = s.extended.provisioned_radios
            .iter()
            .map(|r| (r.issi, r.status.clone()))
            .collect();
        let mut new_radios: Vec<ProvisionedRadio> = radios.into_iter().map(|(issi, has_key)| {
            ProvisionedRadio {
                issi,
                has_key,
                status: old_statuses.get(&issi).cloned().unwrap_or(MsStatus::Offline),
            }
        }).collect();
        new_radios.sort_by_key(|r| r.issi);
        s.extended.provisioned_radios = new_radios;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_ms_status(issi: u32, status: MsStatus) {
    if let Ok(mut s) = state().lock() {
        if let Some(radio) = s.extended.provisioned_radios.iter_mut().find(|r| r.issi == issi) {
            radio.status = status;
            s.extended.updated_unix_ms = now_unix_ms();
        }
    }
}

pub fn append_call_log(entry: CallLogEntry) {
    if let Ok(mut s) = state().lock() {
        s.extended.call_log.insert(0, entry);
        if s.extended.call_log.len() > 200 {
            s.extended.call_log.truncate(200);
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn finalize_call_log(call_id: u64, ended_at_unix_ms: u64) {
    if let Ok(mut s) = state().lock() {
        for entry in s.extended.call_log.iter_mut() {
            if entry.call_id == Some(call_id) && entry.is_live {
                entry.is_live = false;
                entry.duration_ms = Some(ended_at_unix_ms.saturating_sub(entry.timestamp_unix_ms));
                break;
            }
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_active_talkgroups(mut gssis: Vec<u32>) {
    gssis.sort_unstable();
    gssis.dedup();
    if let Ok(mut s) = state().lock() {
        s.extended.active_talkgroups = gssis;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Update the set of GSSIs that currently have an active group call in progress.
/// This is a subset of `active_talkgroups` and is used by the web UI to colour-
/// highlight talkgroup pills that are live on air.
pub fn set_active_call_talkgroups(mut gssis: Vec<u32>) {
    gssis.sort_unstable();
    gssis.dedup();
    if let Ok(mut s) = state().lock() {
        s.extended.active_call_talkgroups = gssis;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn inc_sds_sent() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_sent += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn inc_sds_delivered() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_delivered += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Record a UL control-channel frame. Called from lmac_bs for every decoded
/// signalling block regardless of CRC outcome.
pub fn record_ctrl_frame(crc_ok: bool) {
    if let Ok(mut s) = state().lock() {
        s.ctrl_frames.record(!crc_ok);
        let total = s.ctrl_frames.total_alltime;
        let err   = s.ctrl_frames.err_alltime;
        let rate  = s.ctrl_frames.error_rate();
        let now   = now_unix_ms();
        s.extended.air.ul_ctrl_frames_total   = total;
        s.extended.air.ul_ctrl_frames_crc_err = err;
        s.extended.air.ctrl_crc_error_rate    = rate;
        s.extended.updated_unix_ms = now;
    }
}

/// Record a UL traffic-channel frame. Called from lmac_bs for every decoded
/// voice block regardless of BFI (Bad Frame Indicator).
pub fn record_traffic_frame(crc_ok: bool) {
    if let Ok(mut s) = state().lock() {
        s.traffic_frames.record(!crc_ok);
        let total = s.traffic_frames.total_alltime;
        let bfi   = s.traffic_frames.err_alltime;
        let rate  = s.traffic_frames.error_rate();
        let now   = now_unix_ms();
        s.extended.air.ul_traffic_frames_total = total;
        s.extended.air.ul_traffic_frames_bfi   = bfi;
        s.extended.air.traffic_bfi_rate        = rate;
        s.extended.updated_unix_ms = now;
    }
}

/// Update the 24-hour MS online history with the current registered count.
/// Called from `publish()` on every stats tick.
/// Advances hour slots when wall-clock hour changes; records the max count
/// seen within the current hour slot.
fn update_ms_online_history(hist: &mut MsOnlineHistory, count: u32, now_ms: u64) {
    let this_hour = hour_start_secs(now_ms);

    if hist.current_hour_ts == 0 {
        // First call ever — initialise
        hist.current_hour_ts = this_hour;
        hist.slots[23] = count;
        return;
    }

    if this_hour > hist.current_hour_ts {
        // One or more hours have elapsed — rotate slots
        let hours_elapsed = ((this_hour - hist.current_hour_ts) / 3600).min(24) as usize;
        if hours_elapsed >= 24 {
            // More than 24h gap — clear everything
            hist.slots = [0u32; 24];
        } else {
            // Shift slots left by hours_elapsed, filling new slots with 0
            hist.slots.rotate_left(hours_elapsed);
            for slot in hist.slots[24 - hours_elapsed..].iter_mut() {
                *slot = 0;
            }
        }
        hist.current_hour_ts = this_hour;
        hist.slots[23] = count;
    } else {
        // Still within the current hour — update max
        if count > hist.slots[23] {
            hist.slots[23] = count;
        }
    }
}

#[allow(clippy::too_many_arguments)]
pub fn publish(
    mut registered_issis: Vec<u32>,
    affiliated_group_links: usize,
    groups_with_listeners: usize,
    active_group_calls: usize,
    active_individual_calls: usize,
    total_group_call_setups: u64,
    total_individual_call_setups: u64,
) {
    registered_issis.sort_unstable();
    registered_issis.dedup();
    let count = registered_issis.len() as u32;
    let now = now_unix_ms();
    let snapshot = WebUiStatsSnapshot {
        registered_issi_count: count as u64,
        registered_issis,
        affiliated_group_links: affiliated_group_links as u64,
        groups_with_listeners: groups_with_listeners as u64,
        active_group_calls: active_group_calls as u64,
        active_individual_calls: active_individual_calls as u64,
        total_group_call_setups,
        total_individual_call_setups,
        updated_unix_ms: now,
    };
    if let Ok(mut s) = state().lock() {
        s.snapshot = snapshot;
        update_ms_online_history(&mut s.extended.ms_online_history, count, now);
        s.extended.updated_unix_ms = now;
    }
}

pub fn snapshot() -> WebUiStatsSnapshot {
    state().lock().map(|s| s.snapshot.clone())
        .unwrap_or_else(|_| WebUiStatsSnapshot { updated_unix_ms: now_unix_ms(), ..Default::default() })
}

pub fn snapshot_json() -> String {
    serde_json::to_string(&snapshot()).unwrap_or_else(|_| "{}".to_string())
}

pub fn extended_snapshot() -> WebUiExtendedSnapshot {
    state().lock().map(|s| s.extended.clone())
        .unwrap_or_else(|_| WebUiExtendedSnapshot { updated_unix_ms: now_unix_ms(), ..Default::default() })
}

pub fn extended_snapshot_json() -> String {
    serde_json::to_string(&extended_snapshot()).unwrap_or_else(|_| "{}".to_string())
}
