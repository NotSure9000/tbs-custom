use std::collections::{HashMap, HashSet};

use tetra_config::bluestation::SharedConfig;
use tetra_core::{
    BitBuffer, Direction, EndpointId, LinkId, MleHandle, Sap, SsiType, TdmaTime, TetraAddress, tetra_entities::TetraEntity,
    unimplemented_log,
};
use tetra_core::{TimeslotOwner, TxReceipt, TxReporter, TxState};
use tetra_pdus::cmce::enums::disconnect_cause::DisconnectCause;
use tetra_pdus::cmce::{
    enums::{
        call_timeout::CallTimeout, call_timeout_setup_phase::CallTimeoutSetupPhase, cmce_pdu_type_ul::CmcePduTypeUl,
        transmission_grant::TransmissionGrant,
    },
    fields::basic_service_information::BasicServiceInformation,
    pdus::{
        d_call_proceeding::DCallProceeding, d_connect::DConnect, d_release::DRelease, d_setup::DSetup, d_tx_ceased::DTxCeased,
        d_tx_granted::DTxGranted, u_disconnect::UDisconnect, u_release::URelease, u_setup::USetup, u_tx_ceased::UTxCeased,
        u_tx_demand::UTxDemand,
    },
    structs::cmce_circuit::CmceCircuit,
};
use tetra_saps::{
    SapMsg, SapMsgInner,
    control::{
        brew::{BrewSubscriberAction, MmSubscriberUpdate},
        call_control::{CallControl, Circuit},
        enums::{circuit_mode_type::CircuitModeType, communication_type::CommunicationType},
    },
    lcmc::{
        LcmcMleUnitdataReq,
        enums::{alloc_type::ChanAllocType, ul_dl_assignment::UlDlAssignment},
        fields::chan_alloc_req::CmceChanAllocReq,
    },
};

use crate::brew;
use crate::{
    MessageQueue,
    cmce::components::circuit_mgr::{CircuitMgr, CircuitMgrCmd},
    mm::components::auth_taa1::ta61_decrypt_identity,
};

const NETWORK_CALL_START_GRACE_FRAMES: i32 = 12 * 18 * 4;

/// Clause 11 Call Control CMCE sub-entity
pub struct CcBsSubentity {
    config: SharedConfig,
    dltime: TdmaTime,
    /// Cached D-SETUP PDUs for late-entry re-sends: call_id -> (D-SETUP PDU, dest address, tx receipt)
    cached_setups: HashMap<u16, (DSetup, TetraAddress, Option<TxReceipt>)>,
    /// Deferred network-originated call starts waiting for listener affiliation.
    pending_network_starts: Vec<PendingNetworkCallStart>,
    circuits: CircuitMgr,
    /// Active group calls: call_id -> call info
    active_calls: HashMap<u16, ActiveCall>,
    /// Registered subscriber groups (ISSI -> set of GSSIs)
    subscriber_groups: HashMap<u32, HashSet<u32>>,
    /// Listener counts per GSSI
    group_listeners: HashMap<u32, usize>,
    /// ESI -> ISSI mapping for encrypted UL sessions.
    esi_to_issi: HashMap<u32, u32>,
    /// ISSI -> ESI inverse mapping.
    issi_to_esi: HashMap<u32, u32>,
}

/// Origin of a group call
#[derive(Clone)]
enum CallOrigin {
    /// Local MS-initiated call, needs MLE routing for individual addressing
    Local {
        caller_addr: TetraAddress, // For D-CALL-PROCEEDING, D-CONNECT routing
    },
    /// Network-initiated call from TetraPack/Brew
    Network {
        brew_uuid: uuid::Uuid, // For Brew tracking
    },
}

#[derive(Clone, Copy)]
struct LocalCallRoute {
    addr: TetraAddress,
    handle: MleHandle,
    endpoint_id: EndpointId,
    link_id: LinkId,
}

/// Tracks an active group call (local or network-initiated)
#[derive(Clone)]
struct ActiveCall {
    origin: CallOrigin,
    /// Route data for individually addressed setup/control refreshes back to local owner.
    /// `None` for network-originated calls.
    local_route: Option<LocalCallRoute>,
    dest_gssi: u32,   // Destination group
    source_issi: u32, // Current speaker
    ts: u8,
    usage: u8,
    /// True if someone is currently transmitting
    tx_active: bool,
    /// When PTT was released (for hangtime). None if transmitting.
    hangtime_start: Option<TdmaTime>,
    /// Brew session UUID — set when a network speaker is active on this call,
    /// regardless of call origin. Cleared when the network speaker ends.
    brew_uuid: Option<uuid::Uuid>,
    /// Air-interface encryption state for this call (SC2/AIE).
    /// This is transport security and is distinct from CMCE basic service encryption flag.
    air_interface_encrypted: bool,
}

#[derive(Clone)]
struct PendingNetworkCallStart {
    brew_uuid: uuid::Uuid,
    source_issi: u32,
    dest_gssi: u32,
    priority: u8,
    queued_at: TdmaTime,
}

impl CcBsSubentity {
    pub fn new(config: SharedConfig) -> Self {
        CcBsSubentity {
            config,
            dltime: TdmaTime::default(),
            cached_setups: HashMap::new(),
            pending_network_starts: Vec::new(),
            circuits: CircuitMgr::new(),
            active_calls: HashMap::new(),
            subscriber_groups: HashMap::new(),
            group_listeners: HashMap::new(),
            esi_to_issi: HashMap::new(),
            issi_to_esi: HashMap::new(),
        }
    }

    pub fn set_config(&mut self, config: SharedConfig) {
        self.config = config;
    }

    fn build_d_setup_prim(pdu: &DSetup, usage: u8, ts: u8, ul_dl: UlDlAssignment) -> (BitBuffer, CmceChanAllocReq) {
        tracing::debug!("-> {:?}", pdu);

        let mut sdu = BitBuffer::new_autoexpand(80);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DSetup");
        sdu.seek(0);

        // Construct ChanAlloc descriptor for the allocated timeslot
        let mut timeslots = [false; 4];
        timeslots[ts as usize - 1] = true;
        let chan_alloc = CmceChanAllocReq {
            usage: Some(usage),
            alloc_type: ChanAllocType::Replace,
            carrier: None,
            timeslots,
            ul_dl_assigned: ul_dl,
        };
        (sdu, chan_alloc)
    }

    fn build_sapmsg(
        sdu: BitBuffer,
        chan_alloc: Option<CmceChanAllocReq>,
        dltime: TdmaTime,
        address: TetraAddress,
        reporter: Option<TxReporter>,
    ) -> SapMsg {
        // Construct prim
        SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: 0,
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc,
                main_address: address,
                tx_reporter: reporter,
            }),
        }
    }

    fn build_sapmsg_stealing(sdu: BitBuffer, dltime: TdmaTime, address: TetraAddress, ts: u8) -> SapMsg {
        // For FACCH stealing on traffic channel, must specify target timeslot
        let mut timeslots = [false; 4];
        timeslots[(ts - 1) as usize] = true;
        let chan_alloc = CmceChanAllocReq {
            usage: None,
            carrier: None,
            timeslots,
            alloc_type: ChanAllocType::Replace,
            ul_dl_assigned: UlDlAssignment::Both,
        };

        SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: 0,
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: true,
                stealing_repeats_flag: false,
                chan_alloc: Some(chan_alloc),
                main_address: address,
                tx_reporter: None,
            }),
        }
    }

    fn build_d_release_from_d_setup(d_setup_pdu: &DSetup, disconnect_cause: DisconnectCause) -> BitBuffer {
        let pdu = DRelease {
            call_identifier: d_setup_pdu.call_identifier,
            disconnect_cause,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };
        tracing::info!("-> {:?}", pdu);

        let mut sdu = BitBuffer::new_autoexpand(32);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DRelease");
        sdu.seek(0);
        sdu
    }

    fn send_d_tx_granted_individual_facch(
        &mut self,
        queue: &mut MessageQueue,
        call_id: u16,
        transmitting_party_issi: u32,
        mut destination_address: TetraAddress,
        ts: u8,
    ) {
        let pdu = DTxGranted {
            call_identifier: call_id,
            transmission_grant: TransmissionGrant::Granted.into_raw() as u8,
            // Align with clear-call behavior and ETSI interop note:
            // 0 means request to transmit is permitted.
            transmission_request_permission: false,
            encryption_control: self.is_call_air_encrypted(call_id),
            reserved: false,
            notification_indicator: None,
            transmitting_party_type_identifier: Some(1),
            transmitting_party_address_ssi: Some(transmitting_party_issi as u64),
            transmitting_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::info!("-> D-TX GRANTED (individual FACCH, Granted) {:?}", pdu);
        let mut sdu = BitBuffer::new_autoexpand(50);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DTxGranted");
        sdu.seek(0);

        destination_address.encrypted = self.is_local_call_signalling_encrypted(call_id);
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, destination_address, ts);
        queue.push_back(msg);
    }

    fn has_listener(&self, gssi: u32) -> bool {
        self.group_listeners.get(&gssi).copied().unwrap_or(0) > 0
    }

    fn cmce_aie_enabled(&self) -> bool {
        let cfg = self.config.config();
        cfg.cell.aie_service
            && cfg
                .ms_auth
                .as_ref()
                .is_some_and(|ms_auth| ms_auth.select_tmo_sck_material().is_some())
    }

    fn resolve_esi(&self, esi: u32) -> Option<u32> {
        let cfg = self.config.config();
        let ms_auth = cfg.ms_auth.as_ref()?;
        if !ms_auth.enabled {
            return None;
        }
        for sck_entry in &ms_auth.sck_material {
            let candidate = ta61_decrypt_identity(&sck_entry.sck, esi);
            if ms_auth.subscribers.contains_key(&candidate) {
                tracing::info!(
                    "CMCE TA61 ESI resolution: ESI {} -> ISSI {} (SCKN={} SCK-VN={})",
                    esi,
                    candidate,
                    sck_entry.sck_n,
                    sck_entry.sck_vn
                );
                return Some(candidate);
            }
        }
        tracing::warn!("CMCE TA61 ESI resolution failed for ESI {}", esi);
        None
    }

    fn register_esi_session(&mut self, esi: u32, issi: u32) {
        if let Some(old_esi) = self.issi_to_esi.remove(&issi) {
            self.esi_to_issi.remove(&old_esi);
        }
        self.esi_to_issi.insert(esi, issi);
        self.issi_to_esi.insert(issi, esi);
        tracing::debug!("CMCE ESI session registered: ESI {} <-> ISSI {}", esi, issi);
    }

    fn clear_esi_session_by_issi(&mut self, issi: u32) {
        if let Some(esi) = self.issi_to_esi.remove(&issi) {
            self.esi_to_issi.remove(&esi);
            tracing::debug!("CMCE ESI session cleared: ISSI {} (ESI {})", issi, esi);
        }
    }

    fn resolve_uplink_issi(&mut self, raw_ssi: u32, encrypted: bool) -> u32 {
        if encrypted {
            if let Some(&issi) = self.esi_to_issi.get(&raw_ssi) {
                return issi;
            }
            if let Some(issi) = self.resolve_esi(raw_ssi) {
                self.register_esi_session(raw_ssi, issi);
                return issi;
            }
            return raw_ssi;
        }

        if self.issi_to_esi.contains_key(&raw_ssi) {
            self.clear_esi_session_by_issi(raw_ssi);
        }
        raw_ssi
    }

    fn is_call_air_encrypted(&self, call_id: u16) -> bool {
        self.active_calls
            .get(&call_id)
            .map(|call| call.air_interface_encrypted)
            .or_else(|| self.cached_setups.get(&call_id).map(|(_, dest_addr, _)| dest_addr.encrypted))
            .unwrap_or(false)
    }

    fn is_local_call_signalling_encrypted(&self, call_id: u16) -> bool {
        self.active_calls
            .get(&call_id)
            .and_then(|call| call.local_route.map(|route| route.addr.encrypted))
            .unwrap_or_else(|| self.is_call_air_encrypted(call_id))
    }

    fn inc_group_listener(&mut self, gssi: u32) {
        let entry = self.group_listeners.entry(gssi).or_insert(0);
        *entry += 1;
    }

    fn dec_group_listener(&mut self, gssi: u32) {
        if let Some(entry) = self.group_listeners.get_mut(&gssi) {
            if *entry <= 1 {
                self.group_listeners.remove(&gssi);
            } else {
                *entry -= 1;
            }
        }
    }

    fn drop_group_calls_if_unlistened(&mut self, queue: &mut MessageQueue, gssi: u32) {
        if self.has_listener(gssi) {
            return;
        }

        let to_drop: Vec<(u16, CallOrigin)> = self
            .active_calls
            .iter()
            .filter(|(_, call)| call.dest_gssi == gssi)
            .map(|(call_id, call)| (*call_id, call.origin.clone()))
            .collect();

        for (call_id, origin) in to_drop {
            tracing::info!("CMCE: dropping call_id={} gssi={} (no listeners)", call_id, gssi);
            if let CallOrigin::Network { brew_uuid } = origin {
                if brew::is_brew_gssi_routable(&self.config, gssi) {
                    queue.push_back(SapMsg {
                        sap: Sap::Control,
                        src: TetraEntity::Cmce,
                        dest: TetraEntity::Brew,
                        dltime: self.dltime,
                        msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd { brew_uuid }),
                    });
                };
            };
            self.release_call(queue, call_id, DisconnectCause::SwmiRequestedDisconnection);
        }
    }

    fn process_pending_network_starts(&mut self, queue: &mut MessageQueue) {
        let mut i = 0;
        while i < self.pending_network_starts.len() {
            let pending = self.pending_network_starts[i].clone();
            let age = pending.queued_at.age(self.dltime);

            if self.has_listener(pending.dest_gssi) {
                tracing::info!(
                    "CMCE: starting deferred network call uuid={} gssi={} speaker={} after {} slots",
                    pending.brew_uuid,
                    pending.dest_gssi,
                    pending.source_issi,
                    age
                );
                self.pending_network_starts.remove(i);
                self.rx_network_call_start(queue, pending.brew_uuid, pending.source_issi, pending.dest_gssi, pending.priority);
                continue;
            }

            if age > NETWORK_CALL_START_GRACE_FRAMES {
                tracing::info!(
                    "CMCE: expiring deferred network call uuid={} gssi={} (no listeners after {} slots)",
                    pending.brew_uuid,
                    pending.dest_gssi,
                    age
                );
                queue.push_back(SapMsg {
                    sap: Sap::Control,
                    src: TetraEntity::Cmce,
                    dest: TetraEntity::Brew,
                    dltime: self.dltime,
                    msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd {
                        brew_uuid: pending.brew_uuid,
                    }),
                });
                self.pending_network_starts.remove(i);
                continue;
            }

            i += 1;
        }
    }

    pub fn handle_subscriber_update(&mut self, queue: &mut MessageQueue, update: MmSubscriberUpdate) {
        let issi = update.issi;
        let groups = update.groups;

        match update.action {
            BrewSubscriberAction::Register => {
                let known = self.subscriber_groups.contains_key(&issi);
                self.subscriber_groups.entry(issi).or_insert_with(HashSet::new);
                tracing::info!("CMCE: subscriber register issi={} known={}", issi, known);
            }
            BrewSubscriberAction::Deregister => {
                self.clear_esi_session_by_issi(issi);
                if let Some(existing) = self.subscriber_groups.remove(&issi) {
                    for gssi in existing {
                        self.dec_group_listener(gssi);
                        self.drop_group_calls_if_unlistened(queue, gssi);
                    }
                }
                tracing::info!("CMCE: subscriber deregister issi={}", issi);
            }
            BrewSubscriberAction::Affiliate => {
                let mut new_groups = Vec::new();
                {
                    let entry = self.subscriber_groups.entry(issi).or_insert_with(HashSet::new);
                    for gssi in groups {
                        if entry.insert(gssi) {
                            new_groups.push(gssi);
                        }
                    }
                }
                for gssi in &new_groups {
                    self.inc_group_listener(*gssi);
                }

                if new_groups.is_empty() {
                    tracing::debug!("CMCE: affiliate ignored (no new groups) issi={}", issi);
                } else {
                    tracing::info!("CMCE: subscriber affiliate issi={} groups={:?}", issi, new_groups);
                }
            }
            BrewSubscriberAction::Deaffiliate => {
                let mut removed_groups = Vec::new();
                let mut known_issi = false;
                if let Some(entry) = self.subscriber_groups.get_mut(&issi) {
                    known_issi = true;
                    for gssi in groups {
                        if entry.remove(&gssi) {
                            removed_groups.push(gssi);
                        }
                    }
                } else {
                    removed_groups = groups;
                }
                if known_issi {
                    for gssi in &removed_groups {
                        self.dec_group_listener(*gssi);
                    }
                }

                if removed_groups.is_empty() {
                    tracing::debug!("CMCE: deaffiliate ignored (no matching groups) issi={}", issi);
                } else {
                    tracing::info!("CMCE: subscriber deaffiliate issi={} groups={:?}", issi, removed_groups);
                    for gssi in &removed_groups {
                        self.drop_group_calls_if_unlistened(queue, *gssi);
                    }
                }
            }
        }

        tracing::debug!(
            "CMCE subscriber-state: issi={} action={:?} known_subscribers={} tracked_groups={}",
            issi,
            update.action,
            self.subscriber_groups.len(),
            self.group_listeners.len()
        );

        // Affiliation events can arrive shortly after a network call request. Try deferred starts immediately.
        self.process_pending_network_starts(queue);
    }

    fn send_d_call_proceeding(
        &mut self,
        queue: &mut MessageQueue,
        message: &SapMsg,
        pdu_request: &USetup,
        call_id: u16,
        _resolved_encryption_flag: bool,
        signalling_encrypted: bool,
    ) {
        tracing::trace!("send_d_call_proceeding");

        let SapMsgInner::LcmcMleUnitdataInd(prim) = &message.msg else {
            tracing::warn!("CMCE send_d_call_proceeding called with unexpected payload");
            return;
        };

        let pdu_response = DCallProceeding {
            call_identifier: call_id,
            // Match known-good clear setup signaling behavior.
            call_time_out_set_up_phase: CallTimeoutSetupPhase::T10s,
            hook_method_selection: pdu_request.hook_method_selection,
            simplex_duplex_selection: pdu_request.simplex_duplex_selection,
            basic_service_information: None,
            call_status: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(25);
        pdu_response.to_bitbuf(&mut sdu).expect("Failed to serialize DCallProceeding");
        sdu.seek(0);
        tracing::debug!("send_d_call_proceeding: -> {:?} sdu {}", pdu_response, sdu.dump_bin());

        let mut dest_addr = prim.received_tetra_address;
        dest_addr.encrypted = signalling_encrypted;

        let msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: prim.handle,
                endpoint_id: prim.endpoint_id,
                link_id: prim.link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,

                chan_alloc: None,
                main_address: dest_addr,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_connect_to_caller(
        &mut self,
        queue: &mut MessageQueue,
        message: &SapMsg,
        pdu_request: &USetup,
        call_id: u16,
        usage: u8,
        ts: u8,
        _resolved_encryption_flag: bool,
        signalling_encrypted: bool,
    ) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &message.msg else {
            tracing::warn!("CMCE send_d_connect_to_caller called with unexpected payload");
            return;
        };

        let mut timeslots = [false; 4];
        timeslots[ts as usize - 1] = true;

        let d_connect = DConnect {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: pdu_request.hook_method_selection,
            simplex_duplex_selection: pdu_request.simplex_duplex_selection,
            transmission_grant: TransmissionGrant::Granted,
            // Keep clear-flow semantics: false permits request-to-transmit.
            transmission_request_permission: false,
            call_ownership: true, // Calling MS is the call owner (ETSI 14.8.4)
            call_priority: None,
            basic_service_information: None,
            temporary_address: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_connect);
        let mut connect_sdu = BitBuffer::new_autoexpand(30);
        d_connect.to_bitbuf(&mut connect_sdu).expect("Failed to serialize DConnect");
        connect_sdu.seek(0);

        let mut calling_party_individual = prim.received_tetra_address;
        calling_party_individual.encrypted = signalling_encrypted;

        let connect_msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: connect_sdu,
                handle: prim.handle,
                endpoint_id: prim.endpoint_id,
                link_id: prim.link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: Some(CmceChanAllocReq {
                    usage: Some(usage),
                    alloc_type: ChanAllocType::Replace,
                    carrier: None,
                    timeslots,
                    ul_dl_assigned: UlDlAssignment::Both,
                }),
                main_address: calling_party_individual,
                tx_reporter: None,
            }),
        };
        queue.push_back(connect_msg);
    }

    /// Re-send setup-phase signaling to the local call owner.
    /// ETSI EN 300 392-2 allows the calling MS to ignore group D-SETUP when it
    /// recognizes itself as caller, so D-CONNECT delivery is the key transition.
    fn send_setup_phase_refresh_to_local_owner(&mut self, queue: &mut MessageQueue, call_id: u16) {
        let (route, call_ts, call_usage, speaker_issi, hook_method_selection, simplex_duplex_selection) = {
            let Some(call) = self.active_calls.get(&call_id) else {
                return;
            };
            if !matches!(call.origin, CallOrigin::Local { .. }) {
                return;
            }
            let Some(route) = call.local_route else {
                tracing::warn!("CMCE setup refresh skipped: no owner route for call_id={}", call_id);
                return;
            };
            let Some((d_setup, _, _)) = self.cached_setups.get(&call_id) else {
                tracing::warn!("CMCE setup refresh skipped: no cached D-SETUP for call_id={}", call_id);
                return;
            };
            (
                route,
                call.ts,
                call.usage,
                call.source_issi,
                d_setup.hook_method_selection,
                d_setup.simplex_duplex_selection,
            )
        };
        if !self.is_local_call_signalling_encrypted(call_id) {
            return;
        }

        let mut target_addr = route.addr;
        target_addr.encrypted = self.is_local_call_signalling_encrypted(call_id);

        let d_call_proceeding = DCallProceeding {
            call_identifier: call_id,
            call_time_out_set_up_phase: CallTimeoutSetupPhase::T10s,
            hook_method_selection,
            simplex_duplex_selection,
            basic_service_information: None,
            call_status: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };
        let mut proceeding_sdu = BitBuffer::new_autoexpand(25);
        d_call_proceeding
            .to_bitbuf(&mut proceeding_sdu)
            .expect("Failed to serialize DCallProceeding");
        proceeding_sdu.seek(0);
        queue.push_back(SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: self.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: proceeding_sdu,
                handle: route.handle,
                endpoint_id: route.endpoint_id,
                link_id: route.link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: None,
                main_address: target_addr,
                tx_reporter: None,
            }),
        });

        let mut timeslots = [false; 4];
        timeslots[call_ts as usize - 1] = true;
        let d_connect = DConnect {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection,
            simplex_duplex_selection,
            transmission_grant: TransmissionGrant::Granted,
            transmission_request_permission: false,
            call_ownership: true,
            call_priority: None,
            basic_service_information: None,
            temporary_address: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };
        let mut connect_sdu = BitBuffer::new_autoexpand(30);
        d_connect.to_bitbuf(&mut connect_sdu).expect("Failed to serialize DConnect");
        connect_sdu.seek(0);
        queue.push_back(SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: self.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: connect_sdu,
                handle: route.handle,
                endpoint_id: route.endpoint_id,
                link_id: route.link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: Some(CmceChanAllocReq {
                    usage: Some(call_usage),
                    alloc_type: ChanAllocType::Replace,
                    carrier: None,
                    timeslots,
                    ul_dl_assigned: UlDlAssignment::Both,
                }),
                main_address: target_addr,
                tx_reporter: None,
            }),
        });

        tracing::debug!(
            "CMCE setup refresh: resent owner D-CALL PROCEEDING + D-CONNECT call_id={} addr={} ts={} usage={} payload_speaker_issi={}",
            call_id,
            target_addr,
            call_ts,
            call_usage,
            speaker_issi
        );
    }

    fn signal_umac_circuit_open(&self, queue: &mut MessageQueue, call: &CmceCircuit, dltime: TdmaTime) {
        let circuit = Circuit {
            direction: call.direction,
            ts: call.ts,
            usage: call.usage,
            circuit_mode: call.circuit_mode,
            speech_service: call.speech_service,
            etee_encrypted: call.etee_encrypted,
        };
        let cmd = SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::Open(circuit)),
        };
        queue.push_back(cmd);
    }

    fn signal_umac_circuit_close(queue: &mut MessageQueue, circuit: CmceCircuit, dltime: TdmaTime) {
        let cmd = SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::Close(circuit.direction, circuit.ts)),
        };
        queue.push_back(cmd);
    }

    fn rx_u_setup(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_setup: {:?}", message);
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            tracing::warn!("CMCE rx_u_setup called with unexpected payload");
            return;
        };
        let calling_party = prim.received_tetra_address;
        let resolved_calling_issi = self.resolve_uplink_issi(calling_party.ssi, calling_party.encrypted);
        let caller_route = LocalCallRoute {
            addr: calling_party,
            handle: prim.handle,
            endpoint_id: prim.endpoint_id,
            link_id: prim.link_id,
        };

        let pdu = match USetup::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-SETUP {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-SETUP: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request
        if !Self::feature_check_u_setup(&pdu) {
            tracing::error!("Unsupported critical features in USetup");
            return;
        }

        // Get destination GSSI (called party)
        let Some(dest_gssi) = pdu.called_party_ssi else {
            tracing::warn!("U-SETUP without called_party_ssi, ignoring");
            return;
        };
        let dest_gssi = dest_gssi as u32;
        let mut dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);

        if !self.has_listener(dest_gssi) {
            let mut auto_affiliated = false;
            let mut healed_listener_count = false;
            let mut needs_listener_increment = false;
            let had_listener_count = self.group_listeners.get(&dest_gssi).copied().unwrap_or(0) > 0;

            if let Some(groups) = self.subscriber_groups.get_mut(&resolved_calling_issi) {
                if groups.insert(dest_gssi) {
                    auto_affiliated = true;
                    needs_listener_increment = true;
                } else if !had_listener_count {
                    // Repair listener_count drift when affiliation set says attached but
                    // counter was dropped by an earlier out-of-order deaffiliate event.
                    healed_listener_count = true;
                    needs_listener_increment = true;
                }
            }

            if needs_listener_increment {
                self.inc_group_listener(dest_gssi);
            }

            if auto_affiliated {
                tracing::warn!(
                    "CMCE: auto-affiliated ISSI {} to GSSI {} on U-SETUP (MM affiliation missing/late)",
                    resolved_calling_issi,
                    dest_gssi
                );
            } else if healed_listener_count {
                tracing::warn!(
                    "CMCE: restored listener count for GSSI {} on U-SETUP from ISSI {}",
                    dest_gssi,
                    resolved_calling_issi
                );
            }

            if self.has_listener(dest_gssi) {
                tracing::info!(
                    "CMCE: proceeding with U-SETUP after affiliation recovery for ISSI {} -> GSSI {}",
                    resolved_calling_issi,
                    dest_gssi
                );
            } else {
                let listener_count = self.group_listeners.get(&dest_gssi).copied().unwrap_or(0);
                let subscriber_known = self.subscriber_groups.contains_key(&resolved_calling_issi);
                tracing::info!(
                    "CMCE: rejecting U-SETUP from raw_ssi={} resolved_issi={} to gssi={} (no listeners; listener_count={} subscriber_known={})",
                    calling_party.ssi,
                    resolved_calling_issi,
                    dest_gssi,
                    listener_count,
                    subscriber_known
                );
                return;
            }
        }

        let requested_encryption = pdu.basic_service_information.encryption_flag;
        let cmce_aie_enabled = self.cmce_aie_enabled();
        let signalling_encrypted = calling_party.encrypted && cmce_aie_enabled;
        let call_air_encrypted = cmce_aie_enabled && (requested_encryption || calling_party.encrypted);

        if calling_party.encrypted && !cmce_aie_enabled {
            tracing::warn!(
                "U-SETUP arrived on encrypted UL address {} but CMCE AIE is unavailable; forced clear signaling response",
                calling_party.ssi
            );
        }
        if requested_encryption && !cmce_aie_enabled {
            tracing::warn!(
                "U-SETUP requested encrypted call, but CMCE AIE is unavailable; falling back to clear call"
            );
        }
        if calling_party.encrypted && resolved_calling_issi != calling_party.ssi {
            tracing::info!(
                "rx_u_setup: resolved encrypted caller E_SSI {} -> ISSI {}",
                calling_party.ssi,
                resolved_calling_issi
            );
        }

        if let Some((existing_call_id, existing_ts, existing_usage, existing_call_air_encrypted)) =
            self.active_calls.iter().find_map(|(call_id, call)| match &call.origin {
                CallOrigin::Local { .. } if call.source_issi == resolved_calling_issi && call.dest_gssi == dest_gssi => {
                    Some((*call_id, call.ts, call.usage, call.air_interface_encrypted))
                }
                _ => None,
            })
        {
            if existing_call_air_encrypted != call_air_encrypted {
                tracing::warn!(
                    "rx_u_setup: duplicate setup from {} for gssi {} requested_encryption={} differs from existing call_id={} encryption={}; reusing existing call",
                    resolved_calling_issi,
                    dest_gssi,
                    requested_encryption,
                    existing_call_id,
                    existing_call_air_encrypted
                );
            } else {
                tracing::info!(
                    "rx_u_setup: duplicate setup from {} for gssi {} -> reusing call_id={} ts={} usage={}",
                    resolved_calling_issi,
                    dest_gssi,
                    existing_call_id,
                    existing_ts,
                    existing_usage
                );
            }

            self.send_d_call_proceeding(
                queue,
                &message,
                &pdu,
                existing_call_id,
                existing_call_air_encrypted,
                signalling_encrypted,
            );
            if let Some(active_call) = self.active_calls.get_mut(&existing_call_id) {
                active_call.local_route = Some(caller_route);
                if let CallOrigin::Local { caller_addr } = &mut active_call.origin {
                    *caller_addr = calling_party;
                }
            }
            self.send_d_connect_to_caller(
                queue,
                &message,
                &pdu,
                existing_call_id,
                existing_usage,
                existing_ts,
                existing_call_air_encrypted,
                signalling_encrypted,
            );
            return;
        }

        // Allocate circuit (DL+UL for group call)
        let mut circuit = match {
            let mut state = self.config.state_write();
            self.circuits.allocate_circuit_with_allocator(
                Direction::Both,
                pdu.basic_service_information.communication_type,
                &mut state.timeslot_alloc,
                TimeslotOwner::Cmce,
            )
        } {
            Ok(circuit) => circuit.clone(),
            Err(e) => {
                let state = self.config.state_read();
                tracing::error!(
                    "Failed to allocate circuit for U-SETUP: {:?} (owners: ts2={:?}, ts3={:?}, ts4={:?}, active_calls={}, cached_setups={})",
                    e,
                    state.timeslot_alloc.owner(2),
                    state.timeslot_alloc.owner(3),
                    state.timeslot_alloc.owner(4),
                    self.active_calls.len(),
                    self.cached_setups.len()
                );
                return;
            }
        };

        circuit.etee_encrypted = call_air_encrypted;
        dest_addr.encrypted = call_air_encrypted;

        tracing::info!(
            "rx_u_setup: call from raw_ssi={} resolved_issi={} to GSSI {} → ts={} call_id={} usage={} air_if_encrypted={} signalling_encrypted={}",
            calling_party.ssi,
            resolved_calling_issi,
            dest_gssi,
            circuit.ts,
            circuit.call_id,
            circuit.usage,
            call_air_encrypted,
            signalling_encrypted
        );

        // Signal UMAC to open DL+UL circuits
        self.signal_umac_circuit_open(queue, &circuit, message.dltime);

        // === 1) Send D-CALL-PROCEEDING to the calling MS (individually addressed) ===
        // This acknowledges the U-SETUP and keeps the radio from timing out.
        self.send_d_call_proceeding(
            queue,
            &message,
            &pdu,
            circuit.call_id,
            call_air_encrypted,
            signalling_encrypted,
        );
        // === 2) Send D-CONNECT to the calling MS with Granted + channel allocation ===
        // This transitions the calling MS from "Call Setup" to "Active".
        // MUST be sent BEFORE the group D-SETUP so the radio receives it on MCCH.
        self.send_d_connect_to_caller(
            queue,
            &message,
            &pdu,
            circuit.call_id,
            circuit.usage,
            circuit.ts,
            call_air_encrypted,
            signalling_encrypted,
        );

        // === 3) Send D-SETUP to group (broadcast on MCCH with channel allocation) ===
        // GrantedToOtherUser tells other group members that someone else has the floor.
        let d_setup = DSetup {
            call_identifier: circuit.call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: pdu.hook_method_selection,
            simplex_duplex_selection: pdu.simplex_duplex_selection,
            basic_service_information: pdu.basic_service_information.clone(),
            transmission_grant: TransmissionGrant::GrantedToOtherUser,
            // Match known-good clear setup behavior; false permits TX demand.
            transmission_request_permission: false,
            call_priority: pdu.call_priority,
            notification_indicator: None,
            temporary_address: None,
            // Interop: in encrypted local setup, keep payload caller as ISSI while
            // transport addressing stays on E_SSI at lower layers.
            calling_party_address_ssi: Some(resolved_calling_issi),
            calling_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        // Cache for late-entry re-sends. Receipt starts as None so the CircuitMgr-triggered
        // backup send (within D_SETUP_REPEATS frames) is not throttled by this initial send.
        // The first re-send via tick_start will create a tracked receipt.
        self.cached_setups.insert(circuit.call_id, (d_setup, dest_addr, None));
        let (d_setup_ref, _, _) = self.cached_setups.get(&circuit.call_id).unwrap();

        let (setup_sdu, setup_chan_alloc) = Self::build_d_setup_prim(d_setup_ref, circuit.usage, circuit.ts, UlDlAssignment::Both);
        let setup_msg = Self::build_sapmsg(setup_sdu, Some(setup_chan_alloc), message.dltime, dest_addr, None);
        queue.push_back(setup_msg);

        // Track the active local call — caller is granted the floor, so tx_active = true
        self.active_calls.insert(
            circuit.call_id,
            ActiveCall {
                origin: CallOrigin::Local {
                    caller_addr: calling_party,
                },
                local_route: Some(caller_route),
                dest_gssi,
                source_issi: resolved_calling_issi,
                ts: circuit.ts,
                usage: circuit.usage,
                tx_active: true,
                hangtime_start: None,
                brew_uuid: None,
                air_interface_encrypted: call_air_encrypted,
            },
        );

        // ETSI EN 300 392-2 call setup flow: do not emit unsolicited D-TX GRANTED
        // during setup/refresh. D-TX GRANTED is handled in transmission control
        // (e.g. after U-TX DEMAND).

        // Notify Brew entity about this local call if Brew is loaded and the SSI is cleared for Brew
        // It can then forward to TetraPack if the group is subscribed
        if brew::is_brew_gssi_routable(&self.config, dest_gssi) {
            let msg = SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: message.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                    call_id: circuit.call_id,
                    source_issi: resolved_calling_issi,
                    dest_gssi,
                    ts: circuit.ts,
                }),
            };
            queue.push_back(msg);
        }

    }

    pub fn route_xx_deliver(&mut self, _queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("route_xx_deliver");

        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            tracing::warn!("CMCE route_xx_deliver called with unexpected payload");
            return;
        };
        let Some(bits) = prim.sdu.peek_bits(5) else {
            tracing::warn!("insufficient bits: {}", prim.sdu.dump_bin());
            return;
        };
        let Ok(pdu_type) = CmcePduTypeUl::try_from(bits) else {
            tracing::warn!("invalid pdu type: {} in {}", bits, prim.sdu.dump_bin());
            return;
        };

        // TODO FIXME: Besides these PDUs, we can also receive several signals (BUSY ind, CLOSE ind, etc)
        match pdu_type {
            CmcePduTypeUl::USetup => self.rx_u_setup(_queue, message),
            CmcePduTypeUl::UTxCeased => self.rx_u_tx_ceased(_queue, message),
            CmcePduTypeUl::UTxDemand => self.rx_u_tx_demand(_queue, message),
            CmcePduTypeUl::URelease => self.rx_u_release(_queue, message),
            CmcePduTypeUl::UDisconnect => self.rx_u_disconnect(_queue, message),
            CmcePduTypeUl::UAlert
            | CmcePduTypeUl::UConnect
            | CmcePduTypeUl::UInfo
            | CmcePduTypeUl::UStatus
            | CmcePduTypeUl::UCallRestore => {
                unimplemented_log!("{}", pdu_type);
            }
            _ => {
                tracing::warn!("CMCE route_xx_deliver dropping unsupported UL PDU type: {}", pdu_type);
            }
        }
    }

    pub fn tick_start(&mut self, queue: &mut MessageQueue, dltime: TdmaTime) {
        self.dltime = dltime;

        // Retry deferred network call starts while waiting for listeners to affiliate.
        self.process_pending_network_starts(queue);

        // Check hangtime expiry for active local calls
        self.check_hangtime_expiry(queue);

        if let Some(tasks) = self.circuits.tick_start(dltime) {
            for task in tasks {
                match task {
                    CircuitMgrCmd::SendDSetup(call_id, usage, ts) => {
                        {
                            // Get our cached D-SETUP, build a prim and send it down the stack
                            let Some((pdu, dest_addr, receipt)) = self.cached_setups.get_mut(&call_id) else {
                                tracing::error!("No cached D-SETUP for call id {}", call_id);
                                continue;
                            };

                            // Throttle: if the previous D-SETUP hasn't reached a final state yet
                            // (still queued in UMAC), skip this re-send to avoid flooding the MCCH.
                            if let Some(r) = receipt.as_ref() {
                                if !r.is_in_final_state() {
                                    tracing::trace!(
                                        "Suppressing D-SETUP re-send for call_id={} (previous still {:?})",
                                        call_id,
                                        r.get_state()
                                    );
                                    continue;
                                }
                                if r.get_state() == TxState::Discarded {
                                    tracing::debug!("Previous D-SETUP for call_id={} was discarded by UMAC, retrying", call_id);
                                }
                            }

                            // Update transmission_grant based on current call state:
                            // During hangtime (nobody transmitting), use NotGranted;
                            // during active TX, use GrantedToOtherUser.
                            if let Some(active) = self.active_calls.get(&call_id) {
                                pdu.transmission_grant = if active.tx_active {
                                    TransmissionGrant::GrantedToOtherUser
                                } else {
                                    TransmissionGrant::NotGranted
                                };
                            }
                            let dest_addr = *dest_addr;
                            let (sdu, chan_alloc) = Self::build_d_setup_prim(pdu, usage, ts, UlDlAssignment::Both);

                            // Create a fresh receipt/reporter for this re-send
                            let (new_receipt, reporter) = TxReceipt::new(false);
                            *receipt = Some(new_receipt);

                            let prim = Self::build_sapmsg(sdu, Some(chan_alloc), self.dltime, dest_addr, Some(reporter));
                            queue.push_back(prim);
                        }

                        self.send_setup_phase_refresh_to_local_owner(queue, call_id);
                    }

                    CircuitMgrCmd::SendClose(call_id, circuit) => {
                        tracing::warn!("need to send CLOSE for call id {}", call_id);
                        let ts = circuit.ts;
                        // Get our cached D-SETUP, build D-RELEASE and send
                        if let Some((pdu, dest_addr, _)) = self.cached_setups.get(&call_id) {
                            let dest_addr = *dest_addr;
                            let sdu = Self::build_d_release_from_d_setup(pdu, DisconnectCause::ExpiryOfTimer);
                            let prim = Self::build_sapmsg(sdu, None, self.dltime, dest_addr, None);
                            queue.push_back(prim);
                        } else {
                            tracing::error!("No cached D-SETUP for call id {}", call_id);
                        }

                        // Clean up call state
                        self.cached_setups.remove(&call_id);
                        self.active_calls.remove(&call_id);

                        // Signal UMAC to release the circuit
                        Self::signal_umac_circuit_close(queue, circuit, self.dltime);
                        self.release_timeslot(ts);
                    }
                }
            }
        }
    }

    /// Check if any active calls in hangtime have expired, and if so, release them
    fn check_hangtime_expiry(&mut self, queue: &mut MessageQueue) {
        // Hangtime: 5 multiframes = ~5 seconds
        const HANGTIME_FRAMES: i32 = 5 * 18 * 4;

        let expired: Vec<u16> = self
            .active_calls
            .iter()
            .filter_map(|(&call_id, call)| {
                if let Some(hangtime_start) = call.hangtime_start {
                    if hangtime_start.age(self.dltime) > HANGTIME_FRAMES {
                        return Some(call_id);
                    }
                }
                None
            })
            .collect();

        for call_id in expired {
            tracing::info!("Hangtime expired for call_id={}, releasing", call_id);
            self.release_call(queue, call_id, DisconnectCause::ExpiryOfTimer);
        }
    }

    fn release_timeslot(&mut self, ts: u8) {
        let mut state = self.config.state_write();
        if let Err(err) = state.timeslot_alloc.release(TimeslotOwner::Cmce, ts) {
            tracing::warn!("CcBsSubentity: failed to release timeslot ts={} err={:?}", ts, err);
        }
    }

    /// Release a call: send D-RELEASE, close circuits, clean up state
    fn release_call(&mut self, queue: &mut MessageQueue, call_id: u16, disconnect_cause: DisconnectCause) {
        let Some((pdu, dest_addr, _)) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };
        let dest_addr = *dest_addr;

        // Send D-RELEASE to group
        let sdu = Self::build_d_release_from_d_setup(pdu, disconnect_cause);
        let prim = Self::build_sapmsg(sdu, None, self.dltime, dest_addr, None);
        queue.push_back(prim);

        // Close the circuit in CircuitMgr and notify Brew
        if let Some(call) = self.active_calls.get(&call_id) {
            let ts = call.ts;
            let dest_ssi = call.dest_gssi;
            let is_local = matches!(call.origin, CallOrigin::Local { .. });

            if let Ok(circuit) = self.circuits.close_circuit(Direction::Both, ts) {
                Self::signal_umac_circuit_close(queue, circuit, self.dltime);
            }

            // Ensure UMAC clears any hangtime override for this slot even if the circuit close is delayed.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::CallEnded { call_id, ts }),
            });

            self.release_timeslot(ts);

            // Notify Brew only for local calls on SSIs that are cleared for Brew
            if brew::is_brew_gssi_routable(&self.config, dest_ssi) {
                if is_local {
                    let notify = SapMsg {
                        sap: Sap::Control,
                        src: TetraEntity::Cmce,
                        dest: TetraEntity::Brew,
                        dltime: self.dltime,
                        msg: SapMsgInner::CmceCallControl(CallControl::CallEnded { call_id, ts }),
                    };
                    queue.push_back(notify);
                }
            }
        }

        // Clean up
        self.cached_setups.remove(&call_id);
        self.active_calls.remove(&call_id);
    }

    fn feature_check_u_setup(pdu: &USetup) -> bool {
        let mut supported = true;

        if !(pdu.area_selection == 0 || pdu.area_selection == 1) {
            unimplemented_log!("Area selection not supported: {}", pdu.area_selection);
            supported = false;
        };
        if pdu.hook_method_selection == true {
            unimplemented_log!("Hook method selection not supported: {}", pdu.hook_method_selection);
            supported = false;
        };
        if pdu.simplex_duplex_selection != false {
            unimplemented_log!("Only simplex calls supported: {}", pdu.simplex_duplex_selection);
            supported = false;
        };
        // if pdu.basic_service_information != 0xFC {
        //     // TODO FIXME implement parsing
        //     tracing::error!("Basic service information not supported: {}", pdu.basic_service_information);
        //     return;
        // };
        // request_to_transmit_send_data can be false for speech group calls — the MS
        // implicitly requests to transmit by initiating the call. No action needed.
        if pdu.clir_control != 0 {
            unimplemented_log!("clir_control not supported: {}", pdu.clir_control);
        };
        if pdu.called_party_ssi.is_none() || pdu.called_party_short_number_address.is_some() || pdu.called_party_extension.is_some() {
            unimplemented_log!("we only support ssi-based calling");
        };
        // Then, we warn about some other unhandled/unsupported fields
        if let Some(v) = &pdu.external_subscriber_number {
            unimplemented_log!("external_subscriber_number not supported: {:?}", v);
        };
        if let Some(v) = &pdu.facility {
            unimplemented_log!("facility not supported: {:?}", v);
        };
        if let Some(v) = &pdu.dm_ms_address {
            unimplemented_log!("dm_ms_address not supported: {:?}", v);
        };
        if let Some(v) = &pdu.proprietary {
            unimplemented_log!("proprietary not supported: {:?}", v);
        };

        supported
    }

    /// Handle U-TX CEASED: radio released PTT
    /// Response: send D-TX CEASED via FACCH to all group members, enter hangtime
    fn rx_u_tx_ceased(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            tracing::warn!("CMCE rx_u_tx_ceased called with unexpected payload");
            return;
        };
        let sender = prim.received_tetra_address;
        let sender_issi = self.resolve_uplink_issi(sender.ssi, sender.encrypted);

        let pdu = match UTxCeased::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-TX CEASED {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-TX CEASED: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;

        // Look up the active call
        let Some(call) = self.active_calls.get_mut(&call_id) else {
            tracing::warn!("U-TX CEASED for unknown call_id={}", call_id);
            return;
        };

        // Ignore ceasing indications from non-current speakers.
        // This avoids stale/duplicate uplink control bursts from tearing down
        // the floor held by another ISSI.
        if call.source_issi != sender_issi {
            tracing::debug!(
                "U-TX CEASED from raw_ssi={} resolved_issi={} ignored on call_id={} (current speaker ISSI {})",
                sender.ssi,
                sender_issi,
                call_id,
                call.source_issi
            );
            return;
        }

        // Check if already in hangtime - ignore duplicate U-TX CEASED to avoid resetting timer
        if !call.tx_active && call.hangtime_start.is_some() {
            tracing::debug!("U-TX CEASED: already in hangtime for call_id={}, ignoring duplicate", call_id);
            return;
        }

        tracing::info!("U-TX CEASED: PTT released on call_id={}, entering hangtime", call_id);

        let ts = call.ts;
        let dest_ssi = call.dest_gssi;
        call.tx_active = false;
        call.hangtime_start = Some(self.dltime);

        // Get dest address from cached setup
        let Some((_, dest_addr, _)) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };
        let dest_addr = *dest_addr;

        // Send D-TX CEASED via FACCH (stealing) to all group members
        let d_tx_ceased = DTxCeased {
            call_identifier: call_id,
            // ETSI 14.8.43 interop behavior: false allows MS to request TX.
            transmission_request_permission: false,
            notification_indicator: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_tx_ceased);
        let mut sdu = BitBuffer::new_autoexpand(25);
        d_tx_ceased.to_bitbuf(&mut sdu).expect("Failed to serialize DTxCeased");
        sdu.seek(0);

        // Send via FACCH (stealing channel) so radios on the traffic channel hear the beep
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, dest_addr, ts);
        queue.push_back(msg);

        // Notify UMAC to enter hangtime signalling mode on this traffic timeslot.
        // This stops downlink TCH fill frames (zeros) and enables UL CommonAndAssigned so MS can request the floor.
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
        });

        // Notify Brew to stop forwarding audio, if this SSI is cleared for Br
        if brew::is_brew_gssi_routable(&self.config, dest_ssi) {
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
            });
        }
    }

    /// Handle U-TX DEMAND: another radio requests floor during hangtime
    /// Response: send D-TX GRANTED via FACCH, resume voice path
    fn rx_u_tx_demand(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            tracing::warn!("CMCE rx_u_tx_demand called with unexpected payload");
            return;
        };
        let requesting_party = prim.received_tetra_address;
        let requesting_issi = self.resolve_uplink_issi(requesting_party.ssi, requesting_party.encrypted);
        let requesting_route = LocalCallRoute {
            addr: requesting_party,
            handle: prim.handle,
            endpoint_id: prim.endpoint_id,
            link_id: prim.link_id,
        };
        let cmce_aie_enabled = self.cmce_aie_enabled();

        let pdu = match UTxDemand::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-TX DEMAND {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-TX DEMAND: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;

        // Grant decision and active-call updates
        let (ts, usage) = {
            let Some(call) = self.active_calls.get_mut(&call_id) else {
                tracing::warn!("U-TX DEMAND for unknown call_id={}", call_id);
                return;
            };

            // While someone already holds the floor, ignore extra demands.
            // (Priority/pre-emption handling is not implemented yet.)
            if call.tx_active {
                tracing::debug!(
                    "U-TX DEMAND from raw_ssi={} resolved_issi={} ignored on call_id={} (floor held by ISSI {})",
                    requesting_party.ssi,
                    requesting_issi,
                    call_id,
                    call.source_issi
                );
                return;
            }

            tracing::info!(
                "U-TX DEMAND: raw_ssi={} resolved_issi={} requests floor on call_id={}",
                requesting_party.ssi,
                requesting_issi,
                call_id
            );

            call.tx_active = true;
            call.hangtime_start = None;
            call.source_issi = requesting_issi;

            // Update caller_addr for local calls
            if let CallOrigin::Local { caller_addr } = &mut call.origin {
                *caller_addr = requesting_party;
                call.local_route = Some(requesting_route);
            }

            (call.ts, call.usage)
        };

        // If MS requests encrypted transmission on this floor request, upgrade call
        // traffic encryption (if AIE material is available) and refresh UMAC circuit state.
        let current_call_encrypted = self.is_call_air_encrypted(call_id);
        let mut effective_call_encrypted = current_call_encrypted;
        if pdu.encryption_control {
            if cmce_aie_enabled {
                effective_call_encrypted = true;
            } else {
                tracing::warn!(
                    "U-TX DEMAND requested encrypted transmission on call_id={}, but CMCE AIE is unavailable",
                    call_id
                );
            }
        }

        if effective_call_encrypted != current_call_encrypted {
            let Some((_, dest_addr, _)) = self.cached_setups.get_mut(&call_id) else {
                tracing::error!("No cached D-SETUP for call_id={}", call_id);
                return;
            };
            dest_addr.encrypted = effective_call_encrypted;
            if let Some(call) = self.active_calls.get_mut(&call_id) {
                call.air_interface_encrypted = effective_call_encrypted;
            }

            let refreshed = CmceCircuit {
                ts_created: self.dltime,
                direction: Direction::Both,
                ts,
                call_id,
                usage,
                circuit_mode: CircuitModeType::TchS,
                comm_type: CommunicationType::P2Mp,
                simplex_duplex: false,
                speech_service: Some(0),
                etee_encrypted: effective_call_encrypted,
            };
            self.signal_umac_circuit_open(queue, &refreshed, self.dltime);

            tracing::info!(
                "U-TX DEMAND: switched call_id={} traffic encryption {} -> {}",
                call_id,
                current_call_encrypted,
                effective_call_encrypted
            );
        }

        let Some((_, dest_addr, _)) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };
        let dest_addr = *dest_addr;

        // ETSI 14.5.2.2.1 b): Send individual D-TX GRANTED (Granted) to requesting MS FIRST
        self.send_d_tx_granted_individual_facch(queue, call_id, requesting_issi, requesting_party, ts);

        // ETSI 14.5.2.2.1 b): Send group D-TX GRANTED (GrantedToOtherUser) to GSSI
        self.send_d_tx_granted_facch(queue, call_id, requesting_issi, dest_addr.ssi, ts);

        // Notify UMAC to resume traffic mode (exit hangtime) for this timeslot.
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                call_id,
                source_issi: requesting_issi,
                dest_gssi: dest_addr.ssi,
                ts,
            }),
        });

        // Notify Brew of speaker change (local MS taking floor)
        if brew::is_brew_gssi_routable(&self.config, dest_addr.ssi) {
            let Some(call) = self.active_calls.get(&call_id) else {
                return;
            };
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                    call_id,
                    source_issi: requesting_issi,
                    dest_gssi: dest_addr.ssi,
                    ts: call.ts,
                }),
            });
        }
    }

    /// Handle U-RELEASE: radio explicitly releases the call
    fn rx_u_release(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            tracing::warn!("CMCE rx_u_release called with unexpected payload");
            return;
        };

        let pdu = match URelease::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-RELEASE {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-RELEASE: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;
        tracing::info!("U-RELEASE: call_id={} cause={}", call_id, pdu.disconnect_cause);
        self.release_call(queue, call_id, DisconnectCause::UserRequestedDisconnection);
    }

    /// Handle U-DISCONNECT: MS requests call disconnection (ETSI 14.5.2.3.1)
    /// Call owner → release entire group call with D-RELEASE (cause=1)
    /// Non-call owner → reject with D-RELEASE cause=8 individually addressed to sender
    fn rx_u_disconnect(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            tracing::warn!("CMCE rx_u_disconnect called with unexpected payload");
            return;
        };
        let sender = prim.received_tetra_address;
        let ul_handle = prim.handle;
        let ul_link_id = prim.link_id;
        let ul_endpoint_id = prim.endpoint_id;

        let pdu = match UDisconnect::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-DISCONNECT {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-DISCONNECT: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;
        let disconnect_cause = pdu.disconnect_cause;

        let Some(call) = self.active_calls.get(&call_id) else {
            tracing::debug!("U-DISCONNECT for unknown call_id={} (likely duplicate)", call_id);
            return;
        };

        let is_call_owner = match (&call.origin, call.local_route) {
            (CallOrigin::Local { caller_addr }, Some(route)) => caller_addr.ssi == sender.ssi || route.addr.ssi == sender.ssi,
            (CallOrigin::Local { caller_addr }, None) => caller_addr.ssi == sender.ssi,
            _ => false,
        };

        if is_call_owner {
            // Call owner: tear down the entire group call
            tracing::info!("U-DISCONNECT: call owner ISSI {} disconnecting call_id={}", sender.ssi, call_id);
            self.release_call(queue, call_id, DisconnectCause::UserRequestedDisconnection);
        } else {
            // Non-call owner: reject with D-RELEASE cause=8 ("Requested service not available")
            // individually addressed back to the sender. The group call continues.
            tracing::info!(
                "U-DISCONNECT: non-call-owner ISSI {} rejected for call_id={} cause={}",
                sender.ssi,
                call_id,
                disconnect_cause
            );

            let d_release = DRelease {
                call_identifier: call_id,
                disconnect_cause: DisconnectCause::RequestedServiceNotAvailable,
                notification_indicator: None,
                facility: None,
                proprietary: None,
            };
            tracing::info!("-> {:?} (to ISSI {})", d_release, sender.ssi);

            let mut sdu = BitBuffer::new_autoexpand(32);
            d_release.to_bitbuf(&mut sdu).expect("Failed to serialize DRelease");
            sdu.seek(0);

            let mut sender_addr = TetraAddress::new(sender.ssi, SsiType::Issi);
            sender_addr.encrypted = sender.encrypted;
            let msg = SapMsg {
                sap: Sap::LcmcSap,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Mle,
                dltime: self.dltime,
                msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                    sdu,
                    handle: ul_handle,
                    endpoint_id: ul_endpoint_id,
                    link_id: ul_link_id,
                    layer2service: 0,
                    pdu_prio: 0,
                    layer2_qos: 0,
                    stealing_permission: false,
                    stealing_repeats_flag: false,
                    chan_alloc: None,
                    main_address: sender_addr,
                    tx_reporter: None,
                }),
            };
            queue.push_back(msg);
        }
    }

    /// Handle incoming CallControl messages from Brew
    pub fn rx_call_control(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        let SapMsgInner::CmceCallControl(call_control) = message.msg else {
            tracing::warn!("CMCE rx_call_control called with unexpected payload");
            return;
        };

        match call_control {
            CallControl::NetworkCallStart {
                brew_uuid,
                source_issi,
                dest_gssi,
                priority,
            } => {
                self.rx_network_call_start(queue, brew_uuid, source_issi, dest_gssi, priority);
            }
            CallControl::NetworkCallEnd { brew_uuid } => {
                self.rx_network_call_end(queue, brew_uuid);
            }
            _ => {
                tracing::warn!("Unexpected CallControl message: {:?}", call_control);
            }
        }
    }

    /// Handle network-initiated group call start
    fn rx_network_call_start(&mut self, queue: &mut MessageQueue, brew_uuid: uuid::Uuid, source_issi: u32, dest_gssi: u32, priority: u8) {
        if !brew::is_brew_gssi_routable(&self.config, dest_gssi) {
            tracing::warn!(
                "CMCE NetworkCallStart for non-routable GSSI={}, ignoring (uuid={}, source_issi={})",
                dest_gssi,
                brew_uuid,
                source_issi
            );
            return;
        }

        if !self.has_listener(dest_gssi) {
            self.drop_group_calls_if_unlistened(queue, dest_gssi);

            if let Some(existing) = self
                .pending_network_starts
                .iter_mut()
                .find(|pending| pending.dest_gssi == dest_gssi || pending.brew_uuid == brew_uuid)
            {
                if existing.brew_uuid != brew_uuid {
                    tracing::info!(
                        "CMCE: replacing deferred network call for gssi={} old_uuid={} new_uuid={}",
                        dest_gssi,
                        existing.brew_uuid,
                        brew_uuid
                    );
                    queue.push_back(SapMsg {
                        sap: Sap::Control,
                        src: TetraEntity::Cmce,
                        dest: TetraEntity::Brew,
                        dltime: self.dltime,
                        msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd {
                            brew_uuid: existing.brew_uuid,
                        }),
                    });
                } else {
                    tracing::debug!(
                        "CMCE: refreshing deferred network call uuid={} gssi={} (still no listeners)",
                        brew_uuid,
                        dest_gssi
                    );
                }

                *existing = PendingNetworkCallStart {
                    brew_uuid,
                    source_issi,
                    dest_gssi,
                    priority,
                    queued_at: self.dltime,
                };
            } else {
                tracing::info!(
                    "CMCE: deferring network call start uuid={} gssi={} speaker={} (no listeners yet; grace={} slots)",
                    brew_uuid,
                    dest_gssi,
                    source_issi,
                    NETWORK_CALL_START_GRACE_FRAMES
                );
                self.pending_network_starts.push(PendingNetworkCallStart {
                    brew_uuid,
                    source_issi,
                    dest_gssi,
                    priority,
                    queued_at: self.dltime,
                });
            }

            // Brew waits for either NetworkCallReady or NetworkCallEnd.
            // We hold this start briefly to avoid affiliate/start races.
            return;
        }

        // Listener is available now. If this UUID was deferred earlier, drop stale pending copy.
        self.pending_network_starts.retain(|pending| pending.brew_uuid != brew_uuid);

        if priority != 0 {
            tracing::debug!(
                "CMCE: network call start uuid={} gssi={} priority={} (priority currently not mapped to D-SETUP call_priority)",
                brew_uuid,
                dest_gssi,
                priority
            );
        }

        // Check if there's an active call for this GSSI (speaker change scenario)
        if let Some((call_id, call)) = self.active_calls.iter_mut().find(|(_, c)| c.dest_gssi == dest_gssi) {
            // Speaker change during active or hangtime
            tracing::info!(
                "CMCE: network call speaker change gssi={} new_speaker={} (was {})",
                dest_gssi,
                source_issi,
                call.source_issi
            );

            call.source_issi = source_issi;
            call.tx_active = true;
            call.hangtime_start = None;
            call.brew_uuid = Some(brew_uuid);

            if let CallOrigin::Network { brew_uuid: old_uuid } = call.origin {
                // Update UUID if different (shouldn't happen but handle it)
                if old_uuid != brew_uuid {
                    tracing::warn!("CMCE: brew_uuid changed during speaker change");
                    call.origin = CallOrigin::Network { brew_uuid };
                }
            }

            // Extract values before mutable borrow ends
            let call_id_val = *call_id;
            let ts = call.ts;
            let usage = call.usage;

            // End the mutable borrow
            let _ = call;

            // Send D-TX GRANTED via FACCH to notify radios of new speaker
            self.send_d_tx_granted_facch(queue, call_id_val, source_issi, dest_gssi, ts);

            // Notify UMAC to resume traffic mode (exit hangtime) for this timeslot.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                    call_id: call_id_val,
                    source_issi,
                    dest_gssi,
                    ts,
                }),
            });

            // Respond to Brew with existing call resources, we already ensured it is cleared for brew
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallReady {
                    brew_uuid,
                    call_id: call_id_val,
                    ts,
                    usage,
                }),
            });
            return;
        }

        // New network call - allocate circuit
        let mut circuit = match {
            let mut state = self.config.state_write();
            self.circuits.allocate_circuit_with_allocator(
                Direction::Both,
                CommunicationType::P2Mp,
                &mut state.timeslot_alloc,
                TimeslotOwner::Cmce,
            )
        } {
            Ok(c) => c.clone(),
            Err(err) => {
                tracing::warn!("CMCE: failed to allocate circuit for network call: {:?}", err);
                return;
            }
        };
        circuit.etee_encrypted = self.cmce_aie_enabled();

        let call_id = circuit.call_id;
        let ts = circuit.ts;
        let usage = circuit.usage;

        tracing::info!(
            "CMCE: starting NEW network call brew_uuid={} gssi={} speaker={} ts={} call_id={}",
            brew_uuid,
            dest_gssi,
            source_issi,
            ts,
            call_id
        );

        // Signal UMAC to open DL and UL circuits
        self.signal_umac_circuit_open(queue, &circuit, self.dltime);

        tracing::debug!(
            "CMCE: sending D-SETUP for NEW call call_id={} gssi={} (network-initiated)",
            call_id,
            dest_gssi
        );

        // Send D-SETUP to group (broadcast on MCCH)
        let mut dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);
        dest_addr.encrypted = circuit.etee_encrypted;
        let d_setup = DSetup {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: false,
            simplex_duplex_selection: false, // Simplex
            basic_service_information: BasicServiceInformation {
                circuit_mode_type: CircuitModeType::TchS,
                // CMCE basic-service encryption is service-level and distinct from
                // SC2/AIE transport encryption managed at lower layers.
                encryption_flag: false,
                communication_type: CommunicationType::P2Mp,
                slots_per_frame: None,
                speech_service: Some(0),
            },
            transmission_grant: TransmissionGrant::GrantedToOtherUser,
            transmission_request_permission: false,
            call_priority: 0,
            notification_indicator: None,
            temporary_address: None,
            calling_party_address_ssi: Some(source_issi),
            calling_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        // Cache for late-entry re-sends. Receipt starts as None so the CircuitMgr-triggered
        // backup send (within D_SETUP_REPEATS frames) is not throttled by this initial send.
        // The first re-send via tick_start will create a tracked receipt.
        self.cached_setups.insert(call_id, (d_setup, dest_addr, None));
        let (d_setup_ref, _, _) = self.cached_setups.get(&call_id).unwrap();

        let (setup_sdu, setup_chan_alloc) = Self::build_d_setup_prim(d_setup_ref, usage, ts, UlDlAssignment::Both);
        let setup_msg = Self::build_sapmsg(setup_sdu, Some(setup_chan_alloc), self.dltime, dest_addr, None);
        queue.push_back(setup_msg);

        // Send D-CONNECT to group
        let d_connect = DConnect {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: false,
            simplex_duplex_selection: false, // Simplex
            transmission_grant: TransmissionGrant::GrantedToOtherUser,
            transmission_request_permission: false,
            call_ownership: false,
            call_priority: None,
            basic_service_information: None,
            temporary_address: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        let mut connect_sdu = BitBuffer::new_autoexpand(30);
        d_connect.to_bitbuf(&mut connect_sdu).expect("Failed to serialize DConnect");
        connect_sdu.seek(0);

        let connect_msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: self.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: connect_sdu,
                handle: 0, // Broadcast to group, no specific handle
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: None, // Already sent in D-SETUP
                main_address: dest_addr,
                tx_reporter: None,
            }),
        };
        queue.push_back(connect_msg);

        // Track the active call
        self.active_calls.insert(
            call_id,
            ActiveCall {
                origin: CallOrigin::Network { brew_uuid },
                local_route: None,
                dest_gssi,
                source_issi,
                ts,
                usage,
                tx_active: true,
                hangtime_start: None,
                brew_uuid: Some(brew_uuid),
                air_interface_encrypted: circuit.etee_encrypted,
            },
        );

        // Respond to Brew with allocated resources, we already ensured it is cleared for brew
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Brew,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallReady {
                brew_uuid,
                call_id,
                ts,
                usage,
            }),
        });
    }

    /// Handle network call end request
    fn rx_network_call_end(&mut self, queue: &mut MessageQueue, brew_uuid: uuid::Uuid) {
        if let Some(idx) = self
            .pending_network_starts
            .iter()
            .position(|pending| pending.brew_uuid == brew_uuid)
        {
            let pending = self.pending_network_starts.remove(idx);
            tracing::info!(
                "CMCE: canceled deferred network call uuid={} gssi={} (network end before listeners)",
                pending.brew_uuid,
                pending.dest_gssi
            );
            return;
        }
        // Find the call by brew_uuid field (works for both Local and Network origin calls)
        let Some((call_id, call)) = self
            .active_calls
            .iter()
            .find(|(_, c)| c.brew_uuid == Some(brew_uuid))
            .map(|(id, c)| (*id, c.clone()))
        else {
            tracing::debug!("CMCE: network call end for unknown brew_uuid={}", brew_uuid);
            return;
        };

        tracing::info!(
            "CMCE: network call ended brew_uuid={} call_id={} gssi={}",
            brew_uuid,
            call_id,
            call.dest_gssi
        );

        // If currently transmitting, enter hangtime instead of immediate release
        let tx_active = call.tx_active;
        let dest_gssi = call.dest_gssi;
        let ts = call.ts;

        if tx_active {
            if let Some(active_call) = self.active_calls.get_mut(&call_id) {
                active_call.tx_active = false;
                active_call.hangtime_start = Some(self.dltime);
                active_call.brew_uuid = None;
            }
            // Send D-TX CEASED via FACCH
            self.send_d_tx_ceased_facch(queue, call_id, dest_gssi, ts);

            // Notify UMAC to enter hangtime signalling mode on this traffic timeslot.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
            });
        } else {
            // Already in hangtime or idle, release immediately
            self.release_call(queue, call_id, DisconnectCause::SwmiRequestedDisconnection);
        }
    }

    /// Send D-TX GRANTED via FACCH stealing
    fn send_d_tx_granted_facch(&mut self, queue: &mut MessageQueue, call_id: u16, source_issi: u32, dest_gssi: u32, ts: u8) {
        let pdu = DTxGranted {
            call_identifier: call_id,
            transmission_grant: TransmissionGrant::GrantedToOtherUser.into_raw() as u8,
            transmission_request_permission: false,
            encryption_control: self.is_call_air_encrypted(call_id),
            reserved: false,
            notification_indicator: None,
            transmitting_party_type_identifier: Some(1), // SSI
            transmitting_party_address_ssi: Some(source_issi as u64),
            transmitting_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::debug!("-> D-TX GRANTED (FACCH) {:?}", pdu);
        let mut sdu = BitBuffer::new_autoexpand(30);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DTxGranted");
        sdu.seek(0);

        let mut dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);
        dest_addr.encrypted = self.is_call_air_encrypted(call_id);
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, dest_addr, ts);
        queue.push_back(msg);
    }

    /// Send D-TX CEASED via FACCH stealing
    fn send_d_tx_ceased_facch(&mut self, queue: &mut MessageQueue, call_id: u16, dest_gssi: u32, ts: u8) {
        let pdu = DTxCeased {
            call_identifier: call_id,
            transmission_request_permission: false,
            notification_indicator: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::debug!("-> D-TX CEASED (FACCH) {:?}", pdu);
        let mut sdu = BitBuffer::new_autoexpand(30);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DTxCeased");
        sdu.seek(0);

        let mut dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);
        dest_addr.encrypted = self.is_call_air_encrypted(call_id);
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, dest_addr, ts);
        queue.push_back(msg);
    }
}
