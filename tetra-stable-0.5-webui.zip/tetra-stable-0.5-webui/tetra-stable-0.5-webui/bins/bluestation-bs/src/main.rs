use clap::Parser;

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;
use std::time::Duration;

use tetra_config::bluestation::{PhyBackend, SharedConfig, StackMode, parsing};
use tetra_core::{TdmaTime, debug};
use tetra_entities::MessageRouter;
use tetra_entities::brew::entity::BrewEntity;
use tetra_entities::{
    cmce::cmce_bs::CmceBs,
    llc::llc_bs_ms::Llc,
    lmac::lmac_bs::LmacBs,
    mle::mle_bs_ms::Mle,
    mm::mm_bs::MmBs,
    phy::{components::soapy_dev::RxTxDevSoapySdr, phy_bs::PhyBs},
    sndcp::sndcp_bs::Sndcp,
    umac::umac_bs::UmacBs,
};

/// Load configuration file
fn load_config_from_toml(cfg_path: &str) -> SharedConfig {
    match parsing::from_file(cfg_path) {
        Ok(c) => c,
        Err(e) => {
            println!("Failed to load configuration from {}: {}", cfg_path, e);
            std::process::exit(1);
        }
    }
}

/// Start base station stack
fn build_bs_stack(cfg: &mut SharedConfig) -> MessageRouter {
    let mut router = MessageRouter::new(cfg.clone());

    // Add suitable Phy component based on PhyIo type
    match cfg.config().phy_io.backend {
        PhyBackend::SoapySdr => {
            let rxdev = RxTxDevSoapySdr::new(cfg);
            let phy = PhyBs::new(cfg.clone(), rxdev);
            router.register_entity(Box::new(phy));
        }
        _ => {
            panic!("Unsupported PhyIo type: {:?}", cfg.config().phy_io.backend);
        }
    }

    // Add remaining components
    let lmac = LmacBs::new(cfg.clone());
    let umac = UmacBs::new(cfg.clone());
    let llc = Llc::new(cfg.clone());
    let mle = Mle::new(cfg.clone());
    let mm = MmBs::new(cfg.clone());
    let sndcp = Sndcp::new(cfg.clone());
    let cmce = CmceBs::new(cfg.clone());
    router.register_entity(Box::new(lmac));
    router.register_entity(Box::new(umac));
    router.register_entity(Box::new(llc));
    router.register_entity(Box::new(mle));
    router.register_entity(Box::new(mm));
    router.register_entity(Box::new(sndcp));
    router.register_entity(Box::new(cmce));

    // Register Brew entity if enabled
    if cfg.config().brew.is_some() {
        let brew_entity = BrewEntity::new(cfg.clone());
        router.register_entity(Box::new(brew_entity));
        eprintln!(" -> Brew/TetraPack integration enabled");
    }

    // Init network time
    router.set_dl_time(TdmaTime::default());

    router
}

#[derive(Parser, Debug)]
#[command(
    author,
    version,
    about = "TETRA BlueStation Stack",
    long_about = "Runs the TETRA BlueStation stack using the provided TOML configuration files"
)]

struct Args {
    /// Config file (required)
    #[arg(help = "TOML config with network/cell parameters")]
    config: String,

    /// Web UI bind address (empty string disables web UI)
    #[arg(long, default_value = "127.0.0.1:8787")]
    web_ui_bind: String,
}

const WEB_UI_HTML: &str = r#"<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tetra BlueStation Stats</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 0; padding: 24px; background: #f3f4f6; color: #111827; }
    h1 { margin: 0 0 8px; font-size: 26px; }
    .meta { color: #4b5563; margin-bottom: 20px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; }
    .card { background: #fff; border-radius: 10px; padding: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.08); }
    .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.05em; }
    .value { font-size: 32px; font-weight: 700; margin-top: 6px; }
    .list { margin-top: 16px; background: #fff; border-radius: 10px; padding: 14px; box-shadow: 0 1px 2px rgba(0,0,0,0.08); }
    .list h2 { margin: 0 0 8px; font-size: 16px; }
    code { background: #e5e7eb; padding: 2px 5px; border-radius: 4px; }
  </style>
</head>
<body>
  <h1>BlueStation Live Stats</h1>
  <div class="meta">Auto-refresh every second</div>
  <div class="grid">
    <div class="card"><div class="label">Registered ISSIs</div><div class="value" id="registered_issi_count">0</div></div>
    <div class="card"><div class="label">Active Group Calls</div><div class="value" id="active_group_calls">0</div></div>
    <div class="card"><div class="label">Active Individual Calls</div><div class="value" id="active_individual_calls">0</div></div>
    <div class="card"><div class="label">Groups With Listeners</div><div class="value" id="groups_with_listeners">0</div></div>
    <div class="card"><div class="label">Affiliations</div><div class="value" id="affiliated_group_links">0</div></div>
    <div class="card"><div class="label">Total Group Call Setups</div><div class="value" id="total_group_call_setups">0</div></div>
    <div class="card"><div class="label">Total Individual Call Setups</div><div class="value" id="total_individual_call_setups">0</div></div>
  </div>
  <div class="list">
    <h2>Registered ISSI List</h2>
    <div id="registered_issis"><code>none</code></div>
  </div>
  <div class="meta" id="updated">Last update: n/a</div>
  <script>
    function setText(id, value) { document.getElementById(id).textContent = value; }
    async function refresh() {
      try {
        const res = await fetch('/api/stats', { cache: 'no-store' });
        const s = await res.json();
        setText('registered_issi_count', s.registered_issi_count ?? 0);
        setText('active_group_calls', s.active_group_calls ?? 0);
        setText('active_individual_calls', s.active_individual_calls ?? 0);
        setText('groups_with_listeners', s.groups_with_listeners ?? 0);
        setText('affiliated_group_links', s.affiliated_group_links ?? 0);
        setText('total_group_call_setups', s.total_group_call_setups ?? 0);
        setText('total_individual_call_setups', s.total_individual_call_setups ?? 0);
        const issis = Array.isArray(s.registered_issis) ? s.registered_issis : [];
        document.getElementById('registered_issis').innerHTML = issis.length ? issis.map(v => `<code>${v}</code>`).join(' ') : '<code>none</code>';
        if (s.updated_unix_ms) {
          setText('updated', 'Last update: ' + new Date(s.updated_unix_ms).toLocaleString());
        }
      } catch (e) {
        setText('updated', 'Last update: error fetching /api/stats');
      }
    }
    refresh();
    setInterval(refresh, 1000);
  </script>
</body>
</html>
"#;

fn write_http_response(stream: &mut TcpStream, status: &str, content_type: &str, body: &str) {
    let response = format!(
        "HTTP/1.1 {status}\r\nContent-Type: {content_type}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n{}",
        body.len(),
        body
    );
    let _ = stream.write_all(response.as_bytes());
}

fn handle_http_client(mut stream: TcpStream) {
    let mut buf = [0_u8; 4096];
    let n = match stream.read(&mut buf) {
        Ok(n) if n > 0 => n,
        _ => return,
    };
    let req = String::from_utf8_lossy(&buf[..n]);
    let first_line = req.lines().next().unwrap_or("");
    let path = first_line.split_whitespace().nth(1).unwrap_or("/");

    match path {
        "/" => write_http_response(&mut stream, "200 OK", "text/html; charset=utf-8", WEB_UI_HTML),
        "/api/stats" => {
            let body = tetra_entities::webui_stats::snapshot_json();
            write_http_response(&mut stream, "200 OK", "application/json; charset=utf-8", &body);
        }
        "/healthz" => write_http_response(&mut stream, "200 OK", "text/plain; charset=utf-8", "ok"),
        _ => write_http_response(&mut stream, "404 Not Found", "text/plain; charset=utf-8", "not found"),
    }
}

fn start_web_ui_server(bind_addr: String, running: Arc<AtomicBool>) -> Option<thread::JoinHandle<()>> {
    if bind_addr.trim().is_empty() {
        eprintln!(" -> Web UI disabled");
        return None;
    }

    let listener = match TcpListener::bind(&bind_addr) {
        Ok(listener) => listener,
        Err(err) => {
            eprintln!(" -> Web UI failed to bind on {bind_addr}: {err}");
            return None;
        }
    };

    if let Err(err) = listener.set_nonblocking(true) {
        eprintln!(" -> Web UI failed to set non-blocking mode on {bind_addr}: {err}");
        return None;
    }

    eprintln!(" -> Web UI available at http://{bind_addr}/");

    Some(thread::spawn(move || {
        while running.load(Ordering::SeqCst) {
            match listener.accept() {
                Ok((stream, _)) => handle_http_client(stream),
                Err(err) if err.kind() == std::io::ErrorKind::WouldBlock => thread::sleep(Duration::from_millis(200)),
                Err(_) => thread::sleep(Duration::from_millis(200)),
            }
        }
    }))
}

fn main() {
    eprintln!("░▀█▀░█▀▀░▀█▀░█▀▄░█▀█░░░░░█▀▄░█░░░█░█░█▀▀░█▀▀░▀█▀░█▀█░▀█▀░▀█▀░█▀█░█▀█");
    eprintln!("░░█░░█▀▀░░█░░█▀▄░█▀█░▄▄▄░█▀▄░█░░░█░█░█▀▀░▀▀█░░█░░█▀█░░█░░░█░░█░█░█░█");
    eprintln!("░░▀░░▀▀▀░░▀░░▀░▀░▀░▀░░░░░▀▀░░▀▀▀░▀▀▀░▀▀▀░▀▀▀░░▀░░▀░▀░░▀░░▀▀▀░▀▀▀░▀░▀\n");
    eprintln!("    Wouter Bokslag / Midnight Blue");
    eprintln!(" -> https://github.com/MidnightBlueLabs/tetra-bluestation");
    eprintln!(" -> https://midnightblue.nl\n");

    let args = Args::parse();
    let mut cfg = load_config_from_toml(&args.config);
    let _log_guard = debug::setup_logging_default(cfg.config().debug_log.clone());

    let mut router = match cfg.config().stack_mode {
        StackMode::Mon => {
            unimplemented!("Monitor mode is not implemented");
        }
        StackMode::Ms => {
            unimplemented!("MS mode is not implemented");
        }
        StackMode::Bs => build_bs_stack(&mut cfg),
    };

    // Set up Ctrl+C handler for graceful shutdown
    let running = Arc::new(AtomicBool::new(true));
    let r = running.clone();
    ctrlc::set_handler(move || {
        r.store(false, Ordering::SeqCst);
    })
    .expect("failed to set Ctrl+C handler");

    let web_ui_handle = start_web_ui_server(args.web_ui_bind.clone(), running.clone());

    router.run_stack(None, Some(running));
    if let Some(handle) = web_ui_handle {
        let _ = handle.join();
    }
    // router drops here → entities are dropped → BrewEntity::Drop fires teardown
}
