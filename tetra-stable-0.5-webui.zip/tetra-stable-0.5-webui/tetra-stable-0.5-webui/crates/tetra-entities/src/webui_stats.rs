use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

use serde::Serialize;

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiStatsSnapshot {
    pub registered_issi_count: u64,
    pub registered_issis: Vec<u32>,
    pub affiliated_group_links: u64,
    pub groups_with_listeners: u64,
    pub active_group_calls: u64,
    pub active_individual_calls: u64,
    pub total_group_call_setups: u64,
    pub total_individual_call_setups: u64,
    pub updated_unix_ms: u64,
}

#[derive(Default)]
struct WebUiStatsState {
    snapshot: WebUiStatsSnapshot,
}

fn state() -> &'static Mutex<WebUiStatsState> {
    static STATE: OnceLock<Mutex<WebUiStatsState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(WebUiStatsState::default()))
}

fn now_unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

pub fn reset() {
    if let Ok(mut s) = state().lock() {
        s.snapshot = WebUiStatsSnapshot {
            updated_unix_ms: now_unix_ms(),
            ..WebUiStatsSnapshot::default()
        };
    }
}

#[allow(clippy::too_many_arguments)]
pub fn publish(
    mut registered_issis: Vec<u32>,
    affiliated_group_links: usize,
    groups_with_listeners: usize,
    active_group_calls: usize,
    active_individual_calls: usize,
    total_group_call_setups: u64,
    total_individual_call_setups: u64,
) {
    registered_issis.sort_unstable();
    registered_issis.dedup();

    let snapshot = WebUiStatsSnapshot {
        registered_issi_count: registered_issis.len() as u64,
        registered_issis,
        affiliated_group_links: affiliated_group_links as u64,
        groups_with_listeners: groups_with_listeners as u64,
        active_group_calls: active_group_calls as u64,
        active_individual_calls: active_individual_calls as u64,
        total_group_call_setups,
        total_individual_call_setups,
        updated_unix_ms: now_unix_ms(),
    };

    if let Ok(mut s) = state().lock() {
        s.snapshot = snapshot;
    }
}

pub fn snapshot() -> WebUiStatsSnapshot {
    if let Ok(s) = state().lock() {
        return s.snapshot.clone();
    }
    WebUiStatsSnapshot {
        updated_unix_ms: now_unix_ms(),
        ..WebUiStatsSnapshot::default()
    }
}

pub fn snapshot_json() -> String {
    match serde_json::to_string(&snapshot()) {
        Ok(s) => s,
        Err(_) => "{}".to_string(),
    }
}
