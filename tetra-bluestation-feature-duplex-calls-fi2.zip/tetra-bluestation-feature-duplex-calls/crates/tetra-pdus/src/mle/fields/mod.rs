pub mod bs_service_details;
