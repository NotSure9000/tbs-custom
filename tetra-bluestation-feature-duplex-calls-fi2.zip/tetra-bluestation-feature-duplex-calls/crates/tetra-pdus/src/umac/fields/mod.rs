// PDU fields
pub mod basic_slotgrant;
pub mod channel_allocation;
pub mod sysinfo_default_def_for_access_code_a;
pub mod sysinfo_ext_services;
pub mod ts_common_frames;

pub type EventLabel = u16;
