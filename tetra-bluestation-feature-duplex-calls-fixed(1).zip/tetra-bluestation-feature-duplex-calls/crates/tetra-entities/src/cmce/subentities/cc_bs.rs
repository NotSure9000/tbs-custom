use std::collections::{HashMap, HashSet};

use tetra_config::bluestation::SharedConfig;
use tetra_core::{BitBuffer, Direction, Sap, SsiType, TdmaTime, TetraAddress, tetra_entities::TetraEntity, unimplemented_log};
use tetra_core::{TimeslotOwner, TxReporter};
use tetra_pdus::cmce::enums::disconnect_cause::DisconnectCause;
use tetra_pdus::cmce::{
    enums::{
        call_timeout::CallTimeout, call_timeout_setup_phase::CallTimeoutSetupPhase, cmce_pdu_type_ul::CmcePduTypeUl,
        transmission_grant::TransmissionGrant,
    },
    fields::basic_service_information::BasicServiceInformation,
    pdus::{
        d_alert::DAlert, d_call_proceeding::DCallProceeding, d_connect::DConnect, d_connect_acknowledge::DConnectAcknowledge,
        d_disconnect::DDisconnect, d_release::DRelease, d_setup::DSetup, d_tx_ceased::DTxCeased, d_tx_granted::DTxGranted, u_alert::UAlert,
        u_connect::UConnect, u_disconnect::UDisconnect, u_release::URelease, u_setup::USetup, u_tx_ceased::UTxCeased,
        u_tx_demand::UTxDemand,
    },
    structs::cmce_circuit::CmceCircuit,
};
use tetra_saps::{
    SapMsg, SapMsgInner,
    control::{
        brew::{BrewSubscriberAction, MmSubscriberUpdate},
        call_control::{CallControl, Circuit},
        enums::{circuit_mode_type::CircuitModeType, communication_type::CommunicationType},
    },
    lcmc::{
        LcmcMleUnitdataReq,
        enums::{alloc_type::ChanAllocType, ul_dl_assignment::UlDlAssignment},
        fields::chan_alloc_req::CmceChanAllocReq,
    },
};

use crate::brew;
use crate::{
    MessageQueue,
    cmce::components::circuit_mgr::{CircuitMgr, CircuitMgrCmd},
};

struct CachedSetup {
    pdu: DSetup,
    dest_addr: TetraAddress,
    resend: bool,
}

/// Clause 11 Call Control CMCE sub-entity
pub struct CcBsSubentity {
    config: SharedConfig,
    dltime: TdmaTime,
    /// Cached D-SETUP PDUs for late-entry re-sends: call_id -> cached setup
    cached_setups: HashMap<u16, CachedSetup>,
    circuits: CircuitMgr,
    /// Active group calls: call_id -> call info
    active_calls: HashMap<u16, ActiveCall>,
    /// Active or pending individual calls (P2P)
    individual_calls: HashMap<u16, IndividualCall>,
    /// Registered subscriber groups (ISSI -> set of GSSIs)
    subscriber_groups: HashMap<u32, HashSet<u32>>,
    /// Listener counts per GSSI
    group_listeners: HashMap<u32, usize>,
}

/// Origin of a group call
#[derive(Clone)]
enum CallOrigin {
    /// Local MS-initiated call, needs MLE routing for individual addressing
    Local {
        caller_addr: TetraAddress, // For D-CALL-PROCEEDING, D-CONNECT routing
    },
    /// Network-initiated call from TetraPack/Brew
    Network {
        brew_uuid: uuid::Uuid, // For Brew tracking
    },
}

/// Tracks an active group call (local or network-initiated)
#[derive(Clone)]
struct ActiveCall {
    origin: CallOrigin,
    dest_gssi: u32,   // Destination group
    source_issi: u32, // Current speaker
    ts: u8,
    usage: u8,
    /// True if someone is currently transmitting
    tx_active: bool,
    /// When the current floor grant began (i.e. when tx_active was last set true).
    /// Used to detect a transmitter that went off-air without sending U-TX-CEASED —
    /// if tx_active stays true beyond TX_WATCHDOG_FRAMES the BS force-releases the
    /// floor, mirroring ETSI EN 300 392-7 timer T3.40 (max transmission time, ~30 s).
    tx_grant_time: TdmaTime,
    /// When PTT was released (for hangtime). None if transmitting.
    hangtime_start: Option<TdmaTime>,
    /// Brew session UUID — set when a network speaker is active on this call,
    /// regardless of call origin. Cleared when the network speaker ends.
    brew_uuid: Option<uuid::Uuid>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum IndividualCallState {
    Setup,
    Active,
}

#[derive(Clone)]
struct IndividualCall {
    calling_addr: TetraAddress,
    called_addr: TetraAddress,
    calling_handle: u32,
    calling_link_id: u32,
    calling_endpoint_id: u32,
    called_handle: Option<u32>,
    called_link_id: Option<u32>,
    called_endpoint_id: Option<u32>,
    calling_ts: u8,
    called_ts: u8,
    calling_usage: u8,
    called_usage: u8,
    simplex_duplex: bool,
    state: IndividualCallState,
    alert_sent: bool,
}

impl CcBsSubentity {
    pub fn new(config: SharedConfig) -> Self {
        CcBsSubentity {
            config,
            dltime: TdmaTime::default(),
            cached_setups: HashMap::new(),
            circuits: CircuitMgr::new(),
            active_calls: HashMap::new(),
            individual_calls: HashMap::new(),
            subscriber_groups: HashMap::new(),
            group_listeners: HashMap::new(),
        }
    }

    pub fn set_config(&mut self, config: SharedConfig) {
        self.config = config;
    }

    fn build_d_setup_prim(pdu: &DSetup, usage: u8, ts: u8, ul_dl: UlDlAssignment) -> (BitBuffer, CmceChanAllocReq) {
        tracing::debug!("-> {:?}", pdu);

        let mut sdu = BitBuffer::new_autoexpand(80);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DSetup");
        sdu.seek(0);

        // Construct ChanAlloc descriptor for the allocated timeslot
        let mut timeslots = [false; 4];
        timeslots[ts as usize - 1] = true;
        let chan_alloc = CmceChanAllocReq {
            usage: Some(usage),
            alloc_type: ChanAllocType::Replace,
            carrier: None,
            timeslots,
            ul_dl_assigned: ul_dl,
        };
        (sdu, chan_alloc)
    }

    fn build_sapmsg(
        sdu: BitBuffer,
        chan_alloc: Option<CmceChanAllocReq>,
        dltime: TdmaTime,
        address: TetraAddress,
        reporter: Option<TxReporter>,
    ) -> SapMsg {
        // Construct prim
        SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: 0,
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc,
                main_address: address,
                tx_reporter: reporter,
            }),
        }
    }

    fn build_sapmsg_direct(sdu: BitBuffer, dltime: TdmaTime, address: TetraAddress, handle: u32, link_id: u32, endpoint_id: u32) -> SapMsg {
        SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle,
                endpoint_id,
                link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: None,
                main_address: address,
                tx_reporter: None,
            }),
        }
    }

    fn build_sapmsg_stealing(sdu: BitBuffer, dltime: TdmaTime, address: TetraAddress, ts: u8, usage: Option<u8>) -> SapMsg {
        // For FACCH stealing on traffic channel, must specify target timeslot
        let mut timeslots = [false; 4];
        timeslots[(ts - 1) as usize] = true;
        let chan_alloc = CmceChanAllocReq {
            usage,
            carrier: None,
            timeslots,
            alloc_type: ChanAllocType::Replace,
            ul_dl_assigned: UlDlAssignment::Both,
        };

        SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: 0,
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: true,
                stealing_repeats_flag: false,
                chan_alloc: Some(chan_alloc),
                main_address: address,
                tx_reporter: None,
            }),
        }
    }

    fn build_d_release(call_identifier: u16, disconnect_cause: DisconnectCause) -> BitBuffer {
        let pdu = DRelease {
            call_identifier,
            disconnect_cause,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };
        tracing::info!("-> {:?}", pdu);

        let mut sdu = BitBuffer::new_autoexpand(32);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DRelease");
        sdu.seek(0);
        sdu
    }

    fn build_d_release_from_d_setup(d_setup_pdu: &DSetup, disconnect_cause: DisconnectCause) -> BitBuffer {
        Self::build_d_release(d_setup_pdu.call_identifier, disconnect_cause)
    }

    fn has_listener(&self, gssi: u32) -> bool {
        self.group_listeners.get(&gssi).copied().unwrap_or(0) > 0
    }

    fn inc_group_listener(&mut self, gssi: u32) {
        let entry = self.group_listeners.entry(gssi).or_insert(0);
        *entry += 1;
    }

    fn dec_group_listener(&mut self, gssi: u32) {
        if let Some(entry) = self.group_listeners.get_mut(&gssi) {
            if *entry <= 1 {
                self.group_listeners.remove(&gssi);
            } else {
                *entry -= 1;
            }
        }
    }

    fn drop_group_calls_if_unlistened(&mut self, queue: &mut MessageQueue, gssi: u32) {
        if self.has_listener(gssi) {
            return;
        }

        let to_drop: Vec<(u16, CallOrigin)> = self
            .active_calls
            .iter()
            .filter(|(_, call)| call.dest_gssi == gssi)
            .map(|(call_id, call)| (*call_id, call.origin.clone()))
            .collect();

        for (call_id, origin) in to_drop {
            tracing::info!("CMCE: dropping call_id={} gssi={} (no listeners)", call_id, gssi);
            if let CallOrigin::Network { brew_uuid } = origin {
                if brew::is_brew_gssi_routable(&self.config, gssi) {
                    queue.push_back(SapMsg {
                        sap: Sap::Control,
                        src: TetraEntity::Cmce,
                        dest: TetraEntity::Brew,
                        dltime: self.dltime,
                        msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd { brew_uuid }),
                    });
                };
            };
            self.release_group_call(queue, call_id, DisconnectCause::SwmiRequestedDisconnection);
        }
    }

    pub fn handle_subscriber_update(&mut self, queue: &mut MessageQueue, update: MmSubscriberUpdate) {
        let issi = update.issi;
        let groups = update.groups;

        match update.action {
            BrewSubscriberAction::Register => {
                let known = self.subscriber_groups.contains_key(&issi);
                self.subscriber_groups.entry(issi).or_insert_with(HashSet::new);
                tracing::info!("CMCE: subscriber register issi={} known={}", issi, known);
            }
            BrewSubscriberAction::Deregister => {
                if let Some(existing) = self.subscriber_groups.remove(&issi) {
                    for gssi in existing {
                        self.dec_group_listener(gssi);
                        self.drop_group_calls_if_unlistened(queue, gssi);
                    }
                }
                tracing::info!("CMCE: subscriber deregister issi={}", issi);
            }
            BrewSubscriberAction::Affiliate => {
                let mut new_groups = Vec::new();
                {
                    let entry = self.subscriber_groups.entry(issi).or_insert_with(HashSet::new);
                    for gssi in groups {
                        if entry.insert(gssi) {
                            new_groups.push(gssi);
                        }
                    }
                }
                for gssi in &new_groups {
                    self.inc_group_listener(*gssi);
                }

                if new_groups.is_empty() {
                    tracing::debug!("CMCE: affiliate ignored (no new groups) issi={}", issi);
                } else {
                    tracing::info!("CMCE: subscriber affiliate issi={} groups={:?}", issi, new_groups);
                }
            }
            BrewSubscriberAction::Deaffiliate => {
                let mut removed_groups = Vec::new();
                let mut known_issi = false;
                if let Some(entry) = self.subscriber_groups.get_mut(&issi) {
                    known_issi = true;
                    for gssi in groups {
                        if entry.remove(&gssi) {
                            removed_groups.push(gssi);
                        }
                    }
                } else {
                    removed_groups = groups;
                }
                if known_issi {
                    for gssi in &removed_groups {
                        self.dec_group_listener(*gssi);
                    }
                }

                if removed_groups.is_empty() {
                    tracing::debug!("CMCE: deaffiliate ignored (no matching groups) issi={}", issi);
                } else {
                    tracing::info!("CMCE: subscriber deaffiliate issi={} groups={:?}", issi, removed_groups);
                    for gssi in &removed_groups {
                        self.drop_group_calls_if_unlistened(queue, *gssi);
                    }
                }
            }
        }
    }

    fn send_d_call_proceeding(
        &mut self,
        queue: &mut MessageQueue,
        message: &SapMsg,
        pdu_request: &USetup,
        call_id: u16,
        setup_timeout: CallTimeoutSetupPhase,
        hook_method_selection: bool,
    ) {
        tracing::trace!("send_d_call_proceeding");

        let SapMsgInner::LcmcMleUnitdataInd(prim) = &message.msg else {
            panic!()
        };

        let pdu_response = DCallProceeding {
            call_identifier: call_id,
            call_time_out_set_up_phase: setup_timeout,
            hook_method_selection,
            simplex_duplex_selection: pdu_request.simplex_duplex_selection,
            basic_service_information: None, // Only needed if different from requested
            call_status: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(25);
        pdu_response.to_bitbuf(&mut sdu).expect("Failed to serialize DCallProceeding");
        sdu.seek(0);
        tracing::debug!("send_d_call_proceeding: -> {:?} sdu {}", pdu_response, sdu.dump_bin());

        let msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: prim.handle,
                endpoint_id: prim.endpoint_id,
                link_id: prim.link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,

                chan_alloc: None,
                main_address: prim.received_tetra_address,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_alert_individual(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        call_id: u16,
        simplex_duplex: bool,
        calling_addr: TetraAddress,
        calling_handle: u32,
        calling_link_id: u32,
        calling_endpoint_id: u32,
        setup_timeout: CallTimeoutSetupPhase,
    ) {
        let d_alert = DAlert {
            call_identifier: call_id,
            call_time_out_set_up_phase: setup_timeout.into_raw() as u8,
            reserved: true, // per spec note: set to 1 for backwards compatibility
            simplex_duplex_selection: simplex_duplex,
            call_queued: false,
            basic_service_information: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_alert);
        let mut sdu = BitBuffer::new_autoexpand(32);
        d_alert.to_bitbuf(&mut sdu).expect("Failed to serialize DAlert");
        sdu.seek(0);

        let msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu,
                handle: calling_handle,
                endpoint_id: calling_endpoint_id,
                link_id: calling_link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: None,
                main_address: calling_addr,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_disconnect_individual(
        &mut self,
        queue: &mut MessageQueue,
        call_id: u16,
        call_snapshot: &IndividualCall,
        sender: TetraAddress,
        disconnect_cause: DisconnectCause,
    ) {
        let target_addr = if sender.ssi == call_snapshot.calling_addr.ssi {
            Some(call_snapshot.called_addr)
        } else if sender.ssi == call_snapshot.called_addr.ssi {
            Some(call_snapshot.calling_addr)
        } else {
            tracing::warn!(
                "U-DISCONNECT/U-RELEASE (individual) call_id={} from unexpected ISSI {} (calling {}, called {})",
                call_id,
                sender.ssi,
                call_snapshot.calling_addr.ssi,
                call_snapshot.called_addr.ssi
            );
            None
        };

        let Some(target_addr) = target_addr else {
            return;
        };

        let target_ts = if target_addr.ssi == call_snapshot.calling_addr.ssi {
            call_snapshot.calling_ts
        } else {
            call_snapshot.called_ts
        };

        let d_disconnect = DDisconnect {
            call_identifier: call_id,
            disconnect_cause,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };
        tracing::info!("-> {:?} (to ISSI {})", d_disconnect, target_addr.ssi);

        let mut sdu = BitBuffer::new_autoexpand(32);
        d_disconnect.to_bitbuf(&mut sdu).expect("Failed to serialize DDisconnect");
        sdu.seek(0);

        let msg = if call_snapshot.state == IndividualCallState::Active {
            let usage = if target_addr.ssi == call_snapshot.calling_addr.ssi {
                Some(call_snapshot.calling_usage)
            } else {
                Some(call_snapshot.called_usage)
            };
            Self::build_sapmsg_stealing(sdu, self.dltime, target_addr, target_ts, usage)
        } else if target_addr.ssi == call_snapshot.calling_addr.ssi {
            Self::build_sapmsg_direct(
                sdu,
                self.dltime,
                target_addr,
                call_snapshot.calling_handle,
                call_snapshot.calling_link_id,
                call_snapshot.calling_endpoint_id,
            )
        } else if let (Some(handle), Some(link_id), Some(endpoint_id)) = (
            call_snapshot.called_handle,
            call_snapshot.called_link_id,
            call_snapshot.called_endpoint_id,
        ) {
            Self::build_sapmsg_direct(sdu, self.dltime, target_addr, handle, link_id, endpoint_id)
        } else {
            Self::build_sapmsg(sdu, None, self.dltime, target_addr, None)
        };
        queue.push_back(msg);
    }

    fn signal_umac_circuit_open(queue: &mut MessageQueue, call: &CmceCircuit, dltime: TdmaTime, peer_ts: Option<u8>) {
        let circuit = Circuit {
            direction: call.direction,
            ts: call.ts,
            peer_ts,
            usage: call.usage,
            circuit_mode: call.circuit_mode,
            speech_service: call.speech_service,
            etee_encrypted: call.etee_encrypted,
        };
        let cmd = SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::Open(circuit)),
        };
        queue.push_back(cmd);
    }

    fn signal_umac_circuit_close(queue: &mut MessageQueue, circuit: CmceCircuit, dltime: TdmaTime) {
        let cmd = SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::Close(circuit.direction, circuit.ts)),
        };
        queue.push_back(cmd);
    }

    fn rx_u_setup(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_setup: {:?}", message);
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };
        let calling_party = prim.received_tetra_address;

        let pdu = match USetup::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-SETUP {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-SETUP: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request
        if !Self::feature_check_u_setup(&pdu) {
            tracing::error!("Unsupported critical features in USetup");
            return;
        }

        // Handle P2P (individual) call setup separately
        if pdu.basic_service_information.communication_type == CommunicationType::P2p {
            self.rx_u_setup_p2p(queue, &message, &pdu, calling_party);
            return;
        }

        // Get destination GSSI (called party)
        let Some(dest_gssi) = pdu.called_party_ssi else {
            tracing::warn!("U-SETUP without called_party_ssi, ignoring");
            return;
        };
        let dest_gssi = dest_gssi as u32;
        let dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);

        if !self.has_listener(dest_gssi) {
            tracing::info!(
                "CMCE: rejecting U-SETUP from issi={} to gssi={} (no listeners)",
                calling_party.ssi,
                dest_gssi
            );
            return;
        }

        // Allocate circuit (DL+UL for group call)
        let circuit = match {
            let mut state = self.config.state_write();
            self.circuits.allocate_circuit_with_allocator(
                Direction::Both,
                pdu.basic_service_information.communication_type,
                pdu.simplex_duplex_selection,
                &mut state.timeslot_alloc,
                TimeslotOwner::Cmce,
            )
        } {
            Ok(circuit) => circuit.clone(),
            Err(e) => {
                tracing::error!("Failed to allocate circuit for U-SETUP: {:?}", e);
                return;
            }
        };

        tracing::info!(
            "rx_u_setup: call from ISSI {} to GSSI {} → ts={} call_id={} usage={}",
            calling_party.ssi,
            dest_gssi,
            circuit.ts,
            circuit.call_id,
            circuit.usage
        );

        // Signal UMAC to open DL+UL circuits
        Self::signal_umac_circuit_open(queue, &circuit, message.dltime, None);

        // Build channel allocation timeslot mask for this call
        let mut timeslots = [false; 4];
        timeslots[circuit.ts as usize - 1] = true;

        // Extract UL message routing info (handle, link_id, endpoint_id) for
        // individually-addressed responses. These are needed so MLE can route
        // the response back to the correct radio via the established LLC link.
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &message.msg else {
            panic!()
        };
        let ul_handle = prim.handle;
        let ul_link_id = prim.link_id;
        let ul_endpoint_id = prim.endpoint_id;

        // === 1) Send D-CALL-PROCEEDING to the calling MS (individually addressed) ===
        // This acknowledges the U-SETUP and keeps the radio from timing out.
        self.send_d_call_proceeding(
            queue,
            &message,
            &pdu,
            circuit.call_id,
            CallTimeoutSetupPhase::T10s,
            pdu.hook_method_selection,
        );

        // === 2) Send D-CONNECT to the calling MS with Granted + channel allocation ===
        // This transitions the calling MS from "Call Setup" to "Active".
        // MUST be sent BEFORE the group D-SETUP so the radio receives it on MCCH.
        // Uses the correct MLE handle (not 0) so MLE routes it properly.
        let d_connect = DConnect {
            call_identifier: circuit.call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: pdu.hook_method_selection,
            simplex_duplex_selection: pdu.simplex_duplex_selection,
            transmission_grant: TransmissionGrant::Granted,
            transmission_request_permission: false,
            call_ownership: true, // Calling MS is the call owner (ETSI 14.8.4)
            call_priority: None,
            basic_service_information: None,
            temporary_address: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_connect);
        let mut connect_sdu = BitBuffer::new_autoexpand(30);
        d_connect.to_bitbuf(&mut connect_sdu).expect("Failed to serialize DConnect");
        connect_sdu.seek(0);

        let connect_msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: connect_sdu,
                handle: ul_handle,
                endpoint_id: ul_endpoint_id,
                link_id: ul_link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: Some(CmceChanAllocReq {
                    usage: Some(circuit.usage),
                    alloc_type: ChanAllocType::Replace,
                    carrier: None,
                    timeslots,
                    ul_dl_assigned: UlDlAssignment::Both,
                }),
                main_address: calling_party,
                tx_reporter: None,
            }),
        };
        queue.push_back(connect_msg);

        // === 3) Send D-SETUP to group (broadcast on MCCH with channel allocation) ===
        // GrantedToOtherUser tells other group members that someone else has the floor.
        let d_setup = DSetup {
            call_identifier: circuit.call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: pdu.hook_method_selection,
            simplex_duplex_selection: pdu.simplex_duplex_selection,
            basic_service_information: pdu.basic_service_information.clone(),
            transmission_grant: TransmissionGrant::GrantedToOtherUser,
            transmission_request_permission: false,
            call_priority: pdu.call_priority,
            notification_indicator: None,
            temporary_address: None,
            calling_party_address_ssi: Some(calling_party.ssi),
            calling_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        // Cache for late-entry re-sends
        self.cached_setups.insert(
            circuit.call_id,
            CachedSetup {
                pdu: d_setup,
                dest_addr,
                resend: true,
            },
        );
        let d_setup_ref = &self.cached_setups.get(&circuit.call_id).unwrap().pdu;

        let (setup_sdu, setup_chan_alloc) = Self::build_d_setup_prim(d_setup_ref, circuit.usage, circuit.ts, UlDlAssignment::Both);
        let setup_msg = Self::build_sapmsg(setup_sdu, Some(setup_chan_alloc), message.dltime, dest_addr, None);
        queue.push_back(setup_msg);

        // Track the active local call — caller is granted the floor, so tx_active = true
        self.active_calls.insert(
            circuit.call_id,
            ActiveCall {
                origin: CallOrigin::Local {
                    caller_addr: calling_party,
                },
                dest_gssi,
                source_issi: calling_party.ssi,
                ts: circuit.ts,
                usage: circuit.usage,
                tx_active: true,
                tx_grant_time: message.dltime,
                hangtime_start: None,
                brew_uuid: None,
            },
        );

        // Notify Brew entity about this local call if Brew is loaded and the SSI is cleared for Brew
        // It can then forward to TetraPack if the group is subscribed
        if brew::is_brew_gssi_routable(&self.config, dest_gssi) {
            let msg = SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: message.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                    call_id: circuit.call_id,
                    source_issi: calling_party.ssi,
                    dest_gssi,
                    ts: circuit.ts,
                }),
            };
            queue.push_back(msg);
        }
    }

    /// Handle U-SETUP for point-to-point (individual) duplex calls
    fn rx_u_setup_p2p(&mut self, queue: &mut MessageQueue, message: &SapMsg, pdu: &USetup, calling_party: TetraAddress) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &message.msg else {
            panic!()
        };

        // For P2P calls, only ISSI addressing is valid (CPTI=1 or 2).
        // Reject short-number or other types to avoid unintended group ringing.
        if pdu.called_party_type_identifier != 1 && pdu.called_party_type_identifier != 2 {
            tracing::warn!(
                "U-SETUP P2P with non-ISSI called_party_type_identifier={} (rejecting)",
                pdu.called_party_type_identifier
            );
            return;
        }
        if pdu.called_party_short_number_address.is_some()
            || (pdu.called_party_extension.is_some() && pdu.called_party_type_identifier != 2)
        {
            tracing::warn!("U-SETUP P2P with invalid called party fields (short number/extension mismatch), rejecting");
            return;
        }

        let Some(called_ssi) = pdu.called_party_ssi else {
            tracing::warn!("U-SETUP P2P without called_party_ssi, ignoring");
            return;
        };
        let called_addr = TetraAddress::new(called_ssi as u32, SsiType::Issi);

        if !self.subscriber_groups.contains_key(&called_addr.ssi) {
            tracing::info!(
                "CMCE: rejecting U-SETUP P2P from ISSI {} to ISSI {} (callee not registered)",
                calling_party.ssi,
                called_addr.ssi
            );
            let call_id = self.circuits.get_next_call_id();
            let sdu = Self::build_d_release(call_id, DisconnectCause::CalledPartyNotReachable);
            let msg = Self::build_sapmsg_direct(sdu, message.dltime, calling_party, prim.handle, prim.link_id, prim.endpoint_id);
            queue.push_back(msg);
            return;
        }

        // Allocate circuit(s). Duplex uses two traffic timeslots, one per MS, with cross-routing.
        let (circuit_calling, circuit_called) = {
            let mut state = self.config.state_write();
            let circuit_calling = match self.circuits.allocate_circuit_with_allocator(
                Direction::Both,
                pdu.basic_service_information.communication_type,
                pdu.simplex_duplex_selection,
                &mut state.timeslot_alloc,
                TimeslotOwner::Cmce,
            ) {
                Ok(circuit) => circuit.clone(),
                Err(e) => {
                    // tracing::error!("Failed to allocate circuit for U-SETUP P2P: {:?}", e);
                    tracing::info!(
                        "CMCE: rejecting U-SETUP P2P from ISSI {} to ISSI {}, failed to allocate circuit for U-SETUP P2P, error: {:?}",
                        calling_party.ssi,
                        called_addr.ssi,
                        e
                    );
                    let call_id = self.circuits.get_next_call_id();
                    let sdu = Self::build_d_release(call_id, DisconnectCause::CongestionInInfrastructure);
                    let msg = Self::build_sapmsg_direct(sdu, message.dltime, calling_party, prim.handle, prim.link_id, prim.endpoint_id);
                    queue.push_back(msg);
                    return;
                }
            };

            let circuit_called = if pdu.simplex_duplex_selection {
                match self.circuits.allocate_circuit_for_call_with_allocator(
                    circuit_calling.call_id,
                    Direction::Both,
                    pdu.basic_service_information.communication_type,
                    pdu.simplex_duplex_selection,
                    &mut state.timeslot_alloc,
                    TimeslotOwner::Cmce,
                ) {
                    Ok(circuit) => Some(circuit.clone()),
                    Err(e) => {
                        // tracing::error!("Failed to allocate second circuit for duplex P2P: {:?}", e);
                        let _ = self.circuits.close_circuit(Direction::Both, circuit_calling.ts);
                        let _ = state.timeslot_alloc.release(TimeslotOwner::Cmce, circuit_calling.ts);
                        tracing::info!(
                            "CMCE: rejecting U-SETUP P2P from ISSI {} to ISSI {}, failed to allocate second circuit for duplex P2P, error {:?}",
                            calling_party.ssi,
                            called_addr.ssi,
                            e
                        );
                        let call_id = self.circuits.get_next_call_id();
                        let sdu = Self::build_d_release(call_id, DisconnectCause::CongestionInInfrastructure);
                        let msg =
                            Self::build_sapmsg_direct(sdu, message.dltime, calling_party, prim.handle, prim.link_id, prim.endpoint_id);
                        queue.push_back(msg);
                        return;
                    }
                }
            } else {
                None
            };

            (circuit_calling, circuit_called)
        };

        let calling_ts = circuit_calling.ts;
        let calling_usage = circuit_calling.usage;
        let call_id = circuit_calling.call_id;
        let (called_ts, called_usage) = if let Some(called) = &circuit_called {
            (called.ts, called.usage)
        } else {
            (calling_ts, calling_usage)
        };

        tracing::info!(
            "rx_u_setup_p2p: call from ISSI {} to ISSI {} → call_id={} ts(call)={} usage(call)={} ts(called)={} usage(called)={}",
            calling_party.ssi,
            called_addr.ssi,
            call_id,
            calling_ts,
            calling_usage,
            called_ts,
            called_usage
        );

        // Do not open traffic channel yet. Let the called MS respond on MCCH
        // (U-ALERT/U-CONNECT), then allocate the TCH upon U-CONNECT.

        // 1) Send D-CALL-PROCEEDING to the calling MS (individually addressed)
        self.send_d_call_proceeding(queue, message, pdu, call_id, CallTimeoutSetupPhase::T60s, pdu.hook_method_selection);

        // 2) Send D-SETUP to called MS (individually addressed)
        let d_setup = DSetup {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: pdu.hook_method_selection,
            simplex_duplex_selection: pdu.simplex_duplex_selection,
            basic_service_information: pdu.basic_service_information.clone(),
            transmission_grant: TransmissionGrant::NotGranted,
            transmission_request_permission: false,
            call_priority: pdu.call_priority,
            notification_indicator: None,
            temporary_address: None,
            calling_party_address_ssi: Some(calling_party.ssi),
            calling_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };
        tracing::debug!("-> {:?}", d_setup);

        self.cached_setups.insert(
            call_id,
            CachedSetup {
                pdu: d_setup,
                dest_addr: called_addr,
                resend: false, // no late-entry resends for individual calls
            },
        );

        let d_setup_ref = &self.cached_setups.get(&call_id).unwrap().pdu;
        let mut setup_sdu = BitBuffer::new_autoexpand(80);
        d_setup_ref.to_bitbuf(&mut setup_sdu).expect("Failed to serialize DSetup");
        setup_sdu.seek(0);
        let setup_msg = Self::build_sapmsg(setup_sdu, None, message.dltime, called_addr, None);
        queue.push_back(setup_msg);

        // 3) Wait for U-ALERT from the called MS before notifying the caller.
        // Some radios are sensitive to early D-ALERT; keep setup strictly ordered.

        // 3a) Send U-ALERT for testing, U-ALERT makes the calling radio show a ringing status
        // self.send_d_alert_individual(
        //     queue,
        //     message.dltime,
        //     call_id,
        //     pdu.simplex_duplex_selection,
        //     calling_party,
        //     prim.handle,
        //     prim.link_id,
        //     prim.endpoint_id,
        //     CallTimeoutSetupPhase::T60s,
        // );

        // Track pending individual call
        self.individual_calls.insert(
            call_id,
            IndividualCall {
                calling_addr: calling_party,
                called_addr,
                calling_handle: prim.handle,
                calling_link_id: prim.link_id,
                calling_endpoint_id: prim.endpoint_id,
                called_handle: None,
                called_link_id: None,
                called_endpoint_id: None,
                calling_ts,
                called_ts,
                calling_usage,
                called_usage,
                simplex_duplex: pdu.simplex_duplex_selection,
                state: IndividualCallState::Setup,
                alert_sent: false,
            },
        );
    }

    /// Handle U-ALERT for an individual call: notify calling MS
    fn rx_u_alert(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UAlert::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-ALERT {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-ALERT: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;
        let Some(call) = self.individual_calls.get(&call_id).cloned() else {
            tracing::warn!("U-ALERT for unknown call_id={}", call_id);
            return;
        };

        if call.called_addr.ssi != prim.received_tetra_address.ssi {
            tracing::warn!(
                "U-ALERT call_id={} from unexpected ISSI {} (expected {})",
                call_id,
                prim.received_tetra_address.ssi,
                call.called_addr.ssi
            );
        }

        if call.alert_sent {
            tracing::debug!("U-ALERT call_id={} already alerted, ignoring", call_id);
            return;
        }

        if let Some(call) = self.individual_calls.get_mut(&call_id) {
            if call.called_handle.is_none() {
                call.called_handle = Some(prim.handle);
                call.called_link_id = Some(prim.link_id);
                call.called_endpoint_id = Some(prim.endpoint_id);
            }
        }

        let calling_addr = call.calling_addr;
        let calling_handle = call.calling_handle;
        let calling_link_id = call.calling_link_id;
        let calling_endpoint_id = call.calling_endpoint_id;
        let simplex_duplex = call.simplex_duplex;

        self.send_d_alert_individual(
            queue,
            message.dltime,
            call_id,
            simplex_duplex,
            calling_addr,
            calling_handle,
            calling_link_id,
            calling_endpoint_id,
            CallTimeoutSetupPhase::T60s,
        );

        if let Some(call) = self.individual_calls.get_mut(&call_id) {
            call.alert_sent = true;
        }
    }

    /// Handle U-CONNECT for an individual call: establish call and grant duplex permissions
    fn rx_u_connect(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UConnect::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-CONNECT {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-CONNECT: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;
        let Some(call_snapshot) = self.individual_calls.get(&call_id).cloned() else {
            tracing::warn!("U-CONNECT for unknown call_id={}", call_id);
            return;
        };

        if call_snapshot.state == IndividualCallState::Active {
            tracing::debug!("U-CONNECT for active call_id={}, ignoring", call_id);
            return;
        }

        if call_snapshot.called_addr.ssi != prim.received_tetra_address.ssi {
            tracing::warn!(
                "U-CONNECT call_id={} from unexpected ISSI {} (expected {})",
                call_id,
                prim.received_tetra_address.ssi,
                call_snapshot.called_addr.ssi
            );
        }

        if call_snapshot.simplex_duplex && !pdu.simplex_duplex_selection {
            tracing::warn!("U-CONNECT call_id={} downgraded to simplex by called MS; not supported", call_id);
            self.release_individual_call(queue, call_id, DisconnectCause::RequestedServiceNotAvailable);
            return;
        }

        if let Some(call) = self.individual_calls.get_mut(&call_id) {
            if call.called_handle.is_none() {
                call.called_handle = Some(prim.handle);
                call.called_link_id = Some(prim.link_id);
                call.called_endpoint_id = Some(prim.endpoint_id);
            }
        }

        let calling_addr = call_snapshot.calling_addr;
        let called_addr = call_snapshot.called_addr;
        let calling_handle = call_snapshot.calling_handle;
        let calling_link_id = call_snapshot.calling_link_id;
        let calling_endpoint_id = call_snapshot.calling_endpoint_id;
        let calling_ts = call_snapshot.calling_ts;
        let called_ts = call_snapshot.called_ts;
        let calling_usage = call_snapshot.calling_usage;
        let called_usage = call_snapshot.called_usage;
        let simplex_duplex = call_snapshot.simplex_duplex;

        let Some(cached) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };

        // Channel allocation (per-MS timeslot)
        let mut calling_timeslots = [false; 4];
        calling_timeslots[calling_ts as usize - 1] = true;
        let mut called_timeslots = [false; 4];
        called_timeslots[called_ts as usize - 1] = true;
        let chan_alloc_calling = CmceChanAllocReq {
            usage: Some(calling_usage),
            alloc_type: ChanAllocType::Replace,
            carrier: None,
            timeslots: calling_timeslots,
            ul_dl_assigned: UlDlAssignment::Both,
        };
        let chan_alloc_called = CmceChanAllocReq {
            usage: Some(called_usage),
            alloc_type: ChanAllocType::Replace,
            carrier: None,
            timeslots: called_timeslots,
            ul_dl_assigned: UlDlAssignment::Both,
        };
        tracing::debug!(
            "P2P chan_alloc: calling ts={} usage={} slots={:?}, called ts={} usage={} slots={:?}",
            calling_ts,
            calling_usage,
            calling_timeslots,
            called_ts,
            called_usage,
            called_timeslots
        );

        // Send D-CONNECT to calling MS with transmission grant (duplex)
        let d_connect = DConnect {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: true,
            simplex_duplex_selection: simplex_duplex,
            transmission_grant: TransmissionGrant::Granted,
            transmission_request_permission: false,
            call_ownership: true,
            call_priority: None,
            basic_service_information: None,
            temporary_address: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_connect);
        let mut connect_sdu = BitBuffer::new_autoexpand(30);
        d_connect.to_bitbuf(&mut connect_sdu).expect("Failed to serialize DConnect");
        connect_sdu.seek(0);

        let connect_msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: connect_sdu,
                handle: calling_handle,
                endpoint_id: calling_endpoint_id,
                link_id: calling_link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: Some(chan_alloc_calling),
                main_address: calling_addr,
                tx_reporter: None,
            }),
        };
        queue.push_back(connect_msg);

        // Send D-CONNECT ACKNOWLEDGE to called MS
        let d_connect_ack = DConnectAcknowledge {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m.into_raw() as u8,
            transmission_grant: TransmissionGrant::Granted.into_raw() as u8,
            transmission_request_permission: false,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_connect_ack);
        let mut ack_sdu = BitBuffer::new_autoexpand(28);
        d_connect_ack
            .to_bitbuf(&mut ack_sdu)
            .expect("Failed to serialize DConnectAcknowledge");
        ack_sdu.seek(0);

        let ack_msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: ack_sdu,
                handle: prim.handle,
                endpoint_id: prim.endpoint_id,
                link_id: prim.link_id,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: Some(chan_alloc_called),
                main_address: called_addr,
                tx_reporter: None,
            }),
        };
        queue.push_back(ack_msg);

        // Open circuit(s) in UMAC (traffic mode)
        let circuit_calling = CmceCircuit {
            ts_created: self.dltime,
            direction: Direction::Both,
            ts: calling_ts,
            call_id,
            usage: calling_usage,
            circuit_mode: cached.pdu.basic_service_information.circuit_mode_type,
            comm_type: cached.pdu.basic_service_information.communication_type,
            simplex_duplex,
            speech_service: cached.pdu.basic_service_information.speech_service,
            etee_encrypted: cached.pdu.basic_service_information.encryption_flag,
        };
        let duplex_peer = if calling_ts != called_ts { Some(called_ts) } else { None };
        Self::signal_umac_circuit_open(queue, &circuit_calling, self.dltime, duplex_peer);

        if called_ts != calling_ts {
            let circuit_called = CmceCircuit {
                ts_created: self.dltime,
                direction: Direction::Both,
                ts: called_ts,
                call_id,
                usage: called_usage,
                circuit_mode: cached.pdu.basic_service_information.circuit_mode_type,
                comm_type: cached.pdu.basic_service_information.communication_type,
                simplex_duplex,
                speech_service: cached.pdu.basic_service_information.speech_service,
                etee_encrypted: cached.pdu.basic_service_information.encryption_flag,
            };
            Self::signal_umac_circuit_open(queue, &circuit_called, self.dltime, Some(calling_ts));
        }

        if let Some(call) = self.individual_calls.get_mut(&call_id) {
            call.state = IndividualCallState::Active;
        }
    }

    pub fn route_xx_deliver(&mut self, _queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("route_xx_deliver");

        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!();
        };
        let Some(bits) = prim.sdu.peek_bits(5) else {
            tracing::warn!("insufficient bits: {}", prim.sdu.dump_bin());
            return;
        };
        let Ok(pdu_type) = CmcePduTypeUl::try_from(bits) else {
            tracing::warn!("invalid pdu type: {} in {}", bits, prim.sdu.dump_bin());
            return;
        };

        // TODO FIXME: Besides these PDUs, we can also receive several signals (BUSY ind, CLOSE ind, etc)
        match pdu_type {
            CmcePduTypeUl::USetup => self.rx_u_setup(_queue, message),
            CmcePduTypeUl::UTxCeased => self.rx_u_tx_ceased(_queue, message),
            CmcePduTypeUl::UTxDemand => self.rx_u_tx_demand(_queue, message),
            CmcePduTypeUl::URelease => self.rx_u_release(_queue, message),
            CmcePduTypeUl::UDisconnect => self.rx_u_disconnect(_queue, message),
            CmcePduTypeUl::UAlert => self.rx_u_alert(_queue, message),
            CmcePduTypeUl::UConnect => self.rx_u_connect(_queue, message),
            CmcePduTypeUl::UInfo | CmcePduTypeUl::UStatus | CmcePduTypeUl::UCallRestore => {
                unimplemented_log!("{}", pdu_type);
            }
            _ => {
                panic!();
            }
        }
    }

    pub fn tick_start(&mut self, queue: &mut MessageQueue, dltime: TdmaTime) {
        self.dltime = dltime;

        // Check hangtime expiry for active local calls
        self.check_hangtime_expiry(queue);

        if let Some(tasks) = self.circuits.tick_start(dltime) {
            for task in tasks {
                match task {
                    CircuitMgrCmd::SendDSetup(call_id, usage, ts) => {
                        // Get our cached D-SETUP, build a prim and send it down the stack
                        let Some(cached) = self.cached_setups.get_mut(&call_id) else {
                            tracing::error!("No cached D-SETUP for call id {}", call_id);
                            return;
                        };
                        if !cached.resend {
                            continue;
                        }
                        // Update transmission_grant based on current call state:
                        // During hangtime (nobody transmitting), use NotGranted;
                        // during active TX, use GrantedToOtherUser.
                        if let Some(active) = self.active_calls.get(&call_id) {
                            cached.pdu.transmission_grant = if active.tx_active {
                                TransmissionGrant::GrantedToOtherUser
                            } else {
                                TransmissionGrant::NotGranted
                            };
                        }
                        let dest_addr = cached.dest_addr;
                        let (sdu, chan_alloc) = Self::build_d_setup_prim(&cached.pdu, usage, ts, UlDlAssignment::Both);
                        let prim = Self::build_sapmsg(sdu, Some(chan_alloc), self.dltime, dest_addr, None);
                        queue.push_back(prim);
                    }

                    CircuitMgrCmd::SendClose(call_id, circuit) => {
                        tracing::warn!("need to send CLOSE for call id {}", call_id);
                        let ts = circuit.ts;
                        // Get our cached D-SETUP, build D-RELEASE and send
                        if let Some(cached) = self.cached_setups.get(&call_id) {
                            let sdu = Self::build_d_release_from_d_setup(&cached.pdu, DisconnectCause::ExpiryOfTimer);
                            let prim = Self::build_sapmsg(sdu, None, self.dltime, cached.dest_addr, None);
                            queue.push_back(prim);

                            if let Some(ind_call) = self.individual_calls.get(&call_id) {
                                let sdu_calling = Self::build_d_release_from_d_setup(&cached.pdu, DisconnectCause::ExpiryOfTimer);
                                let prim_calling = SapMsg {
                                    sap: Sap::LcmcSap,
                                    src: TetraEntity::Cmce,
                                    dest: TetraEntity::Mle,
                                    dltime: self.dltime,
                                    msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                                        sdu: sdu_calling,
                                        handle: ind_call.calling_handle,
                                        endpoint_id: ind_call.calling_endpoint_id,
                                        link_id: ind_call.calling_link_id,
                                        layer2service: 0,
                                        pdu_prio: 0,
                                        layer2_qos: 0,
                                        stealing_permission: false,
                                        stealing_repeats_flag: false,
                                        chan_alloc: None,
                                        main_address: ind_call.calling_addr,
                                        tx_reporter: None,
                                    }),
                                };
                                queue.push_back(prim_calling);
                            }
                        } else {
                            tracing::error!("No cached D-SETUP for call id {}", call_id);
                        }

                        // Clean up call state
                        self.cached_setups.remove(&call_id);
                        self.active_calls.remove(&call_id);
                        self.individual_calls.remove(&call_id);

                        // Signal UMAC to release the circuit
                        Self::signal_umac_circuit_close(queue, circuit, self.dltime);
                        self.release_timeslot(ts);
                    }
                }
            }
        }
    }

    /// Check if any active calls in hangtime have expired, and if so, release them.
    ///
    /// This also implements a **TX watchdog** that handles the case where the transmitting MS
    /// goes off-air abruptly (RF loss, battery death, etc.) without sending U-TX-CEASED.
    /// In that scenario `tx_active` stays `true` indefinitely and `hangtime_start` is never set,
    /// so the original hangtime check would never fire — the call would hang forever.
    ///
    /// ETSI EN 300 392-7 §14.8 defines timer **T3.40** as the maximum permitted continuous
    /// transmission time (infrastructure side, default 30 s).  When that timer expires the BS
    /// is required to force-release the floor.  We use 35 s to give a small margin above the
    /// MS-side timer so a legitimately long transmission is not cut off prematurely.
    ///
    /// When the watchdog fires the call is transitioned into hangtime (exactly as if the MS had
    /// sent U-TX-CEASED), and the existing ~5 s hangtime expiry path then tears down the call
    /// cleanly — freeing the timeslot, closing the UMAC circuit, and notifying Brew.
    fn check_hangtime_expiry(&mut self, queue: &mut MessageQueue) {
        // Hangtime duration: 5 multiframes ~5 seconds (18 frames/MF x 4 slots/frame)
        const HANGTIME_FRAMES: i32 = 5 * 18 * 4;

        // TX watchdog: 35 s x 18 frames/MF x 4 slots/frame.
        // ETSI T3.40 default = 30 s; 35 s gives a comfortable margin above the MS timer.
        const TX_WATCHDOG_FRAMES: i32 = 35 * 18 * 4;

        // --- 1. Hangtime expiry (existing logic, unchanged) ---
        let hangtime_expired: Vec<u16> = self
            .active_calls
            .iter()
            .filter_map(|(&call_id, call)| {
                if let Some(hangtime_start) = call.hangtime_start {
                    if hangtime_start.age(self.dltime) > HANGTIME_FRAMES {
                        return Some(call_id);
                    }
                }
                None
            })
            .collect();

        for call_id in hangtime_expired {
            tracing::info!("Hangtime expired for call_id={}, releasing", call_id);
            self.release_group_call(queue, call_id, DisconnectCause::ExpiryOfTimer);
        }

        // --- 2. TX watchdog: detect MS that went off-air without releasing the floor ---
        let watchdog_expired: Vec<u16> = self
            .active_calls
            .iter()
            .filter_map(|(&call_id, call)| {
                // Only active (transmitting) calls that have not yet entered hangtime.
                if call.tx_active && call.hangtime_start.is_none() {
                    if call.tx_grant_time.age(self.dltime) > TX_WATCHDOG_FRAMES {
                        return Some(call_id);
                    }
                }
                None
            })
            .collect();

        for call_id in watchdog_expired {
            // Snapshot what we need before taking a mutable borrow.
            let (ts, dest_gssi, brew_uuid_opt) = {
                let call = self.active_calls.get(&call_id).unwrap();
                tracing::warn!(
                    "TX watchdog fired for call_id={} gssi={} speaker_issi={}:                      MS went off-air without releasing floor, force-entering hangtime (T3.40)",
                    call_id,
                    call.dest_gssi,
                    call.source_issi,
                );
                (call.ts, call.dest_gssi, call.brew_uuid)
            };

            // Transition call into hangtime state, exactly as U-TX-CEASED would do.
            {
                let call = self.active_calls.get_mut(&call_id).unwrap();
                call.tx_active = false;
                call.hangtime_start = Some(self.dltime);
                // Detach the brew_uuid so a later NetworkCallEnd does not double-release.
                call.brew_uuid = None;
            }

            // Inform remaining group members the floor was released (D-TX-CEASED via FACCH).
            self.send_d_tx_ceased_facch(queue, call_id, dest_gssi, ts);

            // Tell UMAC to enter hangtime signalling mode on this timeslot.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
            });

            // If a network (Brew) session was active, notify Brew that the floor dropped.
            if brew::is_brew_gssi_routable(&self.config, dest_gssi) {
                if let Some(brew_uuid) = brew_uuid_opt {
                    queue.push_back(SapMsg {
                        sap: Sap::Control,
                        src: TetraEntity::Cmce,
                        dest: TetraEntity::Brew,
                        dltime: self.dltime,
                        msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd { brew_uuid }),
                    });
                }
                queue.push_back(SapMsg {
                    sap: Sap::Control,
                    src: TetraEntity::Cmce,
                    dest: TetraEntity::Brew,
                    dltime: self.dltime,
                    msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
                });
            }

            // The call is now in hangtime. The next tick(s) will see hangtime_start.is_some()
            // and once HANGTIME_FRAMES elapses, release_group_call fires automatically.
        }
    }

    fn release_timeslot(&mut self, ts: u8) {
        let mut state = self.config.state_write();
        if let Err(err) = state.timeslot_alloc.release(TimeslotOwner::Cmce, ts) {
            tracing::warn!("CcBsSubentity: failed to release timeslot ts={} err={:?}", ts, err);
        }
    }

    /// Release a group call: send D-RELEASE, close circuits, clean up state
    fn release_group_call(&mut self, queue: &mut MessageQueue, call_id: u16, disconnect_cause: DisconnectCause) {
        let Some(cached) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };
        let dest_addr = cached.dest_addr;

        // Send D-RELEASE to group
        let sdu = Self::build_d_release_from_d_setup(&cached.pdu, disconnect_cause);
        let prim = Self::build_sapmsg(sdu, None, self.dltime, dest_addr, None);
        queue.push_back(prim);

        // Close the circuit in CircuitMgr and notify Brew
        if let Some(call) = self.active_calls.get(&call_id) {
            let ts = call.ts;
            let dest_ssi = call.dest_gssi;
            let is_local = matches!(call.origin, CallOrigin::Local { .. });

            if let Ok(circuit) = self.circuits.close_circuit(Direction::Both, ts) {
                Self::signal_umac_circuit_close(queue, circuit, self.dltime);
            }

            // Ensure UMAC clears any hangtime override for this slot even if the circuit close is delayed.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::CallEnded { call_id, ts }),
            });

            self.release_timeslot(ts);

            // Notify Brew only for local calls on SSIs that are cleared for Brew
            if brew::is_brew_gssi_routable(&self.config, dest_ssi) {
                if is_local {
                    let notify = SapMsg {
                        sap: Sap::Control,
                        src: TetraEntity::Cmce,
                        dest: TetraEntity::Brew,
                        dltime: self.dltime,
                        msg: SapMsgInner::CmceCallControl(CallControl::CallEnded { call_id, ts }),
                    };
                    queue.push_back(notify);
                }
            }
        }

        // Clean up
        self.cached_setups.remove(&call_id);
        self.active_calls.remove(&call_id);
    }

    /// Release an individual call: send D-RELEASE to both parties, close circuits, clean up state
    fn release_individual_call(&mut self, queue: &mut MessageQueue, call_id: u16, disconnect_cause: DisconnectCause) {
        let Some(call) = self.individual_calls.remove(&call_id) else {
            tracing::warn!("No individual call for call_id={}", call_id);
            return;
        };

        const SETUP_RELEASE_REPEATS: usize = 3;

        if call.state == IndividualCallState::Active {
            // Deliver on traffic channel via FACCH stealing so the MS is still listening.
            // Send twice to reduce "no response" due to occasional STCH loss.
            for _ in 0..2 {
                let sdu_calling = if let Some(cached) = self.cached_setups.get(&call_id) {
                    Self::build_d_release_from_d_setup(&cached.pdu, disconnect_cause)
                } else {
                    Self::build_d_release(call_id, disconnect_cause)
                };
                let sdu_called = if let Some(cached) = self.cached_setups.get(&call_id) {
                    Self::build_d_release_from_d_setup(&cached.pdu, disconnect_cause)
                } else {
                    Self::build_d_release(call_id, disconnect_cause)
                };
                let prim_calling = Self::build_sapmsg_stealing(
                    sdu_calling,
                    self.dltime,
                    call.calling_addr,
                    call.calling_ts,
                    Some(call.calling_usage),
                );
                let prim_called =
                    Self::build_sapmsg_stealing(sdu_called, self.dltime, call.called_addr, call.called_ts, Some(call.called_usage));
                queue.push_back(prim_calling);
                queue.push_back(prim_called);
            }
        } else {
            // Send D-RELEASE to calling and called MS via MCCH (no LLC link context).
            // During setup, both parties are monitoring MCCH, so force link_id=0.
            for _ in 0..SETUP_RELEASE_REPEATS {
                let sdu_calling = if let Some(cached) = self.cached_setups.get(&call_id) {
                    Self::build_d_release_from_d_setup(&cached.pdu, disconnect_cause)
                } else {
                    Self::build_d_release(call_id, disconnect_cause)
                };
                let sdu_called = if let Some(cached) = self.cached_setups.get(&call_id) {
                    Self::build_d_release_from_d_setup(&cached.pdu, disconnect_cause)
                } else {
                    Self::build_d_release(call_id, disconnect_cause)
                };
                let prim_calling = Self::build_sapmsg(sdu_calling, None, self.dltime, call.calling_addr, None);
                queue.push_back(prim_calling);

                let prim_called = Self::build_sapmsg(sdu_called, None, self.dltime, call.called_addr, None);
                queue.push_back(prim_called);
            }
        }

        // Close the circuit(s)
        let mut ts_list = vec![call.calling_ts];
        if call.called_ts != call.calling_ts {
            ts_list.push(call.called_ts);
        }
        for ts in ts_list {
            if let Ok(circuit) = self.circuits.close_circuit(Direction::Both, ts) {
                Self::signal_umac_circuit_close(queue, circuit, self.dltime);
            }

            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::CallEnded { call_id, ts }),
            });

            self.release_timeslot(ts);
        }
        self.cached_setups.remove(&call_id);
    }

    fn feature_check_u_setup(pdu: &USetup) -> bool {
        let mut supported = true;

        if !(pdu.area_selection == 0 || pdu.area_selection == 1) {
            unimplemented_log!("Area selection not supported: {}", pdu.area_selection);
            supported = false;
        };
        // if pdu.hook_method_selection {
        //     // We do not implement explicit hook transitions yet; force hook_method_selection=false in responses.
        //     unimplemented_log!("Hook method selection requested, forcing hook_method_selection=false");
        // };
        // Duplex supported only for P2P calls. Group/broadcast remain simplex only.
        if pdu.basic_service_information.communication_type == CommunicationType::P2p {
            if !pdu.simplex_duplex_selection {
                unimplemented_log!("Simplex P2P calls not supported");
                supported = false;
            }
        } else if pdu.simplex_duplex_selection {
            unimplemented_log!(
                "Duplex only supported for P2P calls (comm_type={})",
                pdu.basic_service_information.communication_type
            );
            supported = false;
        };
        // if pdu.basic_service_information != 0xFC {
        //     // TODO FIXME implement parsing
        //     tracing::error!("Basic service information not supported: {}", pdu.basic_service_information);
        //     return;
        // };
        // request_to_transmit_send_data can be false for speech group calls — the MS
        // implicitly requests to transmit by initiating the call. No action needed.
        if pdu.clir_control != 0 {
            unimplemented_log!("clir_control not supported: {}", pdu.clir_control);
        };
        if pdu.called_party_ssi.is_none() || pdu.called_party_short_number_address.is_some() || pdu.called_party_extension.is_some() {
            unimplemented_log!("we only support ssi-based calling");
        };
        // Then, we warn about some other unhandled/unsupported fields
        if let Some(v) = &pdu.external_subscriber_number {
            unimplemented_log!("external_subscriber_number not supported: {:?}", v);
        };
        if let Some(v) = &pdu.facility {
            unimplemented_log!("facility not supported: {:?}", v);
        };
        if let Some(v) = &pdu.dm_ms_address {
            unimplemented_log!("dm_ms_address not supported: {:?}", v);
        };
        if let Some(v) = &pdu.proprietary {
            unimplemented_log!("proprietary not supported: {:?}", v);
        };

        supported
    }

    /// Handle U-TX CEASED: radio released PTT
    /// Response: send D-TX CEASED via FACCH to all group members, enter hangtime
    fn rx_u_tx_ceased(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UTxCeased::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-TX CEASED {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-TX CEASED: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;

        if self.individual_calls.contains_key(&call_id) {
            tracing::debug!("U-TX CEASED for individual call_id={}, ignoring", call_id);
            return;
        }

        // Look up the active call
        let Some(call) = self.active_calls.get_mut(&call_id) else {
            tracing::warn!("U-TX CEASED for unknown call_id={}", call_id);
            return;
        };

        // Check if already in hangtime - ignore duplicate U-TX CEASED to avoid resetting timer
        if !call.tx_active && call.hangtime_start.is_some() {
            tracing::debug!("U-TX CEASED: already in hangtime for call_id={}, ignoring duplicate", call_id);
            return;
        }

        tracing::info!("U-TX CEASED: PTT released on call_id={}, entering hangtime", call_id);

        let ts = call.ts;
        let dest_ssi = call.dest_gssi;
        call.tx_active = false;
        call.hangtime_start = Some(self.dltime);

        // Get dest address from cached setup
        let Some(cached) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };
        let dest_addr = cached.dest_addr;

        // Send D-TX CEASED via FACCH (stealing) to all group members
        let d_tx_ceased = DTxCeased {
            call_identifier: call_id,
            transmission_request_permission: false, // ETSI 14.8.43: 0 = allowed to request transmission
            notification_indicator: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::info!("-> {:?}", d_tx_ceased);
        let mut sdu = BitBuffer::new_autoexpand(25);
        d_tx_ceased.to_bitbuf(&mut sdu).expect("Failed to serialize DTxCeased");
        sdu.seek(0);

        // Send via FACCH (stealing channel) so radios on the traffic channel hear the beep
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, dest_addr, ts, None);
        queue.push_back(msg);

        // Notify UMAC to enter hangtime signalling mode on this traffic timeslot.
        // This stops downlink TCH fill frames (zeros) and enables UL CommonAndAssigned so MS can request the floor.
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
        });

        // Notify Brew to stop forwarding audio, if this SSI is cleared for Br
        if brew::is_brew_gssi_routable(&self.config, dest_ssi) {
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
            });
        }
    }

    /// Handle U-TX DEMAND: another radio requests floor during hangtime
    /// Response: send D-TX GRANTED via FACCH, resume voice path
    fn rx_u_tx_demand(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };
        let requesting_party = prim.received_tetra_address;

        let pdu = match UTxDemand::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-TX DEMAND {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-TX DEMAND: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;

        if self.individual_calls.contains_key(&call_id) {
            tracing::debug!("U-TX DEMAND for individual call_id={}, ignoring", call_id);
            return;
        }

        let Some(call) = self.active_calls.get_mut(&call_id) else {
            tracing::warn!("U-TX DEMAND for unknown call_id={}", call_id);
            return;
        };

        tracing::info!("U-TX DEMAND: ISSI {} requests floor on call_id={}", requesting_party.ssi, call_id);

        // Grant the floor to the requesting MS
        let ts = call.ts;
        call.tx_active = true;
        call.tx_grant_time = self.dltime;
        call.hangtime_start = None;
        call.source_issi = requesting_party.ssi;

        // Update caller_addr for local calls
        if let CallOrigin::Local { caller_addr } = &mut call.origin {
            *caller_addr = requesting_party;
        }

        let Some(cached) = self.cached_setups.get(&call_id) else {
            tracing::error!("No cached D-SETUP for call_id={}", call_id);
            return;
        };
        let dest_addr = cached.dest_addr;

        // ETSI 14.5.2.2.1 b): Send individual D-TX GRANTED (Granted) to requesting MS FIRST
        let d_tx_granted_individual = DTxGranted {
            call_identifier: call_id,
            transmission_grant: TransmissionGrant::Granted.into_raw() as u8,
            transmission_request_permission: false,
            encryption_control: false,
            reserved: false,
            notification_indicator: None,
            transmitting_party_type_identifier: Some(1), // SSI
            transmitting_party_address_ssi: Some(requesting_party.ssi as u64),
            transmitting_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::info!("-> D-TX GRANTED (individual, Granted) {:?}", d_tx_granted_individual);
        let mut sdu = BitBuffer::new_autoexpand(50);
        d_tx_granted_individual.to_bitbuf(&mut sdu).expect("Failed to serialize DTxGranted");
        sdu.seek(0);

        let requesting_addr = TetraAddress::new(requesting_party.ssi, SsiType::Issi);
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, requesting_addr, ts, None);
        queue.push_back(msg);

        // ETSI 14.5.2.2.1 b): Send group D-TX GRANTED (GrantedToOtherUser) to GSSI
        self.send_d_tx_granted_facch(queue, call_id, requesting_party.ssi, dest_addr.ssi, ts);

        // Notify UMAC to resume traffic mode (exit hangtime) for this timeslot.
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                call_id,
                source_issi: requesting_party.ssi,
                dest_gssi: dest_addr.ssi,
                ts,
            }),
        });

        // Notify Brew of speaker change (local MS taking floor)
        if brew::is_brew_gssi_routable(&self.config, dest_addr.ssi) {
            let Some(call) = self.active_calls.get(&call_id) else {
                return;
            };
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                    call_id,
                    source_issi: requesting_party.ssi,
                    dest_gssi: dest_addr.ssi,
                    ts: call.ts,
                }),
            });
        }
    }

    /// Handle U-RELEASE: radio explicitly releases the call
    fn rx_u_release(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };
        let sender = prim.received_tetra_address;

        let pdu = match URelease::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-RELEASE {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-RELEASE: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;
        let disconnect_cause = pdu.disconnect_cause;
        tracing::info!("U-RELEASE: call_id={} cause={}", call_id, disconnect_cause);
        if let Some(call_snapshot) = self.individual_calls.get(&call_id).cloned() {
            tracing::info!("U-RELEASE (individual) call_id={} cause={}", call_id, disconnect_cause);
            let sender_is_called = sender.ssi == call_snapshot.called_addr.ssi;
            if call_snapshot.state == IndividualCallState::Active || sender_is_called {
                self.send_d_disconnect_individual(queue, call_id, &call_snapshot, sender, disconnect_cause);
            }
            self.release_individual_call(queue, call_id, disconnect_cause);
        } else {
            self.release_group_call(queue, call_id, disconnect_cause);
        }
    }

    /// Handle U-DISCONNECT: MS requests call disconnection (ETSI 14.5.2.3.1)
    /// Call owner → release entire group call with D-RELEASE (cause=1)
    /// Non-call owner → reject with D-RELEASE cause=8 individually addressed to sender
    fn rx_u_disconnect(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        let SapMsgInner::LcmcMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };
        let sender = prim.received_tetra_address;
        let ul_handle = prim.handle;
        let ul_link_id = prim.link_id;
        let ul_endpoint_id = prim.endpoint_id;

        let pdu = match UDisconnect::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- U-DISCONNECT {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing U-DISCONNECT: {:?}", e);
                return;
            }
        };

        let call_id = pdu.call_identifier;
        let disconnect_cause = pdu.disconnect_cause;

        if let Some(call_snapshot) = self.individual_calls.get(&call_id).cloned() {
            tracing::info!("U-DISCONNECT (individual) call_id={} cause={}", call_id, disconnect_cause);
            let sender_is_called = sender.ssi == call_snapshot.called_addr.ssi;
            if call_snapshot.state == IndividualCallState::Active || sender_is_called {
                self.send_d_disconnect_individual(queue, call_id, &call_snapshot, sender, disconnect_cause);
            }
            self.release_individual_call(queue, call_id, disconnect_cause);
            return;
        }

        let Some(call) = self.active_calls.get(&call_id) else {
            tracing::debug!("U-DISCONNECT for unknown call_id={} (likely duplicate)", call_id);
            return;
        };

        let is_call_owner = matches!(&call.origin, CallOrigin::Local { caller_addr } if caller_addr.ssi == sender.ssi);

        if is_call_owner {
            // Call owner: tear down the entire group call
            tracing::info!("U-DISCONNECT: call owner ISSI {} disconnecting call_id={}", sender.ssi, call_id);
            self.release_group_call(queue, call_id, DisconnectCause::UserRequestedDisconnection);
        } else {
            // Non-call owner: reject with D-RELEASE cause=8 ("Requested service not available")
            // individually addressed back to the sender. The group call continues.
            tracing::info!(
                "U-DISCONNECT: non-call-owner ISSI {} rejected for call_id={} cause={}",
                sender.ssi,
                call_id,
                disconnect_cause
            );

            let d_release = DRelease {
                call_identifier: call_id,
                disconnect_cause: DisconnectCause::RequestedServiceNotAvailable,
                notification_indicator: None,
                facility: None,
                proprietary: None,
            };
            tracing::info!("-> {:?} (to ISSI {})", d_release, sender.ssi);

            let mut sdu = BitBuffer::new_autoexpand(32);
            d_release.to_bitbuf(&mut sdu).expect("Failed to serialize DRelease");
            sdu.seek(0);

            let sender_addr = TetraAddress::new(sender.ssi, SsiType::Issi);
            let msg = SapMsg {
                sap: Sap::LcmcSap,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Mle,
                dltime: self.dltime,
                msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                    sdu,
                    handle: ul_handle,
                    endpoint_id: ul_endpoint_id,
                    link_id: ul_link_id,
                    layer2service: 0,
                    pdu_prio: 0,
                    layer2_qos: 0,
                    stealing_permission: false,
                    stealing_repeats_flag: false,
                    chan_alloc: None,
                    main_address: sender_addr,
                    tx_reporter: None,
                }),
            };
            queue.push_back(msg);
        }
    }

    /// Handle incoming CallControl messages from Brew
    pub fn rx_call_control(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        let SapMsgInner::CmceCallControl(call_control) = message.msg else {
            panic!("Expected CmceCallControl message");
        };

        match call_control {
            CallControl::NetworkCallStart {
                brew_uuid,
                source_issi,
                dest_gssi,
                priority,
            } => {
                self.rx_network_call_start(queue, brew_uuid, source_issi, dest_gssi, priority);
            }
            CallControl::NetworkCallEnd { brew_uuid } => {
                self.rx_network_call_end(queue, brew_uuid);
            }
            CallControl::UplinkSilence { ts } => {
                self.rx_uplink_silence(queue, ts);
            }
            _ => {
                tracing::warn!("Unexpected CallControl message: {:?}", call_control);
            }
        }
    }

    /// Handle sustained UL silence notification from UMAC (BFI threshold exceeded).
    ///
    /// UMAC fires this after seeing a run of consecutive Bad Frames on a traffic timeslot,
    /// meaning the transmitting MS has almost certainly gone off-air (RF loss or battery death).
    /// We treat it as an implicit U-TX-CEASED: force the call into hangtime so the timeslot
    /// and circuit are released naturally within ~5 seconds, rather than hanging forever.
    fn rx_uplink_silence(&mut self, queue: &mut MessageQueue, ts: u8) {
        // Find the active call on this timeslot that is currently transmitting.
        let Some(call_id) = self
            .active_calls
            .iter()
            .find(|(_, c)| c.ts == ts && c.tx_active && c.hangtime_start.is_none())
            .map(|(id, _)| *id)
        else {
            // No tx-active call on this slot — silence during hangtime is normal, ignore.
            tracing::trace!("rx_uplink_silence: no tx-active call on ts={}, ignoring", ts);
            return;
        };

        let (dest_gssi, brew_uuid_opt) = {
            let call = self.active_calls.get(&call_id).unwrap();
            tracing::warn!(
                "CMCE: UL silence on ts={} call_id={} gssi={} speaker_issi={}:                  forcing floor release (MS went off-air)",
                ts, call_id, call.dest_gssi, call.source_issi
            );
            (call.dest_gssi, call.brew_uuid)
        };

        // Transition to hangtime — identical to what U-TX-CEASED does.
        {
            let call = self.active_calls.get_mut(&call_id).unwrap();
            call.tx_active = false;
            call.hangtime_start = Some(self.dltime);
            call.brew_uuid = None;
        }

        // Notify group members (D-TX-CEASED via FACCH).
        self.send_d_tx_ceased_facch(queue, call_id, dest_gssi, ts);

        // Tell UMAC to enter hangtime signalling mode.
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Umac,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
        });

        // Notify Brew if applicable.
        if brew::is_brew_gssi_routable(&self.config, dest_gssi) {
            if let Some(brew_uuid) = brew_uuid_opt {
                queue.push_back(SapMsg {
                    sap: Sap::Control,
                    src: TetraEntity::Cmce,
                    dest: TetraEntity::Brew,
                    dltime: self.dltime,
                    msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd { brew_uuid }),
                });
            }
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
            });
        }
        // The call is now in hangtime; check_hangtime_expiry() will release it ~5 s later.
    }

    /// Handle network-initiated group call start
    fn rx_network_call_start(&mut self, queue: &mut MessageQueue, brew_uuid: uuid::Uuid, source_issi: u32, dest_gssi: u32, _priority: u8) {
        assert!(brew::is_brew_gssi_routable(&self.config, dest_gssi));

        if !self.has_listener(dest_gssi) {
            tracing::info!(
                "CMCE: ignoring network call start uuid={} gssi={} (no listeners)",
                brew_uuid,
                dest_gssi
            );
            self.drop_group_calls_if_unlistened(queue, dest_gssi);

            // We already checked this is cleared for brew
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallEnd { brew_uuid }),
            });
            return;
        }

        // Check if there's an active call for this GSSI (speaker change scenario)
        if let Some((call_id, call)) = self.active_calls.iter_mut().find(|(_, c)| c.dest_gssi == dest_gssi) {
            // Speaker change during active or hangtime
            tracing::info!(
                "CMCE: network call speaker change gssi={} new_speaker={} (was {})",
                dest_gssi,
                source_issi,
                call.source_issi
            );

            call.source_issi = source_issi;
            call.tx_active = true;
            call.tx_grant_time = self.dltime;
            call.hangtime_start = None;
            call.brew_uuid = Some(brew_uuid);

            if let CallOrigin::Network { brew_uuid: old_uuid } = call.origin {
                // Update UUID if different (shouldn't happen but handle it)
                if old_uuid != brew_uuid {
                    tracing::warn!("CMCE: brew_uuid changed during speaker change");
                    call.origin = CallOrigin::Network { brew_uuid };
                }
            }

            // Extract values before mutable borrow ends
            let call_id_val = *call_id;
            let ts = call.ts;
            let usage = call.usage;

            // End the mutable borrow
            let _ = call;

            // Send D-TX GRANTED via FACCH to notify radios of new speaker
            self.send_d_tx_granted_facch(queue, call_id_val, source_issi, dest_gssi, ts);

            // Notify UMAC to resume traffic mode (exit hangtime) for this timeslot.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorGranted {
                    call_id: call_id_val,
                    source_issi,
                    dest_gssi,
                    ts,
                }),
            });

            // Respond to Brew with existing call resources, we already ensured it is cleared for brew
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Brew,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallReady {
                    brew_uuid,
                    call_id: call_id_val,
                    ts,
                    usage,
                }),
            });
            return;
        }

        // New network call - allocate circuit
        let circuit = match {
            let mut state = self.config.state_write();
            self.circuits.allocate_circuit_with_allocator(
                Direction::Both,
                CommunicationType::P2Mp,
                false,
                &mut state.timeslot_alloc,
                TimeslotOwner::Cmce,
            )
        } {
            Ok(c) => c.clone(),
            Err(err) => {
                tracing::warn!("CMCE: failed to allocate circuit for network call: {:?}", err);
                return;
            }
        };

        let call_id = circuit.call_id;
        let ts = circuit.ts;
        let usage = circuit.usage;

        tracing::info!(
            "CMCE: starting NEW network call brew_uuid={} gssi={} speaker={} ts={} call_id={}",
            brew_uuid,
            dest_gssi,
            source_issi,
            ts,
            call_id
        );

        // Signal UMAC to open DL and UL circuits
        Self::signal_umac_circuit_open(queue, &circuit, self.dltime, None);

        tracing::debug!(
            "CMCE: sending D-SETUP for NEW call call_id={} gssi={} (network-initiated)",
            call_id,
            dest_gssi
        );

        // Send D-SETUP to group (broadcast on MCCH)
        let dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);
        let d_setup = DSetup {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: false,
            simplex_duplex_selection: false, // Simplex
            basic_service_information: BasicServiceInformation {
                circuit_mode_type: CircuitModeType::TchS,
                encryption_flag: false,
                communication_type: CommunicationType::P2Mp,
                slots_per_frame: None,
                speech_service: Some(0),
            },
            transmission_grant: TransmissionGrant::GrantedToOtherUser,
            transmission_request_permission: false,
            call_priority: 0,
            notification_indicator: None,
            temporary_address: None,
            calling_party_address_ssi: Some(source_issi),
            calling_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        // Cache for late-entry re-sends
        self.cached_setups.insert(
            call_id,
            CachedSetup {
                pdu: d_setup,
                dest_addr: dest_addr.clone(),
                resend: true,
            },
        );
        let d_setup_ref = &self.cached_setups.get(&call_id).unwrap().pdu;

        let (setup_sdu, setup_chan_alloc) = Self::build_d_setup_prim(d_setup_ref, usage, ts, UlDlAssignment::Both);
        let setup_msg = Self::build_sapmsg(setup_sdu, Some(setup_chan_alloc), self.dltime, dest_addr.clone(), None);
        queue.push_back(setup_msg);

        // Send D-CONNECT to group
        let d_connect = DConnect {
            call_identifier: call_id,
            call_time_out: CallTimeout::T5m,
            hook_method_selection: false,
            simplex_duplex_selection: false, // Simplex
            transmission_grant: TransmissionGrant::GrantedToOtherUser,
            transmission_request_permission: false,
            call_ownership: false,
            call_priority: None,
            basic_service_information: None,
            temporary_address: None,
            notification_indicator: None,
            facility: None,
            proprietary: None,
        };

        let mut connect_sdu = BitBuffer::new_autoexpand(30);
        d_connect.to_bitbuf(&mut connect_sdu).expect("Failed to serialize DConnect");
        connect_sdu.seek(0);

        let connect_msg = SapMsg {
            sap: Sap::LcmcSap,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Mle,
            dltime: self.dltime,
            msg: SapMsgInner::LcmcMleUnitdataReq(LcmcMleUnitdataReq {
                sdu: connect_sdu,
                handle: 0, // Broadcast to group, no specific handle
                endpoint_id: 0,
                link_id: 0,
                layer2service: 0,
                pdu_prio: 0,
                layer2_qos: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                chan_alloc: None, // Already sent in D-SETUP
                main_address: dest_addr,
                tx_reporter: None,
            }),
        };
        queue.push_back(connect_msg);

        // Track the active call
        self.active_calls.insert(
            call_id,
            ActiveCall {
                origin: CallOrigin::Network { brew_uuid },
                dest_gssi,
                source_issi,
                ts,
                usage,
                tx_active: true,
                tx_grant_time: self.dltime,
                hangtime_start: None,
                brew_uuid: Some(brew_uuid),
            },
        );

        // Respond to Brew with allocated resources, we already ensured it is cleared for brew
        queue.push_back(SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Cmce,
            dest: TetraEntity::Brew,
            dltime: self.dltime,
            msg: SapMsgInner::CmceCallControl(CallControl::NetworkCallReady {
                brew_uuid,
                call_id,
                ts,
                usage,
            }),
        });
    }

    /// Handle network call end request
    fn rx_network_call_end(&mut self, queue: &mut MessageQueue, brew_uuid: uuid::Uuid) {
        // Find the call by brew_uuid field (works for both Local and Network origin calls)
        let Some((call_id, call)) = self
            .active_calls
            .iter()
            .find(|(_, c)| c.brew_uuid == Some(brew_uuid))
            .map(|(id, c)| (*id, c.clone()))
        else {
            tracing::debug!("CMCE: network call end for unknown brew_uuid={}", brew_uuid);
            return;
        };

        tracing::info!(
            "CMCE: network call ended brew_uuid={} call_id={} gssi={}",
            brew_uuid,
            call_id,
            call.dest_gssi
        );

        // If currently transmitting, enter hangtime instead of immediate release
        let tx_active = call.tx_active;
        let dest_gssi = call.dest_gssi;
        let ts = call.ts;

        if tx_active {
            if let Some(active_call) = self.active_calls.get_mut(&call_id) {
                active_call.tx_active = false;
                active_call.hangtime_start = Some(self.dltime);
                active_call.brew_uuid = None;
            }
            // Send D-TX CEASED via FACCH
            self.send_d_tx_ceased_facch(queue, call_id, dest_gssi, ts);

            // Notify UMAC to enter hangtime signalling mode on this traffic timeslot.
            queue.push_back(SapMsg {
                sap: Sap::Control,
                src: TetraEntity::Cmce,
                dest: TetraEntity::Umac,
                dltime: self.dltime,
                msg: SapMsgInner::CmceCallControl(CallControl::FloorReleased { call_id, ts }),
            });
        } else {
            // Already in hangtime or idle, release immediately
            self.release_group_call(queue, call_id, DisconnectCause::SwmiRequestedDisconnection);
        }
    }

    /// Send D-TX GRANTED via FACCH stealing
    fn send_d_tx_granted_facch(&mut self, queue: &mut MessageQueue, call_id: u16, source_issi: u32, dest_gssi: u32, ts: u8) {
        let pdu = DTxGranted {
            call_identifier: call_id,
            transmission_grant: TransmissionGrant::GrantedToOtherUser.into_raw() as u8,
            transmission_request_permission: false,
            encryption_control: false,
            reserved: false,
            notification_indicator: None,
            transmitting_party_type_identifier: Some(1), // SSI
            transmitting_party_address_ssi: Some(source_issi as u64),
            transmitting_party_extension: None,
            external_subscriber_number: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::debug!("-> D-TX GRANTED (FACCH) {:?}", pdu);
        let mut sdu = BitBuffer::new_autoexpand(30);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DTxGranted");
        sdu.seek(0);

        let dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, dest_addr, ts, None);
        queue.push_back(msg);
    }

    /// Send D-TX CEASED via FACCH stealing
    fn send_d_tx_ceased_facch(&mut self, queue: &mut MessageQueue, call_id: u16, dest_gssi: u32, ts: u8) {
        let pdu = DTxCeased {
            call_identifier: call_id,
            transmission_request_permission: false, // ETSI 14.8.43: 0 = allowed to request transmission
            notification_indicator: None,
            facility: None,
            dm_ms_address: None,
            proprietary: None,
        };

        tracing::debug!("-> D-TX CEASED (FACCH) {:?}", pdu);
        let mut sdu = BitBuffer::new_autoexpand(30);
        pdu.to_bitbuf(&mut sdu).expect("Failed to serialize DTxCeased");
        sdu.seek(0);

        let dest_addr = TetraAddress::new(dest_gssi, SsiType::Gssi);
        let msg = Self::build_sapmsg_stealing(sdu, self.dltime, dest_addr, ts, None);
        queue.push_back(msg);
    }
}
