use std::collections::HashMap;
use std::fmt::Write as _;

use crate::{MessageQueue, TetraEntityTrait, brew};
use tetra_config::bluestation::SharedConfig;
use tetra_core::tetra_entities::TetraEntity;
use tetra_core::{BitBuffer, Sap, SsiType, TdmaTime, TetraAddress, assert_warn, unimplemented_log};
use tetra_saps::control::brew::{BrewSubscriberAction, MmSubscriberUpdate};
use tetra_saps::lmm::LmmMleUnitdataReq;
use tetra_saps::{SapMsg, SapMsgInner};

use crate::mm::components::client_state::{MmClientMgr, MmClientState};
use crate::mm::components::auth_taa1::{
    compute_ta11_ta12, derive_dck_from_dck1, seal_cck_with_dck,
};
use crate::mm::components::not_supported::make_ul_mm_pdu_function_not_supported;
use tetra_pdus::mm::enums::location_update_type::LocationUpdateType;
use tetra_pdus::mm::enums::mm_pdu_type_ul::MmPduTypeUl;
use tetra_pdus::mm::enums::status_uplink::StatusUplink;
use tetra_pdus::mm::fields::authentication_downlink::AuthenticationDownlink;
use tetra_pdus::mm::fields::group_identity_attachment::GroupIdentityAttachment;
use tetra_pdus::mm::fields::group_identity_downlink::GroupIdentityDownlink;
use tetra_pdus::mm::fields::group_identity_location_accept::GroupIdentityLocationAccept;
use tetra_pdus::mm::fields::group_identity_uplink::GroupIdentityUplink;
use tetra_pdus::mm::pdus::d_authentication::DAuthentication;
use tetra_pdus::mm::pdus::d_attach_detach_group_identity_acknowledgement::DAttachDetachGroupIdentityAcknowledgement;
use tetra_pdus::mm::pdus::d_ck_change_demand::{DCkChangeDemand, SckData as DCkSckData};
use tetra_pdus::mm::pdus::d_location_update_accept::DLocationUpdateAccept;
use tetra_pdus::mm::pdus::d_location_update_command::DLocationUpdateCommand;
use tetra_pdus::mm::pdus::d_location_update_reject::DLocationUpdateReject;
use tetra_pdus::mm::pdus::d_otar::DOtarCckProvide;
use tetra_pdus::mm::pdus::u_attach_detach_group_identity::UAttachDetachGroupIdentity;
use tetra_pdus::mm::pdus::u_authentication::UAuthentication;
use tetra_pdus::mm::pdus::u_itsi_detach::UItsiDetach;
use tetra_pdus::mm::pdus::u_ck_change_result::UCkChangeResult;
use tetra_pdus::mm::pdus::u_location_update_demand::ULocationUpdateDemand;
use tetra_pdus::mm::pdus::u_mm_status::UMmStatus;
use tetra_pdus::mm::pdus::u_otar::UOtar;

const AUTH_REJECT_CAUSE: u8 = 1;
const AUTH_REJECT_NOT_SUPPORTED: u8 = 0;

#[derive(Clone, Copy, Debug)]
struct PendingAuthChallenge {
    rand1: [u8; 10],
    rs: [u8; 10],
    dck: [u8; 10],
    expected_res1: u32,
    issued_at: TdmaTime,
}

#[derive(Clone, Debug)]
struct PendingLocationUpdate {
    location_update_type: LocationUpdateType,
    group_identity_uplink: Option<Vec<GroupIdentityUplink>>,
    cipher_control: bool,
    ciphering_parameters: Option<u64>,
    handle: u32,
    issued_at: TdmaTime,
}

#[derive(Clone, Copy, Debug)]
struct PendingTeaProvision {
    cck_id: u16,
    cck: [u8; 10],
    issued_at: TdmaTime,
}

#[derive(Clone, Copy, Debug)]
struct AuthDerivedDck {
    dck: [u8; 10],
    issued_at: TdmaTime,
}

#[derive(Clone, Debug)]
struct PendingCkChange {
    entries: Vec<(u8, u16)>,
    issued_at: TdmaTime,
}

type AnnouncedSck = (u8, u16);

pub struct MmBs {
    config: SharedConfig,
    pub client_mgr: MmClientMgr,
    pending_auth: HashMap<u32, PendingAuthChallenge>,
    pending_location_update: HashMap<u32, PendingLocationUpdate>,
    pending_tea_provision: HashMap<u32, PendingTeaProvision>,
    auth_derived_dck: HashMap<u32, AuthDerivedDck>,
    pending_ck_change: HashMap<u32, PendingCkChange>,
    announced_sck: HashMap<u32, AnnouncedSck>,
    authenticated_ms: HashMap<u32, TdmaTime>,
}

impl MmBs {
    fn make_authentication_downlink_result_only() -> AuthenticationDownlink {
        // Carries authentication_result=true with no CK provision.
        // SCK is pre-loaded in the MS; key activation is handled separately via D-CK CHANGE DEMAND.
        AuthenticationDownlink {
            authentication_result: true,
            tei_request_flag: false,
            ck_provision_information: None,
        }
    }

    pub fn new(config: SharedConfig) -> Self {
        let this = Self {
            config,
            client_mgr: MmClientMgr::new(),
            pending_auth: HashMap::new(),
            pending_location_update: HashMap::new(),
            pending_tea_provision: HashMap::new(),
            auth_derived_dck: HashMap::new(),
            pending_ck_change: HashMap::new(),
            announced_sck: HashMap::new(),
            authenticated_ms: HashMap::new(),
        };
        this.log_ms_auth_config();
        tracing::info!("MM SC2 registration fixes active (mutual-auth downgrade + deferred-LU completion)");
        this
    }

    fn selected_class2_sck(&self) -> Option<AnnouncedSck> {
        let cfg = self.config.config();
        if !cfg.cell.aie_service {
            return None;
        }
        let ms_auth = cfg.ms_auth.as_ref()?;
        if !ms_auth.enabled {
            return None;
        }
        let selected = ms_auth.select_tmo_sck_material()?;
        Some((selected.sck_n, selected.sck_vn))
    }

    fn selected_class2_already_announced(&self, issi: u32) -> bool {
        self.selected_class2_sck()
            .is_some_and(|selected| self.announced_sck.get(&issi).is_some_and(|announced| *announced == selected))
    }

    fn remember_pending_location_update_from_demand(
        &mut self,
        issi: u32,
        handle: u32,
        dltime: TdmaTime,
        pdu: &ULocationUpdateDemand,
    ) {
        let group_identity_uplink = pdu
            .group_identity_location_demand
            .as_ref()
            .and_then(|gild| gild.group_identity_uplink.clone());
        self.pending_location_update.insert(
            issi,
            PendingLocationUpdate {
                location_update_type: pdu.location_update_type,
                group_identity_uplink,
                cipher_control: pdu.cipher_control,
                ciphering_parameters: pdu.ciphering_parameters,
                handle,
                issued_at: dltime,
            },
        );
    }

    fn parse_class2_ciphering_parameters(ciphering_parameters: u64) -> (u8, bool, u8) {
        let ksg_number = ((ciphering_parameters >> 6) & 0x0f) as u8;
        let security_class3 = ((ciphering_parameters >> 5) & 0x01) != 0;
        let sck_number = (ciphering_parameters & 0x1f) as u8;
        (ksg_number, security_class3, sck_number)
    }

    fn pending_lu_requests_selected_class2(&self, pending: &PendingLocationUpdate) -> bool {
        let Some((expected_sck_n, _expected_sck_vn)) = self.selected_class2_sck() else {
            return false;
        };
        let Some(ciphering_parameters) = pending.ciphering_parameters else {
            return false;
        };
        if !pending.cipher_control {
            return false;
        }

        let (_ksg_number, security_class3, requested_sck_n) = Self::parse_class2_ciphering_parameters(ciphering_parameters);
        !security_class3 && requested_sck_n == expected_sck_n
    }

    fn emit_subscriber_update(
        &self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        groups: Vec<u32>,
        action: BrewSubscriberAction,
    ) {
        // If brew is active, take all brew-routable groups and emit an update to brew entity
        if brew::is_active(&self.config) {
            let brew_groups = groups
                .iter()
                .filter(|gssi| brew::is_brew_gssi_routable(&self.config, **gssi))
                .copied()
                .collect::<Vec<u32>>();
            if !brew_groups.is_empty() {
                let brew_update = MmSubscriberUpdate {
                    issi,
                    groups: brew_groups,
                    action,
                };
                let msg = SapMsg {
                    sap: Sap::Control,
                    src: TetraEntity::Mm,
                    dest: TetraEntity::Brew,
                    dltime,
                    msg: SapMsgInner::MmSubscriberUpdate(brew_update),
                };
                queue.push_back(msg);
            }
        }

        // Always emit an update to the Cmce entity
        let mm_update = MmSubscriberUpdate { issi, groups, action };
        let msg = SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Mm,
            dest: TetraEntity::Cmce,
            dltime,
            msg: SapMsgInner::MmSubscriberUpdate(mm_update),
        };
        queue.push_back(msg);
    }

    fn log_ms_auth_config(&self) {
        let cfg = self.config.config();
        let Some(ms_auth) = cfg.ms_auth.as_ref() else {
            tracing::info!("MS auth is disabled (no [ms_auth] config)");
            return;
        };

        if !ms_auth.enabled {
            tracing::info!("MS auth is configured but disabled (ms_auth.enabled=false)");
            return;
        }

        let mut issis: Vec<u32> = ms_auth.subscribers.keys().copied().collect();
        issis.sort_unstable();

        tracing::info!(
            "MS auth enabled: loaded {} key(s), ttl={} slots, log_plain_k={}, tea_kmf_enable={}, ck_change_ack_required={}",
            issis.len(),
            ms_auth.challenge_ttl_slots,
            ms_auth.log_plain_k,
            ms_auth.tea_kmf_enable,
            ms_auth.ck_change_ack_required
        );

        for issi in issis {
            if let Some(k_value) = ms_auth.subscribers.get(&issi) {
                tracing::info!(
                    "MS auth configured key ISSI {}: {}",
                    issi,
                    Self::k_log_value(k_value, ms_auth.log_plain_k)
                );
            }
        }

        if !ms_auth.sck_material.is_empty() {
            tracing::info!("Loaded {} static SCK material entry/entries", ms_auth.sck_material.len());
            for entry in &ms_auth.sck_material {
                if ms_auth.log_plain_k {
                    tracing::info!(
                        "SCK material SCKN={} SCK-VN={} SCK={}",
                        entry.sck_n,
                        entry.sck_vn,
                        Self::k_hex(&entry.sck)
                    );
                } else {
                    tracing::info!(
                        "SCK material SCKN={} SCK-VN={} SCK fp={}",
                        entry.sck_n,
                        entry.sck_vn,
                        Self::k_fingerprint(&entry.sck)
                    );
                }
            }

            if let Some(selected) = ms_auth.select_tmo_sck_material() {
                tracing::info!(
                    "Selected TMO SCK material SCKN={} SCK-VN={} (used for D-CK CHANGE + AIE)",
                    selected.sck_n,
                    selected.sck_vn
                );
                if selected.sck_n < 30 {
                    tracing::warn!(
                        "Selected TMO SCKN={} is outside reserved TMO range 30..31",
                        selected.sck_n
                    );
                }
            } else {
                tracing::warn!(
                    "No valid TMO SCK material selected (need SCK-VN in 1..3); AIE/CK-change signaling will stay disabled"
                );
            }
        }

        if let Some(material_id) = ms_auth.key_material_id {
            tracing::info!("Configured key_material_id=0x{:08X}", material_id);
        }
    }

    fn k_hex(k_value: &[u8]) -> String {
        let mut out = String::with_capacity(k_value.len() * 2);
        for byte in k_value {
            let _ = write!(&mut out, "{:02X}", byte);
        }
        out
    }

    fn k_fingerprint(k_value: &[u8]) -> String {
        let digest = md5::compute(k_value);
        format!("{:02x}{:02x}{:02x}{:02x}", digest.0[0], digest.0[1], digest.0[2], digest.0[3])
    }

    fn k_log_value(k_value: &[u8], log_plain_k: bool) -> String {
        let fp = Self::k_fingerprint(k_value);
        let k_hex = Self::k_hex(k_value);
        if log_plain_k {
            format!("{} (len={} fp={})", k_hex, k_value.len(), fp)
        } else if k_hex.len() <= 8 {
            format!("{} (len={} fp={})", k_hex, k_value.len(), fp)
        } else {
            format!(
                "{}...{} (len={} fp={})",
                &k_hex[..8],
                &k_hex[k_hex.len() - 8..],
                k_value.len(),
                fp
            )
        }
    }

    fn prune_stale_auth_challenges(&mut self, now: TdmaTime, challenge_ttl_slots: i32) {
        self.pending_auth.retain(|_, pending| pending.issued_at.age(now) <= challenge_ttl_slots);
        self.pending_location_update
            .retain(|_, pending| pending.issued_at.age(now) <= challenge_ttl_slots);
        self.pending_tea_provision
            .retain(|_, pending| pending.issued_at.age(now) <= challenge_ttl_slots);
        self.auth_derived_dck
            .retain(|_, pending| pending.issued_at.age(now) <= challenge_ttl_slots);

        let mut stale_ck_issis = Vec::new();
        self.pending_ck_change.retain(|issi, pending| {
            let keep = pending.issued_at.age(now) <= challenge_ttl_slots;
            if !keep {
                stale_ck_issis.push(*issi);
            }
            keep
        });

        for issi in stale_ck_issis {
            if let Some((sck_n, sck_vn)) = self.announced_sck.remove(&issi) {
                tracing::warn!(
                    "ISSI {} did not send U-CK CHANGE RESULT within {} slots for SCKN={} SCK-VN={}; allowing re-announce",
                    issi,
                    challenge_ttl_slots,
                    sck_n,
                    sck_vn
                );
            }
        }

        self.authenticated_ms.retain(|_, issued_at| issued_at.age(now) <= challenge_ttl_slots);
    }

    fn send_location_update_auth_challenge(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        rand1: [u8; 10],
        rs: [u8; 10],
    ) {
        let pdu = DAuthentication::Demand { rand1, rs };
        Self::send_d_authentication(queue, dltime, issi, handle, pdu);
    }

    fn send_d_authentication(queue: &mut MessageQueue, dltime: TdmaTime, issi: u32, handle: u32, pdu: DAuthentication) {
        let mut sdu = BitBuffer::new_autoexpand(128);
        pdu.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_otar_cck_provide(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        pdu: DOtarCckProvide,
    ) {
        let mut sdu = BitBuffer::new_autoexpand(224);
        pdu.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_ck_change_demand(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        pdu: DCkChangeDemand,
    ) {
        let mut sdu = BitBuffer::new_autoexpand(128);
        pdu.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn maybe_send_sck_change_demand_after_auth(&mut self, queue: &mut MessageQueue, dltime: TdmaTime, issi: u32, handle: u32) {
        let cfg = self.config.config();
        let Some(ms_auth) = cfg.ms_auth.as_ref() else {
            return;
        };
        if !ms_auth.enabled {
            return;
        }

        let Some(selected) = ms_auth.select_tmo_sck_material() else {
            tracing::warn!(
                "Skipping D-CK CHANGE DEMAND to ISSI {}: no valid SCK material found (need SCK-VN in 1..3)",
                issi
            );
            return;
        };

        let selected_sck = (selected.sck_n, selected.sck_vn);
        if self.announced_sck.get(&issi).is_some_and(|announced| *announced == selected_sck) {
            if self.pending_ck_change.contains_key(&issi) {
                tracing::warn!(
                    "ISSI {} has pending U-CK CHANGE RESULT for SCKN={} SCK-VN={}; sending one-way D-CK CHANGE DEMAND fallback (ack=false)",
                    issi,
                    selected.sck_n,
                    selected.sck_vn
                );

                let fallback_pdu = DCkChangeDemand {
                    acknowledgement_flag: false,
                    // ETSI EN 300 392-7 Table 16.53: 0b10 = change to SC2/AIE
                    change_of_security_class: 2,
                    key_change_type: 0,
                    // ETSI A.4.1: sck_use=0 for TMO, 1 for DMO.
                    sck_use: Some(false),
                    sck_data: vec![DCkSckData {
                        sck_number: selected.sck_n,
                        sck_version: selected.sck_vn,
                    }],
                    time_type: 2,
                };

                Self::send_d_ck_change_demand(queue, dltime, issi, handle, fallback_pdu);
                self.pending_ck_change.remove(&issi);
            } else {
                // We reach here only when announced_sck matches but pending_ck_change is empty,
                // meaning the radio already ACKed this key selection.  Safe to skip.
                tracing::info!(
                    "Skipping D-CK CHANGE DEMAND to ISSI {}: SCKN={} SCK-VN={} already announced and ACK received",
                    issi,
                    selected.sck_n,
                    selected.sck_vn
                );
            }
            return;
        }

        let ack_required = ms_auth.ck_change_ack_required;

        if selected.sck_n < 30 {
            tracing::warn!(
                "ISSI {} CK change uses SCKN={} (non-TMO-reserved range); prefer SCKN 30..31 for TMO",
                issi,
                selected.sck_n
            );
        }

        let pdu = DCkChangeDemand {
            acknowledgement_flag: ack_required,
            // ETSI EN 300 392-7 Table 16.53 / clause 16.10.3:
            //   0b00 = No change of security class  (WRONG - radio ignores SCK, never replies)
            //   0b10 = Change to Security Class 2   (CORRECT - commands SC2/AIE activation)
            change_of_security_class: 2,
            key_change_type: 0,
            // ETSI A.4.1: sck_use=0 for TMO, 1 for DMO.
            sck_use: Some(false),
            sck_data: vec![DCkSckData {
                sck_number: selected.sck_n,
                sck_version: selected.sck_vn,
            }],
            time_type: 2,
        };

        tracing::info!(
            "Sending D-CK CHANGE DEMAND to ISSI {} (SCKN={}, SCK-VN={}, ack={}, time_type=2, change_of_security_class=2[SC2/AIE])",
            issi,
            selected.sck_n,
            selected.sck_vn,
            ack_required
        );
        if ms_auth.log_plain_k {
            tracing::debug!(
                "Using configured SCK material for ISSI {}: SCK={} (SCKN={}, SCK-VN={})",
                issi,
                Self::k_hex(&selected.sck),
                selected.sck_n,
                selected.sck_vn
            );
        } else {
            tracing::debug!(
                "Using configured SCK material for ISSI {}: SCK fp={} (SCKN={}, SCK-VN={})",
                issi,
                Self::k_fingerprint(&selected.sck),
                selected.sck_n,
                selected.sck_vn
            );
        }
        Self::send_d_ck_change_demand(queue, dltime, issi, handle, pdu);
        self.announced_sck.insert(issi, selected_sck);
        if ack_required {
            self.pending_ck_change.insert(
                issi,
                PendingCkChange {
                    entries: vec![(selected.sck_n, selected.sck_vn)],
                    issued_at: dltime,
                },
            );
        } else {
            self.pending_ck_change.remove(&issi);
        }
    }

    fn maybe_send_tea_key_after_auth(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        dck: [u8; 10],
    ) {
        let cfg = self.config.config();
        let Some(ms_auth) = cfg.ms_auth.as_ref() else {
            return;
        };
        if !ms_auth.enabled || !ms_auth.tea_kmf_enable {
            return;
        }

        let mut cck = [0u8; 10];
        for b in cck.iter_mut() {
            *b = rand::random::<u8>();
        }

        let mut cck_id = ms_auth
            .key_material_id
            .map(|id| (id & 0xFFFF) as u16)
            .unwrap_or_else(rand::random::<u16>);
        if cck_id == 0 {
            cck_id = 1;
        }

        let scck = seal_cck_with_dck(&dck, cck_id, &cck);

        let pdu = DOtarCckProvide {
            cck_provision_flag: true,
            cck_id: Some(cck_id),
            key_type_flag: Some(false),
            scck: Some(scck),
            cck_location_area_type: Some(0),
            future_key_flag: Some(false),
            future_scck: None,
        };

        if ms_auth.log_plain_k {
            tracing::info!(
                "Provisioning TEA CCK to ISSI {} via OTAR (CCK-id=0x{:04X}, CCK={}, DCK={})",
                issi,
                cck_id,
                Self::k_hex(&cck),
                Self::k_hex(&dck)
            );
        } else {
            tracing::info!(
                "Provisioning TEA CCK to ISSI {} via OTAR (CCK-id=0x{:04X}, CCK fp={}, DCK fp={})",
                issi,
                cck_id,
                Self::k_fingerprint(&cck),
                Self::k_fingerprint(&dck)
            );
        }

        Self::send_d_otar_cck_provide(queue, dltime, issi, handle, pdu);
        self.pending_tea_provision.insert(
            issi,
            PendingTeaProvision {
                cck_id,
                cck,
                issued_at: dltime,
            },
        );
        self.auth_derived_dck.insert(
            issi,
            AuthDerivedDck {
                dck,
                issued_at: dltime,
            },
        );
    }

    /// Returns true when the MS is authenticated for this location update flow.
    /// Returns false when a challenge is sent or the update is rejected.
    /// Returns `None` if the LU should be rejected or deferred (no further action needed),
    /// `Some(false)` if LU should proceed with a plain downlink,
    /// `Some(true)` if LU should proceed with an encrypted downlink (SC2 key already activated
    /// by the MS — BS must encrypt the D-LU-ACCEPT to prove it holds the matching SCK).
    fn handle_location_update_auth(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        pdu: &ULocationUpdateDemand,
        uplink_encrypted: bool,
    ) -> Option<bool> {
        let cfg = self.config.config();
        let Some(ms_auth) = cfg.ms_auth.as_ref() else {
            return Some(false);
        };
        if !ms_auth.enabled {
            return Some(false);
        }

        self.prune_stale_auth_challenges(dltime, ms_auth.challenge_ttl_slots);

        let Some(k_value) = ms_auth.subscribers.get(&issi) else {
            tracing::warn!("Rejecting location update for ISSI {}: no K configured", issi);
            self.pending_auth.remove(&issi);
            self.pending_location_update.remove(&issi);
            self.pending_tea_provision.remove(&issi);
            self.auth_derived_dck.remove(&issi);
            self.pending_ck_change.remove(&issi);
            self.announced_sck.remove(&issi);
            self.authenticated_ms.remove(&issi);
            Self::send_d_location_update_reject(queue, dltime, issi, handle, pdu.location_update_type, AUTH_REJECT_CAUSE, false);
            return None;
        };

        tracing::info!(
            "MS auth key for ISSI {}: {}",
            issi,
            Self::k_log_value(k_value, ms_auth.log_plain_k)
        );

        if self.authenticated_ms.contains_key(&issi) {
            if let Some((expected_sck_n, expected_sck_vn)) = self.selected_class2_sck() {
                let ck_select_already_attempted = self
                    .announced_sck
                    .get(&issi)
                    .is_some_and(|announced| *announced == (expected_sck_n, expected_sck_vn));

                let Some(ciphering_parameters) = pdu.ciphering_parameters else {
                    self.remember_pending_location_update_from_demand(issi, handle, dltime, pdu);
                    if ck_select_already_attempted {
                        tracing::info!(
                            "ISSI {} sent clear LU without ciphering parameters after SC2 CK select attempt; responding with encrypted D-LU-ACCEPT to confirm SCK possession",
                            issi
                        );
                        self.pending_ck_change.remove(&issi);
                        return Some(true);
                    }

                    tracing::info!(
                        "ISSI {} is authenticated, but LU is still clear; re-sending D-CK CHANGE DEMAND for SC2 SCKN={} SCK-VN={}",
                        issi,
                        expected_sck_n,
                        expected_sck_vn
                    );
                    self.maybe_send_sck_change_demand_after_auth(queue, dltime, issi, handle);
                    return None;
                };

                let (ksg_number, security_class3, requested_sck_n) = Self::parse_class2_ciphering_parameters(ciphering_parameters);

                if pdu.cipher_control && !uplink_encrypted && !security_class3 && requested_sck_n == expected_sck_n {
                    if ck_select_already_attempted {
                        tracing::info!(
                            "ISSI {} still sends clear LU after SC2 CK select attempt; responding with encrypted D-LU-ACCEPT to confirm SCK possession",
                            issi
                        );
                        self.pending_ck_change.remove(&issi);
                        return Some(true);
                    }
                }

                if !pdu.cipher_control || !uplink_encrypted || security_class3 || requested_sck_n != expected_sck_n {
                    self.remember_pending_location_update_from_demand(issi, handle, dltime, pdu);
                    tracing::warn!(
                        "ISSI {} LU does not yet satisfy SC2 cell requirements (cipher_control={}, uplink_encrypted={}, ksg={}, security_class3={}, sck_n={}, expected_sck_n={}); re-sending D-CK CHANGE DEMAND",
                        issi,
                        pdu.cipher_control,
                        uplink_encrypted,
                        ksg_number,
                        security_class3,
                        requested_sck_n,
                        expected_sck_n
                    );
                    self.maybe_send_sck_change_demand_after_auth(queue, dltime, issi, handle);
                    return None;
                }

                if self.pending_ck_change.remove(&issi).is_some() {
                    tracing::info!(
                        "ISSI {} implicitly accepted SC2 key selection via ciphered LU demand (SCKN={}, SCK-VN={})",
                        issi,
                        expected_sck_n,
                        expected_sck_vn
                    );
                }
                self.authenticated_ms.insert(issi, dltime);
                tracing::info!(
                    "ISSI {} has recent D/U-AUTHENTICATION context and is accepted for SC2 location update",
                    issi
                );
                return Some(false);
            }

            self.pending_location_update.remove(&issi);
            self.authenticated_ms.insert(issi, dltime);
            tracing::info!(
                "ISSI {} has recent D/U-AUTHENTICATION context and is accepted for location update",
                issi
            );
            return Some(false);
        }

        if let Some(pending) = self.pending_auth.get(&issi).copied() {
            self.remember_pending_location_update_from_demand(issi, handle, dltime, pdu);

            tracing::debug!("ISSI {} has pending D-AUTHENTICATION challenge; re-sending", issi);
            Self::send_location_update_auth_challenge(queue, dltime, issi, handle, pending.rand1, pending.rs);
            return None;
        }

        if pdu.authentication_uplink.is_some() {
            tracing::warn!(
                "ISSI {} sent legacy authentication_uplink type3 element; using D/U-AUTHENTICATION flow instead",
                issi
            );
        }

        let mut rand1 = [0u8; 10];
        for b in rand1.iter_mut() {
            *b = rand::random::<u8>();
        }

        let mut rs = [0u8; 10];
        for b in rs.iter_mut() {
            *b = rand::random::<u8>();
        }

        let Some(auth) = compute_ta11_ta12(k_value, &rs, &rand1) else {
            tracing::warn!(
                "Rejecting ISSI {}: K has invalid length {} for TA11/TA12 (expected 16 bytes)",
                issi,
                k_value.len()
            );
            self.pending_auth.remove(&issi);
            self.pending_location_update.remove(&issi);
            self.pending_tea_provision.remove(&issi);
            self.auth_derived_dck.remove(&issi);
            self.pending_ck_change.remove(&issi);
            self.announced_sck.remove(&issi);
            self.authenticated_ms.remove(&issi);
            Self::send_d_location_update_reject(queue, dltime, issi, handle, pdu.location_update_type, AUTH_REJECT_CAUSE, false);
            return None;
        };

        let dck = derive_dck_from_dck1(&auth.dck1);
        let expected_res1 = u32::from_be_bytes(auth.res1);

        // New auth transaction supersedes any prior derived/provisioned TEA context.
        self.pending_tea_provision.remove(&issi);
        self.auth_derived_dck.remove(&issi);
        self.pending_ck_change.remove(&issi);

        self.pending_auth.insert(
            issi,
            PendingAuthChallenge {
                rand1,
                rs,
                dck,
                expected_res1,
                issued_at: dltime,
            },
        );
        self.remember_pending_location_update_from_demand(issi, handle, dltime, pdu);
        tracing::info!(
            "Sending D-AUTHENTICATION demand for ISSI {} (RAND1={}, RS={}, expected_RES1=0x{:08X})",
            issi,
            Self::k_hex(&rand1),
            Self::k_hex(&rs),
            expected_res1
        );
        if ms_auth.log_plain_k {
            tracing::debug!(
                "ISSI {} TA11 result KS={} DCK1={} (for diagnostics)",
                issi,
                Self::k_hex(&auth.ks),
                Self::k_hex(&auth.dck1)
            );
        } else {
            tracing::debug!(
                "ISSI {} TA11 result KS fp={} DCK1 fp={}",
                issi,
                Self::k_fingerprint(&auth.ks),
                Self::k_fingerprint(&auth.dck1)
            );
        }

        Self::send_location_update_auth_challenge(queue, dltime, issi, handle, rand1, rs);
        None
    }

    fn send_d_location_update_accept(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        pdu_response: DLocationUpdateAccept,
        encryption_flag: bool,
    ) {
        let mut sdu = BitBuffer::new_autoexpand(64);
        pdu_response.to_bitbuf(&mut sdu).unwrap(); // we want to know when this happens
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu_response, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: encryption_flag,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_location_update_reject(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        location_update_type: LocationUpdateType,
        reject_cause: u8,
        encryption_flag: bool,
    ) {
        let pdu_response = DLocationUpdateReject {
            location_update_type: location_update_type as u8,
            reject_cause,
            cipher_control: encryption_flag,
            ciphering_parameters: encryption_flag.then_some(0),
            address_extension: None,
            cell_type_control: None,
            proprietary: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(32);
        pdu_response.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu_response, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: encryption_flag,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn rx_u_authentication(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_authentication");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UAuthentication::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UAuthentication: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        let issi = prim.received_address.ssi;

        match pdu {
            UAuthentication::Response {
                res1,
                mutual_authentication,
                rand2,
            } => {
                let Some(pending) = self.pending_auth.get(&issi).copied() else {
                    tracing::warn!("Received U-AUTHENTICATION response for ISSI {} with no pending challenge", issi);
                    self.pending_location_update.remove(&issi);
                    self.pending_tea_provision.remove(&issi);
                    self.pending_ck_change.remove(&issi);
                    return;
                };

                if mutual_authentication {
                    tracing::warn!(
                        "ISSI {} requested mutual authentication (RAND2 present: {}), but BS only supports one-way auth; verifying RES1 and downgrading to non-mutual result",
                        issi,
                        rand2.is_some()
                    );
                }

                if res1 != pending.expected_res1 {
                    tracing::warn!(
                        "ISSI {} failed TA12 verification: provided RES1=0x{:08X}, expected=0x{:08X} (RAND1={}, RS={})",
                        issi,
                        res1,
                        pending.expected_res1,
                        Self::k_hex(&pending.rand1),
                        Self::k_hex(&pending.rs)
                    );

                    self.pending_auth.remove(&issi);
                    self.pending_location_update.remove(&issi);
                    self.pending_tea_provision.remove(&issi);
                    self.auth_derived_dck.remove(&issi);
                    self.pending_ck_change.remove(&issi);
                    self.announced_sck.remove(&issi);
                    self.authenticated_ms.remove(&issi);

                    Self::send_d_authentication(
                        queue,
                        message.dltime,
                        issi,
                        prim.handle,
                        DAuthentication::Result {
                            r1: false,
                            mutual_authentication: false,
                            res2: None,
                        },
                    );
                    return;
                }

                tracing::info!("ISSI {} passed TA11/TA12 verification (RES1=0x{:08X})", issi, res1);

                self.pending_auth.remove(&issi);
                self.authenticated_ms.insert(issi, message.dltime);
                self.auth_derived_dck.insert(
                    issi,
                    AuthDerivedDck {
                        dck: pending.dck,
                        issued_at: message.dltime,
                    },
                );

                Self::send_d_authentication(
                    queue,
                    message.dltime,
                    issi,
                    prim.handle,
                    DAuthentication::Result {
                        r1: true,
                        mutual_authentication: false,
                        res2: None,
                    },
                );

                if let Some(pending_lu) = self.pending_location_update.get(&issi).cloned() {
                    if self.pending_lu_requests_selected_class2(&pending_lu) {
                        tracing::info!(
                            "ISSI {} requested SC2 in initial LU; waiting for terminal auth completion before sending CK select",
                            issi
                        );
                        return;
                    }
                }

                if self.selected_class2_sck().is_some() {
                    self.maybe_send_sck_change_demand_after_auth(queue, message.dltime, issi, prim.handle);
                }

                self.maybe_send_tea_key_after_auth(queue, message.dltime, issi, prim.handle, pending.dck);
            }
            UAuthentication::Reject { reject_reason } => {
                tracing::warn!(
                    "ISSI {} rejected authentication challenge (reason={}), clearing pending state",
                    issi,
                    reject_reason
                );
                self.pending_auth.remove(&issi);
                self.pending_location_update.remove(&issi);
                self.pending_tea_provision.remove(&issi);
                self.auth_derived_dck.remove(&issi);
                self.pending_ck_change.remove(&issi);
                self.announced_sck.remove(&issi);
            }
            UAuthentication::Demand { .. } => {
                tracing::warn!(
                    "ISSI {} sent unsupported U-AUTHENTICATION subtype for current BS flow; replying with reject",
                    issi
                );
                self.pending_tea_provision.remove(&issi);
                self.pending_ck_change.remove(&issi);
                Self::send_d_authentication(
                    queue,
                    message.dltime,
                    issi,
                    prim.handle,
                    DAuthentication::Reject {
                        reject_reason: AUTH_REJECT_NOT_SUPPORTED,
                    },
                );
            }
            UAuthentication::Result {
                r2,
                mutual_authentication,
                res1,
            } => {
                // For SwMI-initiated non-mutual authentication, no further action is required here.
                // Some radios still send U-AUTHENTICATION RESULT as a terminal indication.
                if !mutual_authentication {
                    tracing::info!(
                        "ISSI {} sent U-AUTHENTICATION RESULT (r2={}, non-mutual); treating as terminal, no reply",
                        issi,
                        r2
                    );

                    // If we still have a pending location update context, either drive SC2
                    // key selection first or complete the clear registration.
                    if let Some(pending_lu) = self.pending_location_update.get(&issi).cloned() {
                        if self.selected_class2_sck().is_some() {
                            if self.pending_lu_requests_selected_class2(&pending_lu) {
                                tracing::info!(
                                    "ISSI {} requested SC2 and terminal sent final U-AUTHENTICATION RESULT; completing LU then sending D-CK CHANGE DEMAND (SCK pre-loaded, no SSCK delivery)",
                                    issi
                                );
                                self.complete_location_update(
                                    queue,
                                    message.dltime,
                                    issi,
                                    pending_lu.handle,
                                    pending_lu.location_update_type,
                                    pending_lu.group_identity_uplink,
                                    true,
                                    false,
                                );
                                // D-CK CHANGE DEMAND is queued inside complete_location_update.
                                return;
                            }
                            // MS did not request SC2 in the LU but we have SC2 material —
                            // send CK CHANGE DEMAND so it can switch.
                            tracing::info!(
                                "ISSI {} deferring location update completion until SC2 key selection is applied",
                                issi
                            );
                            self.maybe_send_sck_change_demand_after_auth(queue, message.dltime, issi, pending_lu.handle);
                        } else {
                            self.pending_location_update.remove(&issi);
                            tracing::info!(
                                "ISSI {} completing deferred location update after authentication result",
                                issi
                            );
                            self.complete_location_update(
                                queue,
                                message.dltime,
                                issi,
                                pending_lu.handle,
                                pending_lu.location_update_type,
                                pending_lu.group_identity_uplink,
                                false,
                                false,
                            );
                        }
                    }
                    return;
                }

                tracing::warn!(
                    "ISSI {} sent mutual U-AUTHENTICATION RESULT (r2={}, res1_present={}); mutual flow unsupported",
                    issi,
                    r2,
                    res1.is_some()
                );
                // Do not send reject here to avoid forcing MS into auth-failure loop.
            }
        }
    }

    fn rx_u_otar(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_otar");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UOtar::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UOtar: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        let issi = prim.received_address.ssi;

        match pdu {
            UOtar::CckDemand { location_area } => {
                tracing::info!(
                    "ISSI {} requested CCK via U-OTAR CCK DEMAND (location_area={})",
                    issi,
                    location_area
                );

                let tea_enabled = self
                    .config
                    .config()
                    .ms_auth
                    .as_ref()
                    .is_some_and(|m| m.enabled && m.tea_kmf_enable);
                if !tea_enabled {
                    tracing::warn!("Ignoring U-OTAR CCK DEMAND from ISSI {}: tea_kmf_enable=false", issi);
                    return;
                }

                let Some(derived) = self.auth_derived_dck.get(&issi).copied() else {
                    tracing::warn!(
                        "Cannot provision CCK to ISSI {}: no derived DCK available (authenticate first)",
                        issi
                    );
                    return;
                };
                self.maybe_send_tea_key_after_auth(queue, message.dltime, issi, prim.handle, derived.dck);
            }
            UOtar::CckResult {
                provision_result,
                future_key_flag,
                provision_result_future,
            } => {
                let cfg = self.config.config();
                let log_plain_k = cfg
                    .ms_auth
                    .as_ref()
                    .map(|m| m.log_plain_k)
                    .unwrap_or(false);

                if let Some(pending) = self.pending_tea_provision.get(&issi) {
                    if provision_result == 0 {
                        if log_plain_k {
                            tracing::info!(
                                "ISSI {} accepted OTAR CCK (CCK-id=0x{:04X}, CCK={}, future_key_flag={})",
                                issi,
                                pending.cck_id,
                                Self::k_hex(&pending.cck),
                                future_key_flag
                            );
                        } else {
                            tracing::info!(
                                "ISSI {} accepted OTAR CCK (CCK-id=0x{:04X}, CCK fp={}, future_key_flag={})",
                                issi,
                                pending.cck_id,
                                Self::k_fingerprint(&pending.cck),
                                future_key_flag
                            );
                        }
                        tracing::info!(
                            "ISSI {} CCK is provisioned; CK activation + air-interface TEA ciphering remains TODO",
                            issi
                        );
                    } else {
                        tracing::warn!(
                            "ISSI {} rejected OTAR CCK (result={}, future_key_flag={}, future_result={:?}, CCK-id=0x{:04X}, CCK fp={})",
                            issi,
                            provision_result,
                            future_key_flag,
                            provision_result_future,
                            pending.cck_id,
                            Self::k_fingerprint(&pending.cck)
                        );
                    }
                } else {
                    tracing::info!(
                        "ISSI {} sent U-OTAR CCK RESULT without pending local CCK context (result={})",
                        issi,
                        provision_result
                    );
                }
                self.pending_tea_provision.remove(&issi);
            }
            UOtar::Unsupported { otar_sub_type } => {
                tracing::warn!("ISSI {} sent unsupported U-OTAR sub-type {}", issi, otar_sub_type);
            }
        }
    }

    fn rx_u_ck_change_result(&mut self, _queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_ck_change_result");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let issi = prim.received_address.ssi;
        let uplink_encrypted = prim.received_address.encrypted;

        // Diagnostic: log the raw SDU bits and whether the frame arrived encrypted.
        // This lets us verify whether the radio switched to SC2 before sending the result.
        tracing::info!(
            "ISSI {} U-CK CHANGE RESULT received: uplink_encrypted={} raw_sdu={}",
            issi,
            uplink_encrypted,
            prim.sdu.dump_bin()
        );

        let pdu = match UCkChangeResult::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                // Diagnostic: break out each field explicitly so the intent is clear in logs
                tracing::info!(
                    "ISSI {} U-CK CHANGE RESULT decoded: change_of_security_class={} ({}), \
                     key_change_type={}, sck_use={:?}, num_sck_entries={}, entries={:?}",
                    issi,
                    pdu.change_of_security_class,
                    match pdu.change_of_security_class {
                        0 => "no-class-change",
                        1 => "SC1",
                        2 => "SC2/AIE",
                        3 => "SC3/E2E",
                        _ => "unknown",
                    },
                    pdu.key_change_type,
                    pdu.sck_use,
                    pdu.sck_data.len(),
                    pdu.sck_data
                        .iter()
                        .map(|e| format!("SCKN={} VN={}", e.sck_number, e.sck_version))
                        .collect::<Vec<_>>()
                );
                pdu
            }
            Err(e) => {
                // Diagnostic: if parse fails the frame is likely still encrypted (radio sent
                // U-CK CHANGE RESULT in SC2 but we tried to parse it as plaintext),
                // or it's a different PDU entirely. Log the full raw bits for inspection.
                tracing::warn!(
                    "ISSI {} Failed parsing UCkChangeResult: {:?} — raw_bits={} uplink_encrypted={}",
                    issi,
                    e,
                    prim.sdu.dump_bin(),
                    uplink_encrypted
                );
                tracing::warn!(
                    "ISSI {} If uplink_encrypted=false and parse still fails, \
                     the radio may have sent a different MM PDU (check raw bits for PDU type nibble). \
                     If uplink_encrypted=true and parse fails, SC2 UL is active but BS attempted \
                     plaintext decode — ECK mismatch or frame arrived before BS decrypt path was ready.",
                    issi
                );
                return;
            }
        };
        let Some(pending) = self.pending_ck_change.remove(&issi) else {
            tracing::info!(
                "ISSI {} sent U-CK CHANGE RESULT without pending demand; ignoring",
                issi
            );
            return;
        };

        let mut matched = 0usize;
        for requested in &pending.entries {
            if pdu
                .sck_data
                .iter()
                .any(|entry| entry.sck_number == requested.0 && entry.sck_version == requested.1)
            {
                matched += 1;
            }
        }

        let security_class_ok = matches!(pdu.change_of_security_class, 0 | 2);
        let sck_use_ok = pdu.sck_use == Some(false);

        if matched == pending.entries.len() && security_class_ok && sck_use_ok {
            tracing::info!(
                "ISSI {} CK change ACCEPTED: matched {}/{} SCK entries, \
                 security_class={} ({}), uplink_was_encrypted={}",
                issi,
                matched,
                pending.entries.len(),
                pdu.change_of_security_class,
                match pdu.change_of_security_class {
                    0 => "no-class-change — radio may not have activated SC2",
                    2 => "SC2/AIE confirmed",
                    _ => "unexpected",
                },
                uplink_encrypted
            );

            if let Some(pending_lu) = self.pending_location_update.remove(&issi) {
                tracing::info!(
                    "ISSI {} completing deferred location update after CK change",
                    issi
                );
                self.complete_location_update(
                    _queue,
                    message.dltime,
                    issi,
                    pending_lu.handle,
                    pending_lu.location_update_type,
                    pending_lu.group_identity_uplink,
                    true,
                    false,
                );
            }
        } else {
            tracing::warn!(
                "ISSI {} CK change result mismatch: matched {}/{} requested entries, security_class={}, sck_use={:?} (expect TMO sck_use=false)",
                issi,
                matched,
                pending.entries.len(),
                pdu.change_of_security_class,
                pdu.sck_use
            );
            self.announced_sck.remove(&issi);
        }
    }

    fn rx_u_itsi_detach(&mut self, _queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_itsi_detach");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UItsiDetach::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UItsiDetach: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request, print unsupported stuff
        if !Self::feature_check_u_itsi_detach(&pdu) {
            tracing::error!("Unsupported critical features in UItsiDetach");
            return;
        }

        let ssi = prim.received_address.ssi;
        self.pending_auth.remove(&ssi);
        self.pending_location_update.remove(&ssi);
        self.pending_tea_provision.remove(&ssi);
        self.auth_derived_dck.remove(&ssi);
        self.pending_ck_change.remove(&ssi);
        self.announced_sck.remove(&ssi);
        self.authenticated_ms.remove(&ssi);
        let detached_client = self.client_mgr.remove_client(ssi);
        if let Some(client) = detached_client {
            if !client.groups.is_empty() {
                let groups: Vec<u32> = client.groups.iter().copied().collect();
                self.emit_subscriber_update(_queue, message.dltime, ssi, groups, BrewSubscriberAction::Deaffiliate);
            }
            self.emit_subscriber_update(_queue, message.dltime, ssi, Vec::new(), BrewSubscriberAction::Deregister);
        } else {
            tracing::warn!("Received UItsiDetach for unknown client with SSI: {}", ssi);
            // return;
        };
    }

    fn rx_u_location_update_demand(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_location_update_demand");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match ULocationUpdateDemand::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing ULocationUpdateDemand: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request, print unsupported stuff
        if !self.feature_check_u_location_update_demand(&pdu) {
            tracing::error!("Unsupported critical features in ULocationUpdateDemand");
            return;
        }

        let issi = prim.received_address.ssi;
        let handle = prim.handle;
        let Some(force_encrypted_dl) = self.handle_location_update_auth(queue, message.dltime, issi, handle, &pdu, prim.received_address.encrypted) else {
            return;
        };

        let location_update_type = pdu.location_update_type;
        let group_identity_uplink = pdu
            .group_identity_location_demand
            .and_then(|group_identity_location_demand| group_identity_location_demand.group_identity_uplink);

        // When force_encrypted_dl is true the MS has already activated the SC2 SCK
        // (following our D-CK CHANGE DEMAND) and is re-registering with a clear uplink
        // as per TETRA SC2 procedure.  We must respond with an encrypted D-LU-ACCEPT
        // to prove the BS holds the matching SCK; only then will the radio consider
        // SC2 fully established and allow PTT.
        let uplink_encrypted_or_forced = prim.received_address.encrypted || force_encrypted_dl;
        self.complete_location_update(
            queue,
            message.dltime,
            issi,
            handle,
            location_update_type,
            group_identity_uplink,
            pdu.cipher_control,
            uplink_encrypted_or_forced,
        );
    }

    fn complete_location_update(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        location_update_type: LocationUpdateType,
        group_identity_uplink: Option<Vec<GroupIdentityUplink>>,
        requested_cipher_control: bool,
        uplink_encrypted: bool,
    ) {
        let downlink_encryption_flag = requested_cipher_control && uplink_encrypted;

        // This location update transaction is now completed.
        self.pending_location_update.remove(&issi);
        self.pending_auth.remove(&issi);
        self.authenticated_ms.insert(issi, dltime);

        // SCK is assumed pre-loaded in the MS (K and SCK provisioned out-of-band).
        // We never deliver SSCK via Authentication downlink in the LU ACCEPT — doing so
        // produces an oversized PDU (356-bit, 2 MAC frames) that Motorola radios silently
        // discard, causing the registration to time out.
        //
        // Instead we send a plain, compact LU ACCEPT and follow it immediately with a
        // separate D-CK CHANGE DEMAND to activate the pre-loaded SCK.  The MS responds
        // with U-CK CHANGE RESULT and then re-registers on the encrypted channel.
        //
        // We still include authentication_downlink (with authentication_result=true,
        // no CK provision) when the MS authenticated, so it knows authentication passed.
        let sc2_sck_available = self.selected_class2_sck().is_some();
        let include_auth_result_element = sc2_sck_available
            && (requested_cipher_control || self.selected_class2_already_announced(issi));

        // Decide whether to send D-CK CHANGE DEMAND after this LU ACCEPT.
        // Only send it when the uplink is still clear (key not yet activated) and the MS
        // requested SC2. If the uplink is already encrypted the MS has the key active.
        let send_ck_change_demand = sc2_sck_available && !downlink_encryption_flag
            && (requested_cipher_control || self.selected_class2_already_announced(issi));

        if include_auth_result_element && !downlink_encryption_flag {
            tracing::info!(
                "ISSI {} SC2 LU accept: sending plain D-LOCATION UPDATE ACCEPT (no SSCK) + D-CK CHANGE DEMAND (SCK pre-loaded)",
                issi
            );
        }

        // Handle Energy Saving Mode request
        // TODO FIXME this does not yet seem to be functional, and prevents the MS from remaining
        // properly registered.
        // let esi = if let Some(esm) = pdu.energy_saving_mode {
        //     if esm != EnergySavingMode::StayAlive {
        //         unimplemented_log!("Got req for EnergySavingMode {}, overriding with {}", esm, EnergySavingMode::StayAlive);
        //     }
        //     Some(EnergySavingInformation {
        //         energy_saving_mode: EnergySavingMode::StayAlive,
        //         frame_number: None,
        //         multiframe_number: None,
        //     })
        // } else {
        //     None
        // };
        let esi = None;

        // Try to register the client
        let is_new = !self.client_mgr.client_is_known(issi);
        if is_new {
            match self.client_mgr.try_register_client(issi, true) {
                Ok(_) => {
                    self.emit_subscriber_update(queue, dltime, issi, Vec::new(), BrewSubscriberAction::Register);
                }
                Err(e) => {
                    tracing::warn!("Failed registering roaming MS {}: {:?}", issi, e);
                    // unimplemented_log!("Handle failed registration of roaming MS");
                    return;
                }
            }
        } else if let Err(e) = self.client_mgr.set_client_state(issi, MmClientState::Attached) {
            tracing::warn!("Failed updating roaming MS {}: {:?}", issi, e);
            return;
        }

        // Process optional GroupIdentityLocationDemand field
        let gila = if let Some(giu) = group_identity_uplink {
            let accepted_groups = Some(self.try_attach_detach_groups(queue, dltime, issi, &giu));
            let gila = GroupIdentityLocationAccept {
                group_identity_accept_reject: 0, // Accept
                group_identity_downlink: accepted_groups,
            };
            Some(gila)
        } else {
            // No GroupIdentityLocationAccept element present
            None
        };

        // Build D-LOCATION UPDATE ACCEPT PDU.
        // authentication_downlink carries authentication_result=true (no CK provision —
        // SCK delivery is handled by the subsequent D-CK CHANGE DEMAND).
        let authentication_downlink = include_auth_result_element
            .then(Self::make_authentication_downlink_result_only);

        let pdu_response = DLocationUpdateAccept {
            location_update_accept_type: location_update_type, // Practically identical besides minor migration-related difference
            ssi: Some(issi as u64),
            address_extension: None,
            subscriber_class: None,
            energy_saving_information: esi,
            scch_information_and_distribution_on_18th_frame: None,
            new_registered_area: None,
            security_downlink: None,
            group_identity_location_accept: gila,
            default_group_attachment_lifetime: None,
            authentication_downlink,
            group_identity_security_related_information: None,
            cell_type_control: None,
            proprietary: None,
        };

        Self::send_d_location_update_accept(queue, dltime, issi, handle, pdu_response, downlink_encryption_flag);

        // Send D-CK CHANGE DEMAND immediately after the LU ACCEPT to activate the
        // pre-loaded SCK.  We do this here (not in maybe_send_sck_change_demand_after_auth)
        // so the two PDUs are queued back-to-back in the same scheduling pass.
        // announced_sck must NOT be set before this call — it is set inside
        // maybe_send_sck_change_demand_after_auth on first send, ensuring the guard
        // does not skip the demand.
        if send_ck_change_demand {
            tracing::info!(
                "ISSI {} LU accepted; sending D-CK CHANGE DEMAND to activate pre-loaded SCK",
                issi
            );
            self.maybe_send_sck_change_demand_after_auth(queue, dltime, issi, handle);
        }

        // If this is an unknown returning radio (not ITSI attach), force it to
        // re-register with full group report via D-LOCATION UPDATE COMMAND
        if is_new && location_update_type != LocationUpdateType::ItsiAttach {
            tracing::info!("Sending D-LOCATION UPDATE COMMAND to returning MS {} to request group report", issi);
            Self::send_d_location_update_command(queue, dltime, issi, handle, downlink_encryption_flag);
        }
    }

    fn rx_u_mm_status(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_mm_status");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UMmStatus::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UItsiDetach: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        let handled = false; // Set to true for properly handled U-MM STATUS messages
        match pdu.status_uplink {
            StatusUplink::ChangeOfEnergySavingModeRequest
            | StatusUplink::ChangeOfEnergySavingModeResponse
            | StatusUplink::DualWatchModeRequest
            | StatusUplink::TerminatingDualWatchModeRequest
            | StatusUplink::ChangeOfDualWatchModeResponse
            | StatusUplink::StartOfDirectModeOperation
            | StatusUplink::MsFrequencyBandsInformation
            | StatusUplink::RequestToStartDmGatewayOperation
            | StatusUplink::RequestToContinuedmGatewayOperation
            | StatusUplink::RequestToStopDmGatewayOperation
            | StatusUplink::RequestToAddDmMsAddresses
            | StatusUplink::RequestToRemoveDmMsAddresses
            | StatusUplink::RequestToReplaceDmMsAddresses
            | StatusUplink::AcceptanceToRemovalOfDmMsAddresses
            | StatusUplink::AcceptanceToChangeRegistrationLabel
            | StatusUplink::AcceptanceToStopDmGatewayOperation => {
                unimplemented_log!("{:?}", pdu.status_uplink)
            }
            _ => {
                assert_warn!(false, "Unrecognized UMmStatus type {:?}", pdu.status_uplink);
            }
        }

        if !handled {
            // A fairly untested, best-effort way of sending a PDU not supported error back
            // Note that an MS is not required to really do anything with this message.
            let (sapmsg, debug_str) = make_ul_mm_pdu_function_not_supported(
                prim.handle,
                MmPduTypeUl::UMmStatus,
                Some((6, pdu.status_uplink.into())),
                prim.received_address.ssi,
                message.dltime,
            );
            tracing::debug!("-> {}", debug_str);
            queue.push_back(sapmsg);
        }
    }

    fn rx_u_attach_detach_group_identity(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_attach_detach_group_identity");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let issi = prim.received_address.ssi;

        let pdu = match UAttachDetachGroupIdentity::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UAttachDetachGroupIdentity: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request, print unsupported stuff
        if !Self::feature_check_u_attach_detach_group_identity(&pdu) {
            tracing::error!("Unsupported features in UAttachDetachGroupIdentity");
            return;
        }

        // If group_identity_attach_detach_mode == 1, we first detach all groups
        if pdu.group_identity_attach_detach_mode == true {
            if !self.client_mgr.client_is_known(issi) {
                // Client unknown (e.g. never registered via location update).
                // Re-register so group attachment can proceed.
                match self.client_mgr.try_register_client(issi, true) {
                    Ok(_) => {
                        self.emit_subscriber_update(queue, message.dltime, issi, Vec::new(), BrewSubscriberAction::Register);
                    }
                    Err(e) => {
                        tracing::warn!("Failed re-registering MS {} on group attach: {:?}", issi, e);
                        return;
                    }
                }
            } else {
                // Client is known — detach all existing groups first
                let prior_groups: Vec<u32> = self
                    .client_mgr
                    .get_client_by_issi(issi)
                    .map(|client| client.groups.iter().copied().collect())
                    .unwrap_or_default();
                match self.client_mgr.client_detach_all_groups(issi) {
                    Ok(_) => {
                        if !prior_groups.is_empty() {
                            self.emit_subscriber_update(queue, message.dltime, issi, prior_groups, BrewSubscriberAction::Deaffiliate);
                        }
                    }
                    Err(e) => {
                        tracing::warn!("Failed detaching all groups for MS {}: {:?}", issi, e);
                        return;
                    }
                }
            }
        }

        // Try to attach to requested groups, and retrieve list of accepted GroupIdentityDownlink elements
        // We can unwrap since we did compat check earlier
        let accepted_gid = self.try_attach_detach_groups(queue, message.dltime, issi, &pdu.group_identity_uplink.unwrap());

        // Build reply PDU
        let pdu_response = DAttachDetachGroupIdentityAcknowledgement {
            group_identity_accept_reject: 0, // Accept
            reserved: false,                 // TODO FIXME Guessed proper value of reserved field
            proprietary: None,
            group_identity_downlink: Some(accepted_gid),
            group_identity_security_related_information: None,
        };

        // Write to PDU
        let mut sdu = BitBuffer::new_autoexpand(32);
        pdu_response.to_bitbuf(&mut sdu).unwrap(); // We want to know when this happens
        sdu.seek(0);
        tracing::debug!("-> {:?} sdu {}", pdu_response, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle: prim.handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn rx_lmm_mle_unitdata_ind(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        // unimplemented_log!("rx_lmm_mle_unitdata_ind for MM component");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let Some(bits) = prim.sdu.peek_bits(4) else {
            tracing::warn!("insufficient bits: {}", prim.sdu.dump_bin());
            return;
        };

        let Ok(pdu_type) = MmPduTypeUl::try_from(bits) else {
            tracing::warn!("invalid pdu type: {} in {}", bits, prim.sdu.dump_bin());
            return;
        };

        // Diagnostic: if this ISSI has a pending D-CK CHANGE DEMAND ACK, log what it
        // sent back.  This is the key observable: after a correct D-CK CHANGE DEMAND,
        // the radio should reply with UCkChangeResult.  If it sends something else
        // (e.g. ULocationUpdateDemand again) it did not accept the demand.
        let issi = prim.received_address.ssi;
        if self.pending_ck_change.contains_key(&issi) {
            tracing::info!(
                "MM rx from ISSI {} (has pending CK change): PDU_TYPE={:?} uplink_encrypted={} raw={}",
                issi,
                pdu_type,
                prim.received_address.encrypted,
                prim.sdu.dump_bin()
            );
        }

        match pdu_type {
            MmPduTypeUl::UAuthentication => self.rx_u_authentication(queue, message),
            MmPduTypeUl::UItsiDetach => self.rx_u_itsi_detach(queue, message),
            MmPduTypeUl::ULocationUpdateDemand => self.rx_u_location_update_demand(queue, message),
            MmPduTypeUl::UMmStatus => self.rx_u_mm_status(queue, message),
            MmPduTypeUl::UCkChangeResult => self.rx_u_ck_change_result(queue, message),
            MmPduTypeUl::UOtar => self.rx_u_otar(queue, message),
            MmPduTypeUl::UInformationProvide => unimplemented_log!("UInformationProvide"),
            MmPduTypeUl::UAttachDetachGroupIdentity => self.rx_u_attach_detach_group_identity(queue, message),
            MmPduTypeUl::UAttachDetachGroupIdentityAcknowledgement => unimplemented_log!("UAttachDetachGroupIdentityAcknowledgement"),
            MmPduTypeUl::UTeiProvide => unimplemented_log!("UTeiProvide"),
            MmPduTypeUl::UDisableStatus => unimplemented_log!("UDisableStatus"),
            MmPduTypeUl::MmPduFunctionNotSupported => unimplemented_log!("MmPduFunctionNotSupported"),
        };
    }

    fn try_attach_detach_groups(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        giu_vec: &Vec<GroupIdentityUplink>,
    ) -> Vec<GroupIdentityDownlink> {
        let mut accepted_groups = Vec::new();
        let mut aff_groups = Vec::new();
        let mut deaff_groups = Vec::new();

        for giu in giu_vec.iter() {
            if giu.gssi.is_none() || giu.vgssi.is_some() || giu.address_extension.is_some() {
                unimplemented_log!("Only support GroupIdentityUplink with address_type 0");
                continue;
            }

            let gssi = giu.gssi.unwrap(); // can't fail
            let is_detach = giu.group_identity_detachment_uplink.is_some();

            if is_detach {
                match self.client_mgr.client_group_attach(issi, gssi, false) {
                    Ok(changed) => {
                        if changed {
                            deaff_groups.push(gssi);
                        }
                        let gid = GroupIdentityDownlink {
                            group_identity_attachment: None,
                            group_identity_detachment_uplink: giu.group_identity_detachment_uplink,
                            gssi: Some(gssi),
                            address_extension: None,
                            vgssi: None,
                        };
                        accepted_groups.push(gid);
                    }
                    Err(e) => {
                        tracing::warn!("Failed detaching MS {} from group {}: {:?}", issi, gssi, e);
                    }
                }
            } else {
                match self.client_mgr.client_group_attach(issi, gssi, true) {
                    Ok(changed) => {
                        if changed {
                            aff_groups.push(gssi);
                        }
                        // We have added the client to this group. Add an entry to the downlink response
                        let gid = GroupIdentityDownlink {
                            group_identity_attachment: Some(GroupIdentityAttachment {
                                group_identity_attachment_lifetime: 1, // re-attach after ITSI attach (ETSI default per clause 16.4.2)
                                class_of_usage: giu.class_of_usage.unwrap_or(0),
                            }),
                            group_identity_detachment_uplink: None,
                            gssi: Some(gssi),
                            address_extension: None,
                            vgssi: None,
                        };
                        accepted_groups.push(gid);
                    }
                    Err(e) => {
                        tracing::warn!("Failed attaching MS {} to group {}: {:?}", issi, gssi, e);
                    }
                }
            }
        }

        if !aff_groups.is_empty() {
            self.emit_subscriber_update(queue, dltime, issi, aff_groups, BrewSubscriberAction::Affiliate);
        }
        if !deaff_groups.is_empty() {
            self.emit_subscriber_update(queue, dltime, issi, deaff_groups, BrewSubscriberAction::Deaffiliate);
        }

        accepted_groups
    }

    /// Sends a D-LOCATION UPDATE COMMAND to force the radio to re-register
    /// with full group identity report
    fn send_d_location_update_command(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        encryption_flag: bool,
    ) {
        let pdu = DLocationUpdateCommand {
            group_identity_report: true,
            cipher_control: encryption_flag,
            ciphering_parameters: encryption_flag.then_some(0),
            address_extension: None,
            cell_type_control: None,
            proprietary: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(16);
        pdu.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> DLocationUpdateCommand sdu {}", sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: encryption_flag,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn feature_check_u_itsi_detach(pdu: &UItsiDetach) -> bool {
        let supported = true;
        if pdu.address_extension.is_some() {
            unimplemented_log!("Unsupported address_extension present");
        };
        if pdu.proprietary.is_some() {
            unimplemented_log!("Unsupported proprietary present");
        };
        supported
    }

    fn feature_check_u_location_update_demand(&self, pdu: &ULocationUpdateDemand) -> bool {
        let mut supported = true;
        if pdu.location_update_type == LocationUpdateType::MigratingLocationUpdating
            || pdu.location_update_type == LocationUpdateType::DisabledMsUpdating
        {
            unimplemented_log!("Unsupported {}", pdu.location_update_type);
            supported = false;
        }
        if pdu.request_to_append_la == true {
            unimplemented_log!("Unsupported request_to_append_la == true");
            supported = false;
        }
        if pdu.cipher_control == true {
            tracing::info!("ULocationUpdateDemand requests ciphering for registration");
        }
        if pdu.ciphering_parameters.is_some() {
            tracing::debug!("ULocationUpdateDemand includes ciphering_parameters={:?}", pdu.ciphering_parameters);
        }
        if pdu.class_of_ms.is_some() {
            unimplemented_log!("Unsupported class_of_ms present");
        }
        if pdu.energy_saving_mode.is_some() {
            unimplemented_log!("Unsupported energy_saving_mode present");
        }
        if pdu.la_information.is_some() {
            unimplemented_log!("Unsupported la_information present");
        }
        if pdu.ssi.is_some() {
            unimplemented_log!("Unsupported ssi present");
        }
        if pdu.address_extension.is_some() {
            unimplemented_log!("Unsupported address_extension present");
        }
        if pdu.group_report_response.is_some() {
            unimplemented_log!("Unsupported group_report_response present");
        }
        if pdu.authentication_uplink.is_some() {
            tracing::warn!(
                "Legacy authentication_uplink type3 field is ignored; D/U-AUTHENTICATION PDU flow is used"
            );
        }
        if pdu.extended_capabilities.is_some() {
            unimplemented_log!("Unsupported extended_capabilities present");
        }
        if pdu.proprietary.is_some() {
            unimplemented_log!("Unsupported proprietary present");
        }

        supported
    }

    /// Check for unsupported features in U-ATTACH/DETACH GROUP IDENTITY
    /// Returns false if a critical feature is missing
    fn feature_check_u_attach_detach_group_identity(pdu: &UAttachDetachGroupIdentity) -> bool {
        let mut supported = true;
        if pdu.group_identity_report == true {
            unimplemented_log!("Unsupported group_identity_report == true");
        }
        if pdu.group_identity_uplink.is_none() {
            unimplemented_log!("Missing group_identity_uplink");
            supported = false;
        }
        if pdu.group_report_response.is_some() {
            unimplemented_log!("Unsupported group_report_response present");
        }
        if pdu.proprietary.is_some() {
            unimplemented_log!("Unsupported proprietary present");
        }

        supported
    }
}

impl TetraEntityTrait for MmBs {
    fn entity(&self) -> TetraEntity {
        TetraEntity::Mm
    }

    fn set_config(&mut self, config: SharedConfig) {
        self.config = config;
        self.pending_auth.clear();
        self.pending_location_update.clear();
        self.pending_tea_provision.clear();
        self.auth_derived_dck.clear();
        self.pending_ck_change.clear();
        self.announced_sck.clear();
        self.authenticated_ms.clear();
        self.log_ms_auth_config();
    }

    fn rx_prim(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        tracing::debug!("rx_prim: {:?}", message);
        // tracing::debug!(ts=%message.dltime, "rx_prim: {:?}", message);

        // There is only one SAP for MM
        assert!(message.sap == Sap::LmmSap);

        match message.msg {
            SapMsgInner::LmmMleUnitdataInd(_) => {
                self.rx_lmm_mle_unitdata_ind(queue, message);
            }
            _ => {
                panic!();
            }
        }
    }
}
