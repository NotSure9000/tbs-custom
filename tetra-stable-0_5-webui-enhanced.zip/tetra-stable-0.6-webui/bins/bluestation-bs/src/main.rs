use clap::Parser;

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;
use std::time::Duration;

use tetra_config::bluestation::{PhyBackend, SharedConfig, StackMode, parsing};
use tetra_core::{TdmaTime, debug};
use tetra_entities::MessageRouter;
use tetra_entities::brew::entity::BrewEntity;
use tetra_entities::{
    cmce::cmce_bs::CmceBs,
    llc::llc_bs_ms::Llc,
    lmac::lmac_bs::LmacBs,
    mle::mle_bs_ms::Mle,
    mm::mm_bs::MmBs,
    phy::{components::soapy_dev::RxTxDevSoapySdr, phy_bs::PhyBs},
    sndcp::sndcp_bs::Sndcp,
    umac::umac_bs::UmacBs,
};

/// Load configuration file
fn load_config_from_toml(cfg_path: &str) -> SharedConfig {
    match parsing::from_file(cfg_path) {
        Ok(c) => c,
        Err(e) => {
            println!("Failed to load configuration from {}: {}", cfg_path, e);
            std::process::exit(1);
        }
    }
}

/// Start base station stack
fn build_bs_stack(cfg: &mut SharedConfig) -> MessageRouter {
    let mut router = MessageRouter::new(cfg.clone());

    // Add suitable Phy component based on PhyIo type
    match cfg.config().phy_io.backend {
        PhyBackend::SoapySdr => {
            let rxdev = RxTxDevSoapySdr::new(cfg);
            let phy = PhyBs::new(cfg.clone(), rxdev);
            router.register_entity(Box::new(phy));
        }
        _ => {
            panic!("Unsupported PhyIo type: {:?}", cfg.config().phy_io.backend);
        }
    }

    // Add remaining components
    let lmac = LmacBs::new(cfg.clone());
    let umac = UmacBs::new(cfg.clone());
    let llc = Llc::new(cfg.clone());
    let mle = Mle::new(cfg.clone());
    let mm = MmBs::new(cfg.clone());
    let sndcp = Sndcp::new(cfg.clone());
    let cmce = CmceBs::new(cfg.clone());
    router.register_entity(Box::new(lmac));
    router.register_entity(Box::new(umac));
    router.register_entity(Box::new(llc));
    router.register_entity(Box::new(mle));
    router.register_entity(Box::new(mm));
    router.register_entity(Box::new(sndcp));
    router.register_entity(Box::new(cmce));

    // Register Brew entity if enabled
    if cfg.config().brew.is_some() {
        let brew_entity = BrewEntity::new(cfg.clone());
        router.register_entity(Box::new(brew_entity));
        eprintln!(" -> Brew/TetraPack integration enabled");
    }

    // Init network time
    router.set_dl_time(TdmaTime::default());

    router
}

#[derive(Parser, Debug)]
#[command(
    author,
    version,
    about = "TETRA BlueStation Stack",
    long_about = "Runs the TETRA BlueStation stack using the provided TOML configuration files"
)]

struct Args {
    /// Config file (required)
    #[arg(help = "TOML config with network/cell parameters")]
    config: String,

    /// Web UI bind address (empty string disables web UI)
    #[arg(long, default_value = "127.0.0.1:8787")]
    web_ui_bind: String,
}

const WEB_UI_HTML: &str = r#"<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tetra BlueStation Stats</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f1117; color: #e2e8f0; min-height: 100vh; padding: 20px; }
    header { display: flex; align-items: center; gap: 14px; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid #1e2433; }
    header h1 { font-size: 22px; font-weight: 700; color: #f1f5f9; letter-spacing: -0.3px; }
    .badge { background: #1e3a5f; color: #60a5fa; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.06em; }
    .status-dot { width: 8px; height: 8px; border-radius: 50%; background: #22c55e; display: inline-block; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
    .meta { font-size: 12px; color: #64748b; margin-left: auto; }

    /* Stat cards row */
    .stat-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; margin-bottom: 18px; }
    .stat-card { background: #161b27; border: 1px solid #1e2433; border-radius: 10px; padding: 14px 16px; }
    .stat-label { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 0.07em; margin-bottom: 6px; }
    .stat-value { font-size: 28px; font-weight: 700; color: #f1f5f9; line-height: 1; }
    .stat-value.active { color: #3b82f6; }
    .stat-value.green { color: #22c55e; }
    .stat-value.yellow { color: #eab308; }

    /* Two-column layout for panels */
    .main-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px; }
    @media(max-width: 900px) { .main-grid { grid-template-columns: 1fr; } }

    .panel { background: #161b27; border: 1px solid #1e2433; border-radius: 10px; overflow: hidden; }
    .panel-header { padding: 12px 16px; border-bottom: 1px solid #1e2433; font-size: 13px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.06em; display: flex; align-items: center; justify-content: space-between; }
    .panel-header .count { background: #1e2433; color: #64748b; font-size: 11px; font-weight: 600; padding: 2px 7px; border-radius: 10px; }
    .panel-body { padding: 12px 16px; max-height: 320px; overflow-y: auto; }
    .panel-body::-webkit-scrollbar { width: 4px; }
    .panel-body::-webkit-scrollbar-track { background: transparent; }
    .panel-body::-webkit-scrollbar-thumb { background: #2d3748; border-radius: 2px; }

    /* Radio list */
    .radio-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #1a2030; }
    .radio-item:last-child { border-bottom: none; }
    .radio-status { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .radio-status.online { background: #22c55e; box-shadow: 0 0 6px #22c55e88; }
    .radio-status.offline { background: #475569; }
    .radio-status.oncall { background: #3b82f6; box-shadow: 0 0 6px #3b82f688; animation: pulse 1.2s infinite; }
    .radio-status.error { background: #eab308; box-shadow: 0 0 6px #eab30888; }
    .radio-issi { font-family: monospace; font-size: 14px; font-weight: 600; color: #e2e8f0; flex: 1; }
    .radio-state-label { font-size: 11px; font-weight: 600; padding: 2px 7px; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.05em; }
    .radio-state-label.online { background: #14532d; color: #4ade80; }
    .radio-state-label.offline { background: #1e2433; color: #475569; }
    .radio-state-label.oncall { background: #1e3a5f; color: #60a5fa; }
    .radio-state-label.error { background: #422006; color: #fbbf24; }
    .key-icon { font-size: 12px; color: #64748b; }
    .key-icon.has-key { color: #eab308; }

    /* Call log */
    .log-item { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; border-bottom: 1px solid #1a2030; font-size: 13px; }
    .log-item:last-child { border-bottom: none; }
    .log-type { width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
    .log-type.group { background: #1e3a5f; }
    .log-type.individual { background: #1e3a2a; }
    .log-type.sds { background: #2d1e3a; }
    .log-body { flex: 1; min-width: 0; }
    .log-from-to { color: #e2e8f0; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .log-from-to span { color: #64748b; }
    .log-detail { font-size: 11px; color: #64748b; margin-top: 2px; }
    .log-time { font-size: 11px; color: #475569; white-space: nowrap; }
    .live-pill { display: inline-block; background: #1e3a5f; color: #60a5fa; font-size: 10px; font-weight: 700; padding: 1px 6px; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.05em; animation: pulse 1.2s infinite; }
    .empty-state { color: #475569; font-size: 13px; text-align: center; padding: 24px 0; }

    /* Talkgroups */
    .tg-list { display: flex; flex-wrap: wrap; gap: 8px; padding: 14px 16px; }
    .tg-pill { background: #1e3a5f; color: #93c5fd; font-family: monospace; font-size: 13px; font-weight: 600; padding: 5px 12px; border-radius: 6px; border: 1px solid #2563eb44; display: flex; align-items: center; gap: 6px; }
    .tg-dot { width: 7px; height: 7px; border-radius: 50%; background: #3b82f6; animation: pulse 1.5s infinite; }

    /* SDS panel bottom row */
    .sds-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }

    /* Full-width log panel */
    .full-width { grid-column: 1 / -1; }
    .log-panel-body { max-height: 260px; }
  </style>
</head>
<body>
  <header>
    <span class="status-dot"></span>
    <h1>BlueStation Live Stats</h1>
    <span class="badge">TETRA BS</span>
    <span class="meta" id="updated">Connecting…</span>
  </header>

  <div class="stat-row">
    <div class="stat-card">
      <div class="stat-label">Registered ISSIs</div>
      <div class="stat-value green" id="registered_issi_count">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Active Group Calls</div>
      <div class="stat-value active" id="active_group_calls">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Active Indiv. Calls</div>
      <div class="stat-value active" id="active_individual_calls">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Groups w/ Listeners</div>
      <div class="stat-value" id="groups_with_listeners">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Affiliations</div>
      <div class="stat-value" id="affiliated_group_links">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Group Setups</div>
      <div class="stat-value" id="total_group_call_setups">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Indiv. Setups</div>
      <div class="stat-value" id="total_individual_call_setups">0</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">SDS Sent / Delivered</div>
      <div class="stat-value yellow"><span id="sds_sent">0</span><span style="color:#475569;font-size:18px"> / </span><span id="sds_delivered" style="color:#22c55e">0</span></div>
    </div>
  </div>

  <div class="main-grid">
    <!-- Provisioned Radios Panel -->
    <div class="panel">
      <div class="panel-header">
        Provisioned Radios
        <span class="count" id="radio_count">0</span>
      </div>
      <div class="panel-body" id="radio_list">
        <div class="empty-state">No radios provisioned</div>
      </div>
    </div>

    <!-- Active Talkgroups Panel -->
    <div class="panel">
      <div class="panel-header">
        Active Talkgroups
        <span class="count" id="tg_count">0</span>
      </div>
      <div id="tg_container">
        <div class="tg-list" id="tg_list">
          <div class="empty-state" style="width:100%">No active talkgroups</div>
        </div>
      </div>
    </div>

    <!-- Call & SDS Activity Log (full width) -->
    <div class="panel full-width">
      <div class="panel-header">
        Recent Activity (Calls &amp; SDS)
        <span class="count" id="log_count">0</span>
      </div>
      <div class="panel-body log-panel-body" id="call_log">
        <div class="empty-state">No activity yet</div>
      </div>
    </div>
  </div>

  <script>
    function setText(id, v) {
      const el = document.getElementById(id);
      if (el) el.textContent = v;
    }

    function formatTime(unix_ms) {
      if (!unix_ms) return '';
      const d = new Date(unix_ms);
      return d.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', second: '2-digit'});
    }

    function formatDuration(ms) {
      if (ms == null) return '';
      const s = Math.floor(ms / 1000);
      if (s < 60) return s + 's';
      const m = Math.floor(s / 60);
      const rs = s % 60;
      if (m < 60) return m + 'm ' + rs + 's';
      return Math.floor(m/60) + 'h ' + (m%60) + 'm';
    }

    function statusClass(status) {
      if (!status) return 'offline';
      return status.toLowerCase().replace('oncall','oncall');
    }

    function statusLabel(status) {
      if (!status || status === 'offline') return 'Offline';
      if (status === 'online') return 'Online';
      if (status === 'oncall') return 'On Call';
      if (status === 'error') return 'Error';
      return status;
    }

    function logTypeEmoji(t) {
      if (t === 'group') return '📡';
      if (t === 'individual') return '📞';
      if (t === 'sds') return '✉️';
      return '📋';
    }

    async function refresh() {
      try {
        const [r1, r2] = await Promise.all([
          fetch('/api/stats', {cache:'no-store'}),
          fetch('/api/extended_stats', {cache:'no-store'})
        ]);
        const s = await r1.json();
        const ext = await r2.json();

        // Basic stats
        setText('registered_issi_count', s.registered_issi_count ?? 0);
        setText('active_group_calls', s.active_group_calls ?? 0);
        setText('active_individual_calls', s.active_individual_calls ?? 0);
        setText('groups_with_listeners', s.groups_with_listeners ?? 0);
        setText('affiliated_group_links', s.affiliated_group_links ?? 0);
        setText('total_group_call_setups', s.total_group_call_setups ?? 0);
        setText('total_individual_call_setups', s.total_individual_call_setups ?? 0);

        // SDS counters
        setText('sds_sent', ext.sds_sent ?? 0);
        setText('sds_delivered', ext.sds_delivered ?? 0);

        // Provisioned radios
        const radios = Array.isArray(ext.provisioned_radios) ? ext.provisioned_radios : [];
        setText('radio_count', radios.length);
        const radioList = document.getElementById('radio_list');
        if (radios.length === 0) {
          radioList.innerHTML = '<div class="empty-state">No radios provisioned (add ms_auth subscribers to config)</div>';
        } else {
          radioList.innerHTML = radios.map(r => {
            const sc = statusClass(r.status);
            return `<div class="radio-item">
              <div class="radio-status ${sc}"></div>
              <span class="radio-issi">${r.issi}</span>
              <span class="key-icon ${r.has_key ? 'has-key' : ''}" title="${r.has_key ? 'Key provisioned' : 'No key'}">${r.has_key ? '🔑' : '○'}</span>
              <span class="radio-state-label ${sc}">${statusLabel(r.status)}</span>
            </div>`;
          }).join('');
        }

        // Active talkgroups
        const tgs = Array.isArray(ext.active_talkgroups) ? ext.active_talkgroups : [];
        setText('tg_count', tgs.length);
        const tgList = document.getElementById('tg_list');
        if (tgs.length === 0) {
          tgList.innerHTML = '<div class="empty-state" style="width:100%">No active talkgroups</div>';
        } else {
          tgList.innerHTML = tgs.map(g => `<div class="tg-pill"><span class="tg-dot"></span>GSSI ${g}</div>`).join('');
        }

        // Call log
        const log = Array.isArray(ext.call_log) ? ext.call_log : [];
        setText('log_count', log.length);
        const logEl = document.getElementById('call_log');
        if (log.length === 0) {
          logEl.innerHTML = '<div class="empty-state">No activity yet</div>';
        } else {
          logEl.innerHTML = log.map(e => {
            const ct = e.call_type || 'group';
            const emoji = logTypeEmoji(ct);
            let detail = '';
            if (ct === 'group') {
              detail = `Group call → GSSI ${e.gssi ?? e.to_issi_or_gssi}`;
            } else if (ct === 'individual') {
              detail = `Individual call → ISSI ${e.to_issi_or_gssi}`;
            } else {
              detail = `SDS → ISSI ${e.to_issi_or_gssi}`;
            }
            const durStr = e.is_live
              ? '<span class="live-pill">Live</span>'
              : (e.duration_ms != null ? formatDuration(e.duration_ms) : '');
            return `<div class="log-item">
              <div class="log-type ${ct}">${emoji}</div>
              <div class="log-body">
                <div class="log-from-to">ISSI ${e.from_issi} <span>→</span> ${e.to_issi_or_gssi} ${durStr}</div>
                <div class="log-detail">${detail} · ${formatTime(e.timestamp_unix_ms)}</div>
              </div>
            </div>`;
          }).join('');
        }

        if (s.updated_unix_ms) {
          setText('updated', 'Updated ' + new Date(s.updated_unix_ms).toLocaleTimeString());
        }
      } catch(e) {
        setText('updated', 'Error fetching stats');
      }
    }

    refresh();
    setInterval(refresh, 1000);
  </script>
</body>
</html>
"#;

fn write_http_response(stream: &mut TcpStream, status: &str, content_type: &str, body: &str) {
    let response = format!(
        "HTTP/1.1 {status}\r\nContent-Type: {content_type}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n{}",
        body.len(),
        body
    );
    let _ = stream.write_all(response.as_bytes());
}

fn handle_http_client(mut stream: TcpStream) {
    let mut buf = [0_u8; 4096];
    let n = match stream.read(&mut buf) {
        Ok(n) if n > 0 => n,
        _ => return,
    };
    let req = String::from_utf8_lossy(&buf[..n]);
    let first_line = req.lines().next().unwrap_or("");
    let path = first_line.split_whitespace().nth(1).unwrap_or("/");

    match path {
        "/" => write_http_response(&mut stream, "200 OK", "text/html; charset=utf-8", WEB_UI_HTML),
        "/api/stats" => {
            let body = tetra_entities::webui_stats::snapshot_json();
            write_http_response(&mut stream, "200 OK", "application/json; charset=utf-8", &body);
        }
        "/api/extended_stats" => {
            let body = tetra_entities::webui_stats::extended_snapshot_json();
            write_http_response(&mut stream, "200 OK", "application/json; charset=utf-8", &body);
        }
        "/healthz" => write_http_response(&mut stream, "200 OK", "text/plain; charset=utf-8", "ok"),
        _ => write_http_response(&mut stream, "404 Not Found", "text/plain; charset=utf-8", "not found"),
    }
}

fn start_web_ui_server(bind_addr: String, running: Arc<AtomicBool>) -> Option<thread::JoinHandle<()>> {
    if bind_addr.trim().is_empty() {
        eprintln!(" -> Web UI disabled");
        return None;
    }

    let listener = match TcpListener::bind(&bind_addr) {
        Ok(listener) => listener,
        Err(err) => {
            eprintln!(" -> Web UI failed to bind on {bind_addr}: {err}");
            return None;
        }
    };

    if let Err(err) = listener.set_nonblocking(true) {
        eprintln!(" -> Web UI failed to set non-blocking mode on {bind_addr}: {err}");
        return None;
    }

    eprintln!(" -> Web UI available at http://{bind_addr}/");

    Some(thread::spawn(move || {
        while running.load(Ordering::SeqCst) {
            match listener.accept() {
                Ok((stream, _)) => handle_http_client(stream),
                Err(err) if err.kind() == std::io::ErrorKind::WouldBlock => thread::sleep(Duration::from_millis(200)),
                Err(_) => thread::sleep(Duration::from_millis(200)),
            }
        }
    }))
}

fn main() {
    eprintln!("░▀█▀░█▀▀░▀█▀░█▀▄░█▀█░░░░░█▀▄░█░░░█░█░█▀▀░█▀▀░▀█▀░█▀█░▀█▀░▀█▀░█▀█░█▀█");
    eprintln!("░░█░░█▀▀░░█░░█▀▄░█▀█░▄▄▄░█▀▄░█░░░█░█░█▀▀░▀▀█░░█░░█▀█░░█░░░█░░█░█░█░█");
    eprintln!("░░▀░░▀▀▀░░▀░░▀░▀░▀░▀░░░░░▀▀░░▀▀▀░▀▀▀░▀▀▀░▀▀▀░░▀░░▀░▀░░▀░░▀▀▀░▀▀▀░▀░▀\n");
    eprintln!("    Wouter Bokslag / Midnight Blue");
    eprintln!(" -> https://github.com/MidnightBlueLabs/tetra-bluestation");
    eprintln!(" -> https://midnightblue.nl\n");

    let args = Args::parse();
    let mut cfg = load_config_from_toml(&args.config);
    let _log_guard = debug::setup_logging_default(cfg.config().debug_log.clone());

    // Populate provisioned radios in webui_stats from ms_auth config (ISSI-K pairs)
    {
        let radios: Vec<(u32, bool)> = if let Some(ms_auth) = &cfg.config().ms_auth {
            ms_auth.subscribers.keys().map(|&issi| (issi, true)).collect()
        } else {
            Vec::new()
        };
        tetra_entities::webui_stats::set_provisioned_radios(radios);
    }

    let mut router = match cfg.config().stack_mode {
        StackMode::Mon => {
            unimplemented!("Monitor mode is not implemented");
        }
        StackMode::Ms => {
            unimplemented!("MS mode is not implemented");
        }
        StackMode::Bs => build_bs_stack(&mut cfg),
    };

    // Set up Ctrl+C handler for graceful shutdown
    let running = Arc::new(AtomicBool::new(true));
    let r = running.clone();
    ctrlc::set_handler(move || {
        r.store(false, Ordering::SeqCst);
    })
    .expect("failed to set Ctrl+C handler");

    let web_ui_handle = start_web_ui_server(args.web_ui_bind.clone(), running.clone());

    router.run_stack(None, Some(running));
    if let Some(handle) = web_ui_handle {
        let _ = handle.join();
    }
    // router drops here → entities are dropped → BrewEntity::Drop fires teardown
}
