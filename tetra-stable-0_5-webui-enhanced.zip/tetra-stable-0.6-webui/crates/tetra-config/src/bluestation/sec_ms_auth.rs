use std::collections::{HashMap, HashSet};

use serde::Deserialize;
use toml::Value;

/// Optional MS authentication settings for BS mode.
#[derive(Debug, Clone)]
pub struct CfgMsAuth {
    /// Enable MS authentication.
    pub enabled: bool,
    /// Enable TEA key provisioning (KMF-like) via D/U-OTAR after successful auth.
    pub tea_kmf_enable: bool,
    /// Optional static SCK material set (SCKN/SCK-VN/SCK).
    pub sck_material: Vec<CfgSckMaterial>,
    /// Request explicit acknowledgement for CK change demand.
    pub ck_change_ack_required: bool,
    /// Optional key material identifier/tag.
    pub key_material_id: Option<u32>,
    /// Log full K value during authentication attempts.
    pub log_plain_k: bool,
    /// Maximum challenge age (timeslots) before it is considered stale.
    pub challenge_ttl_slots: i32,
    /// Per-subscriber K values, keyed by ISSI.
    pub subscribers: HashMap<u32, Vec<u8>>,
}

#[derive(Default, Deserialize)]
pub struct CfgMsAuthDto {
    /// Enable MS authentication.
    #[serde(default = "default_ms_auth_enabled")]
    pub enabled: bool,
    /// Enable TEA key provisioning (KMF-like) via D/U-OTAR after successful auth.
    #[serde(default = "default_ms_auth_tea_kmf_enable")]
    pub tea_kmf_enable: bool,
    /// Log full K value during authentication attempts.
    #[serde(default = "default_ms_auth_log_plain_k")]
    pub log_plain_k: bool,
    /// Maximum challenge age (timeslots) before it is considered stale.
    #[serde(default = "default_ms_auth_challenge_ttl_slots")]
    pub challenge_ttl_slots: i32,
    /// Per-subscriber K values.
    #[serde(default)]
    pub subscribers: Vec<CfgMsAuthSubscriberDto>,
    /// Optional static SCK material set (SCKN/SCK-VN/SCK).
    #[serde(default)]
    pub sck_material: Vec<CfgSckMaterialDto>,
    /// Request explicit acknowledgement for CK change demand.
    #[serde(default = "default_ms_auth_ck_change_ack_required")]
    pub ck_change_ack_required: bool,
    /// Optional key material identifier/tag.
    #[serde(default)]
    pub key_material_id: Option<Value>,

    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

#[derive(Debug, Clone)]
pub struct CfgSckMaterial {
    pub sck_n: u8,
    pub sck_vn: u16,
    pub sck: [u8; 10],
}

impl CfgMsAuth {
    /// Select active TMO SCK material.
    ///
    /// Preference order:
    /// 1) TMO-reserved SCKN (30..31) with valid SCK-VN (1..3)
    /// 2) Any valid SCK-VN (1..3) entry
    pub fn select_tmo_sck_material(&self) -> Option<&CfgSckMaterial> {
        for entry in &self.sck_material {
            if (30..=31).contains(&entry.sck_n) && (1..=3).contains(&entry.sck_vn) {
                return Some(entry);
            }
        }

        for entry in &self.sck_material {
            if (1..=3).contains(&entry.sck_vn) {
                return Some(entry);
            }
        }

        None
    }
}

#[derive(Default, Deserialize)]
pub struct CfgSckMaterialDto {
    pub sck_n: u8,
    pub sck_vn: u16,
    /// Hex-encoded SCK value (10 bytes / 80-bit).
    pub sck: String,

    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

#[derive(Default, Deserialize)]
pub struct CfgMsAuthSubscriberDto {
    pub issi: u32,
    /// Hex-encoded K value (16 bytes / 128-bit).
    pub k: String,

    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

fn default_ms_auth_enabled() -> bool {
    true
}

fn default_ms_auth_challenge_ttl_slots() -> i32 {
    4 * 18 * 60
}

fn default_ms_auth_tea_kmf_enable() -> bool {
    false
}

fn default_ms_auth_log_plain_k() -> bool {
    false
}

fn default_ms_auth_ck_change_ack_required() -> bool {
    true
}

fn parse_hex_k(input: &str) -> Result<Vec<u8>, String> {
    let mut compact = String::with_capacity(input.len());
    let trimmed = input.trim();
    let trimmed = trimmed
        .strip_prefix("0x")
        .or_else(|| trimmed.strip_prefix("0X"))
        .unwrap_or(trimmed);

    for ch in trimmed.chars() {
        if ch.is_ascii_hexdigit() {
            compact.push(ch);
        } else if matches!(ch, ':' | '-' | '_' | ' ') {
            continue;
        } else {
            return Err(format!("K contains invalid character '{}': {}", ch, input));
        }
    }

    if compact.is_empty() {
        return Err("K value cannot be empty".to_string());
    }
    if compact.len() % 2 != 0 {
        return Err(format!("K hex length must be even, got {}", compact.len()));
    }

    let mut out = Vec::with_capacity(compact.len() / 2);
    for i in (0..compact.len()).step_by(2) {
        let byte = u8::from_str_radix(&compact[i..i + 2], 16).map_err(|e| format!("invalid K hex byte at {}: {}", i, e))?;
        out.push(byte);
    }

    Ok(out)
}

fn parse_u32_value(input: &str) -> Result<u32, String> {
    let trimmed = input.trim().trim_end_matches(':').trim_end_matches(';').trim();
    if let Some(hex) = trimmed.strip_prefix("0x").or_else(|| trimmed.strip_prefix("0X")) {
        u32::from_str_radix(hex, 16).map_err(|e| format!("invalid hex u32 '{}': {}", input, e))
    } else {
        trimmed
            .parse::<u32>()
            .map_err(|e| format!("invalid decimal u32 '{}': {}", input, e))
    }
}

/// Convert a CfgMsAuthDto (from TOML) into a CfgMsAuth (used in stack config)
pub fn apply_ms_auth_patch(src: CfgMsAuthDto) -> Result<CfgMsAuth, String> {
    if src.challenge_ttl_slots <= 0 {
        return Err("ms_auth.challenge_ttl_slots must be > 0".to_string());
    }

    let mut subscribers = HashMap::with_capacity(src.subscribers.len());
    for sub in src.subscribers {
        let k_bytes = parse_hex_k(&sub.k).map_err(|e| format!("invalid K for ISSI {}: {}", sub.issi, e))?;
        if k_bytes.len() != 16 {
            return Err(format!(
                "invalid K for ISSI {}: expected 16 bytes (128-bit), got {} bytes",
                sub.issi,
                k_bytes.len()
            ));
        }
        if subscribers.insert(sub.issi, k_bytes).is_some() {
            return Err(format!("duplicate ms_auth subscriber entry for ISSI {}", sub.issi));
        }
    }

    if src.enabled && subscribers.is_empty() {
        return Err("ms_auth is enabled but no subscribers are configured".to_string());
    }

    let mut sck_material = Vec::with_capacity(src.sck_material.len());
    let mut seen_sck_n = HashSet::with_capacity(src.sck_material.len());
    for entry in src.sck_material {
        if entry.sck_n > 31 {
            return Err(format!("invalid sck_material.sck_n {}: expected 0..31", entry.sck_n));
        }
        if !(1..=3).contains(&entry.sck_vn) {
            return Err(format!(
                "invalid sck_material.sck_vn {} for sck_n {}: expected 1..3",
                entry.sck_vn, entry.sck_n
            ));
        }
        if !seen_sck_n.insert(entry.sck_n) {
            return Err(format!("duplicate sck_material entry for sck_n {}", entry.sck_n));
        }

        let sck = parse_hex_k(&entry.sck).map_err(|e| format!("invalid sck_material SCK for SCKN {}: {}", entry.sck_n, e))?;
        if sck.len() != 10 {
            return Err(format!(
                "invalid sck_material SCK for SCKN {}: expected 10 bytes (80-bit), got {} bytes",
                entry.sck_n,
                sck.len()
            ));
        }

        let sck_arr: [u8; 10] = sck.try_into().expect("sck length checked");
        sck_material.push(CfgSckMaterial {
            sck_n: entry.sck_n,
            sck_vn: entry.sck_vn,
            sck: sck_arr,
        });
    }
    sck_material.sort_by_key(|e| e.sck_n);

    let key_material_id = match src.key_material_id {
        Some(Value::String(v)) => Some(parse_u32_value(&v).map_err(|e| format!("invalid key_material_id: {}", e))?),
        Some(Value::Integer(v)) => {
            if v < 0 || v > u32::MAX as i64 {
                return Err(format!("invalid key_material_id integer {}: expected 0..{}", v, u32::MAX));
            }
            Some(v as u32)
        }
        Some(other) => {
            return Err(format!(
                "invalid key_material_id type {:?}: expected string (e.g. \"0xCD50E7E7\") or integer",
                other
            ));
        }
        None => None,
    };

    Ok(CfgMsAuth {
        enabled: src.enabled,
        tea_kmf_enable: src.tea_kmf_enable,
        sck_material,
        ck_change_ack_required: src.ck_change_ack_required,
        key_material_id,
        log_plain_k: src.log_plain_k,
        challenge_ttl_slots: src.challenge_ttl_slots,
        subscribers,
    })
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use super::*;

    #[test]
    fn parse_hex_k_accepts_common_formats() {
        let parsed = parse_hex_k("0xAA:bb-cc_dd 01").expect("hex parse failed");
        assert_eq!(parsed, vec![0xAA, 0xBB, 0xCC, 0xDD, 0x01]);
    }

    #[test]
    fn parse_hex_k_rejects_odd_length() {
        let err = parse_hex_k("abc").expect_err("expected parse error");
        assert!(err.contains("even"));
    }

    #[test]
    fn apply_ms_auth_patch_rejects_duplicates() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: false,
            sck_material: Vec::new(),
            ck_change_ack_required: true,
            key_material_id: None,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![
                CfgMsAuthSubscriberDto {
                    issi: 1001,
                    k: "0011".to_string(),
                    extra: HashMap::new(),
                },
                CfgMsAuthSubscriberDto {
                    issi: 1001,
                    k: "0022".to_string(),
                    extra: HashMap::new(),
                },
            ],
            extra: HashMap::new(),
        };

        let err = apply_ms_auth_patch(src).expect_err("expected duplicate parse error");
        assert!(err.contains("duplicate"));
    }

    #[test]
    fn apply_ms_auth_patch_rejects_non_128_bit_k() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: false,
            sck_material: Vec::new(),
            ck_change_ack_required: true,
            key_material_id: None,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233".to_string(),
                extra: HashMap::new(),
            }],
            extra: HashMap::new(),
        };

        let err = apply_ms_auth_patch(src).expect_err("expected K length parse error");
        assert!(err.contains("expected 16 bytes"));
    }

    #[test]
    fn apply_ms_auth_patch_keeps_tea_kmf_flag() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: true,
            sck_material: Vec::new(),
            ck_change_ack_required: true,
            key_material_id: None,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233445566778899AABBCCDDEEFF".to_string(),
                extra: HashMap::new(),
            }],
            extra: HashMap::new(),
        };

        let cfg = apply_ms_auth_patch(src).expect("expected valid config");
        assert!(cfg.tea_kmf_enable);
    }

    #[test]
    fn apply_ms_auth_patch_keeps_ck_change_ack_flag() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: false,
            sck_material: Vec::new(),
            ck_change_ack_required: false,
            key_material_id: None,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233445566778899AABBCCDDEEFF".to_string(),
                extra: HashMap::new(),
            }],
            extra: HashMap::new(),
        };

        let cfg = apply_ms_auth_patch(src).expect("expected valid config");
        assert!(!cfg.ck_change_ack_required);
    }

    #[test]
    fn apply_ms_auth_patch_parses_sck_material_and_material_id() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: false,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233445566778899AABBCCDDEEFF".to_string(),
                extra: HashMap::new(),
            }],
            sck_material: vec![CfgSckMaterialDto {
                sck_n: 0,
                sck_vn: 1,
                sck: "1F6D6B3BC2DB94A5C757".to_string(),
                extra: HashMap::new(),
            }],
            ck_change_ack_required: true,
            key_material_id: Some(Value::String("0xCD50E7E7".to_string())),
            extra: HashMap::new(),
        };

        let cfg = apply_ms_auth_patch(src).expect("expected valid config");
        assert_eq!(cfg.sck_material.len(), 1);
        assert_eq!(cfg.sck_material[0].sck_n, 0);
        assert_eq!(cfg.sck_material[0].sck_vn, 1);
        assert_eq!(cfg.sck_material[0].sck, [0x1F, 0x6D, 0x6B, 0x3B, 0xC2, 0xDB, 0x94, 0xA5, 0xC7, 0x57]);
        assert_eq!(cfg.key_material_id, Some(0xCD50E7E7));
    }

    #[test]
    fn apply_ms_auth_patch_accepts_integer_key_material_id() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: false,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233445566778899AABBCCDDEEFF".to_string(),
                extra: HashMap::new(),
            }],
            sck_material: Vec::new(),
            ck_change_ack_required: true,
            key_material_id: Some(Value::Integer(0x1234)),
            extra: HashMap::new(),
        };

        let cfg = apply_ms_auth_patch(src).expect("expected valid config");
        assert_eq!(cfg.key_material_id, Some(0x1234));
    }

    #[test]
    fn apply_ms_auth_patch_accepts_key_material_id_with_trailing_colon() {
        let src = CfgMsAuthDto {
            enabled: true,
            tea_kmf_enable: false,
            log_plain_k: false,
            challenge_ttl_slots: 16,
            subscribers: vec![CfgMsAuthSubscriberDto {
                issi: 12345,
                k: "00112233445566778899AABBCCDDEEFF".to_string(),
                extra: HashMap::new(),
            }],
            sck_material: Vec::new(),
            ck_change_ack_required: true,
            key_material_id: Some(Value::String("0xCD50E7E7:".to_string())),
            extra: HashMap::new(),
        };

        let cfg = apply_ms_auth_patch(src).expect("expected valid config");
        assert_eq!(cfg.key_material_id, Some(0xCD50E7E7));
    }
}
