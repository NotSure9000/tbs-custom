// Placeholder for testing
#[derive(Debug)]
pub struct TnmmTestDemand {
    pub issi: u32,
}
#[derive(Debug)]
pub struct TnmmTestResponse {
    pub issi: u32,
    pub data: u32,
}
