use std::collections::{HashMap, VecDeque};
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use serde::Serialize;

// ─── MS status ────────────────────────────────────────────────────────────────

#[derive(Clone, Debug, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum MsStatus {
    Offline,
    Online,
    OnCall,
    Error,
}

impl Default for MsStatus {
    fn default() -> Self { MsStatus::Offline }
}

// ─── Provisioned radio ────────────────────────────────────────────────────────

#[derive(Clone, Debug, Default, Serialize)]
pub struct ProvisionedRadio {
    pub issi: u32,
    pub has_key: bool,
    pub status: MsStatus,
}

// ─── Call / SDS log entry ─────────────────────────────────────────────────────

#[derive(Clone, Debug, Serialize)]
pub struct CallLogEntry {
    pub timestamp_unix_ms: u64,
    pub entry_type: String,
    pub from_issi: u32,
    pub to_issi_or_gssi: u32,
    pub call_type: String,
    pub duration_ms: Option<u64>,
    pub is_live: bool,
    pub gssi: Option<u32>,
    pub call_id: Option<u64>,
}

// ─── Air interface statistics ─────────────────────────────────────────────────

#[derive(Clone, Debug, Default, Serialize)]
pub struct AirStats {
    pub ul_ctrl_frames_total: u64,
    pub ul_ctrl_frames_crc_err: u64,
    pub ul_traffic_frames_total: u64,
    pub ul_traffic_frames_bfi: u64,
    pub ctrl_crc_error_rate: f32,
    pub traffic_bfi_rate: f32,
}

// ─── 24-hour MS online history ────────────────────────────────────────────────

#[derive(Clone, Debug, Serialize)]
pub struct MsOnlineHistory {
    pub slots: [u32; 24],
    pub current_hour_ts: u64,
}
impl Default for MsOnlineHistory {
    fn default() -> Self { Self { slots: [0u32; 24], current_hour_ts: 0 } }
}

// ─── Channel utilisation heatmap (60 minutes × TS2/3/4) ──────────────────────

/// 60-minute heatmap of traffic timeslot occupancy.
/// `slots[m][t]` = fraction (0.0–1.0) of minute `m` that timeslot `t+2` was occupied.
/// Slot 0 is the oldest (59 minutes ago), slot 59 is the current minute.
#[derive(Clone, Debug, Serialize)]
pub struct ChanUtilHistory {
    /// [60 minutes][3 timeslots (TS2/3/4)], values 0.0-1.0
    pub slots: Vec<[f32; 3]>,
    /// Unix seconds of the start of the current minute
    pub current_min_ts: u64,
}
impl Default for ChanUtilHistory {
    fn default() -> Self { Self { slots: vec![[0.0f32; 3]; 60], current_min_ts: 0 } }
}

// ─── Registration timeline (60 minutes, 1 sample/minute) ─────────────────────

#[derive(Clone, Debug, Serialize)]
pub struct RegTimeline {
    /// Max registered MS count per minute, oldest-first (slot 0 = 59 min ago)
    pub slots: Vec<u32>,
    pub current_min_ts: u64,
}
impl Default for RegTimeline {
    fn default() -> Self { Self { slots: vec![0u32; 60], current_min_ts: 0 } }
}

// ─── Per-ISSI statistics ──────────────────────────────────────────────────────

#[derive(Clone, Debug, Default, Serialize)]
pub struct IssiStats {
    pub issi: u32,
    pub total_calls: u32,
    pub total_sds: u32,
    /// Total voice time on air (sum of call durations), milliseconds
    pub total_air_ms: u64,
    /// Last time this ISSI was active (unix ms)
    pub last_seen_unix_ms: u64,
}

// ─── Active call detail ───────────────────────────────────────────────────────

#[derive(Clone, Debug, Serialize)]
pub struct ActiveCallDetail {
    pub call_id: u64,
    pub from_issi: u32,
    pub gssi: Option<u32>,
    pub to_issi: Option<u32>,
    pub call_type: String,  // "group" | "individual"
    pub ts: u8,
    pub started_unix_ms: u64,
}

// ─── Unknown ISSI log ─────────────────────────────────────────────────────────

#[derive(Clone, Debug, Serialize)]
pub struct UnknownIssiEntry {
    pub issi: u32,
    pub timestamp_unix_ms: u64,
    pub event: String,  // "register_rejected" | "call_attempt"
}

// ─── Stack health ─────────────────────────────────────────────────────────────

#[derive(Clone, Debug, Default, Serialize)]
pub struct StackHealth {
    pub start_unix_ms: u64,
    pub restart_count: u32,
    pub mcc: u16,
    pub mnc: u16,
    pub colour_code: u8,
    pub main_carrier: u16,
    pub location_area: u16,
}

// ─── Snapshot structs ─────────────────────────────────────────────────────────

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiStatsSnapshot {
    pub registered_issi_count: u64,
    pub registered_issis: Vec<u32>,
    pub affiliated_group_links: u64,
    pub groups_with_listeners: u64,
    pub active_group_calls: u64,
    pub active_individual_calls: u64,
    pub total_group_call_setups: u64,
    pub total_individual_call_setups: u64,
    pub updated_unix_ms: u64,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiExtendedSnapshot {
    pub provisioned_radios: Vec<ProvisionedRadio>,
    pub call_log: Vec<CallLogEntry>,
    pub active_talkgroups: Vec<u32>,
    pub active_call_talkgroups: Vec<u32>,
    pub sds_sent: u64,
    pub sds_delivered: u64,
    pub air: AirStats,
    pub ms_online_history: MsOnlineHistory,
    pub chan_util: ChanUtilHistory,
    pub reg_timeline: RegTimeline,
    pub issi_stats: Vec<IssiStats>,
    pub active_calls: Vec<ActiveCallDetail>,
    pub unknown_issi_log: Vec<UnknownIssiEntry>,
    pub stack_health: StackHealth,
    pub updated_unix_ms: u64,
}

// ─── Rolling-window frame counter ─────────────────────────────────────────────

const ROLLING_WINDOW: usize = 1000;

#[derive(Default)]
struct FrameStats {
    total_alltime: u64,
    err_alltime: u64,
    window: VecDeque<bool>,
    window_err_count: usize,
}
impl FrameStats {
    fn record(&mut self, is_error: bool) {
        self.total_alltime += 1;
        if is_error { self.err_alltime += 1; }
        self.window.push_back(is_error);
        if is_error { self.window_err_count += 1; }
        if self.window.len() > ROLLING_WINDOW {
            if let Some(evicted) = self.window.pop_front() {
                if evicted { self.window_err_count = self.window_err_count.saturating_sub(1); }
            }
        }
    }
    fn error_rate(&self) -> f32 {
        let n = self.window.len();
        if n == 0 { 0.0 } else { self.window_err_count as f32 / n as f32 }
    }
}

// ─── Channel utilisation accumulator (intra-minute) ───────────────────────────

/// Per-timeslot occupancy accumulator for the current minute.
/// Counts samples seen and samples where the slot was occupied.
#[derive(Default)]
struct TsAccum {
    total: u32,
    occupied: u32,
}
impl TsAccum {
    fn rate(&self) -> f32 {
        if self.total == 0 { 0.0 } else { self.occupied as f32 / self.total as f32 }
    }
}

// ─── Time helpers ─────────────────────────────────────────────────────────────

fn hour_start_secs(unix_ms: u64) -> u64 { (unix_ms / 1000) / 3600 * 3600 }
fn min_start_secs(unix_ms: u64)  -> u64 { (unix_ms / 1000) / 60   * 60   }

// ─── Global state ─────────────────────────────────────────────────────────────

#[derive(Default)]
struct WebUiStatsState {
    snapshot: WebUiStatsSnapshot,
    extended: WebUiExtendedSnapshot,
    ctrl_frames: FrameStats,
    traffic_frames: FrameStats,
    /// Per-timeslot intra-minute occupancy accumulators (index 0=TS2, 1=TS3, 2=TS4)
    ts_accum: [TsAccum; 3],
    /// Per-ISSI statistics map
    issi_stats: HashMap<u32, IssiStats>,
    /// Monotonic start time (for uptime calculation)
    start_instant: Option<Instant>,
}

fn state() -> &'static Mutex<WebUiStatsState> {
    static STATE: OnceLock<Mutex<WebUiStatsState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(WebUiStatsState::default()))
}

fn now_unix_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0)
}

// ─── History update helpers ────────────────────────────────────────────────────

fn update_ms_online_history(hist: &mut MsOnlineHistory, count: u32, now_ms: u64) {
    let this_hour = hour_start_secs(now_ms);
    if hist.current_hour_ts == 0 {
        hist.current_hour_ts = this_hour;
        hist.slots[23] = count;
        return;
    }
    if this_hour > hist.current_hour_ts {
        let hours = ((this_hour - hist.current_hour_ts) / 3600).min(24) as usize;
        if hours >= 24 {
            hist.slots = [0u32; 24];
        } else {
            hist.slots.rotate_left(hours);
            for s in hist.slots[24 - hours..].iter_mut() { *s = 0; }
        }
        hist.current_hour_ts = this_hour;
        hist.slots[23] = count;
    } else if count > hist.slots[23] {
        hist.slots[23] = count;
    }
}

fn update_reg_timeline(tl: &mut RegTimeline, count: u32, now_ms: u64) {
    let this_min = min_start_secs(now_ms);
    if tl.current_min_ts == 0 {
        tl.current_min_ts = this_min;
        tl.slots[59] = count;
        return;
    }
    if this_min > tl.current_min_ts {
        let mins = ((this_min - tl.current_min_ts) / 60).min(60) as usize;
        if mins >= 60 {
            tl.slots = vec![0u32; 60];
        } else {
            tl.slots.rotate_left(mins);
            for s in tl.slots[60 - mins..].iter_mut() { *s = 0; }
        }
        tl.current_min_ts = this_min;
        tl.slots[59] = count;
    } else if count > tl.slots[59] {
        tl.slots[59] = count;
    }
}

// ─── Public API ───────────────────────────────────────────────────────────────

pub fn reset() {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        s.snapshot = WebUiStatsSnapshot { updated_unix_ms: now, ..Default::default() };
        let reset_radios: Vec<ProvisionedRadio> = std::mem::take(&mut s.extended.provisioned_radios)
            .into_iter().map(|mut r| { r.status = MsStatus::Offline; r }).collect();
        // Preserve across resets: history charts, issi_stats, stack_health, start_instant
        let preserved_ms_hist  = s.extended.ms_online_history.clone();
        let preserved_chan_util = s.extended.chan_util.clone();
        let preserved_reg_tl   = s.extended.reg_timeline.clone();
        let preserved_health   = s.extended.stack_health.clone();
        let preserved_unknown  = s.extended.unknown_issi_log.clone();
        s.extended = WebUiExtendedSnapshot {
            updated_unix_ms: now,
            provisioned_radios: reset_radios,
            ms_online_history: preserved_ms_hist,
            chan_util: preserved_chan_util,
            reg_timeline: preserved_reg_tl,
            stack_health: preserved_health,
            unknown_issi_log: preserved_unknown,
            ..Default::default()
        };
    }
}

pub fn set_provisioned_radios(radios: Vec<(u32, bool)>) {
    if let Ok(mut s) = state().lock() {
        let old: HashMap<u32, MsStatus> = s.extended.provisioned_radios.iter()
            .map(|r| (r.issi, r.status.clone())).collect();
        let mut new_radios: Vec<ProvisionedRadio> = radios.into_iter().map(|(issi, has_key)| {
            ProvisionedRadio { issi, has_key, status: old.get(&issi).cloned().unwrap_or(MsStatus::Offline) }
        }).collect();
        new_radios.sort_by_key(|r| r.issi);
        s.extended.provisioned_radios = new_radios;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_ms_status(issi: u32, status: MsStatus) {
    if let Ok(mut s) = state().lock() {
        if let Some(radio) = s.extended.provisioned_radios.iter_mut().find(|r| r.issi == issi) {
            radio.status = status;
            s.extended.updated_unix_ms = now_unix_ms();
        }
    }
}

pub fn append_call_log(entry: CallLogEntry) {
    if let Ok(mut s) = state().lock() {
        s.extended.call_log.insert(0, entry);
        if s.extended.call_log.len() > 200 { s.extended.call_log.truncate(200); }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn finalize_call_log(call_id: u64, ended_at_unix_ms: u64) {
    if let Ok(mut s) = state().lock() {
        for entry in s.extended.call_log.iter_mut() {
            if entry.call_id == Some(call_id) && entry.is_live {
                entry.is_live = false;
                entry.duration_ms = Some(ended_at_unix_ms.saturating_sub(entry.timestamp_unix_ms));
                break;
            }
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_active_talkgroups(mut gssis: Vec<u32>) {
    gssis.sort_unstable(); gssis.dedup();
    if let Ok(mut s) = state().lock() {
        s.extended.active_talkgroups = gssis;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_active_call_talkgroups(mut gssis: Vec<u32>) {
    gssis.sort_unstable(); gssis.dedup();
    if let Ok(mut s) = state().lock() {
        s.extended.active_call_talkgroups = gssis;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn inc_sds_sent() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_sent += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn inc_sds_delivered() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_delivered += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn record_ctrl_frame(crc_ok: bool) {
    if let Ok(mut s) = state().lock() {
        s.ctrl_frames.record(!crc_ok);
        s.extended.air.ul_ctrl_frames_total   = s.ctrl_frames.total_alltime;
        s.extended.air.ul_ctrl_frames_crc_err = s.ctrl_frames.err_alltime;
        s.extended.air.ctrl_crc_error_rate    = s.ctrl_frames.error_rate();
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn record_traffic_frame(crc_ok: bool) {
    if let Ok(mut s) = state().lock() {
        s.traffic_frames.record(!crc_ok);
        s.extended.air.ul_traffic_frames_total = s.traffic_frames.total_alltime;
        s.extended.air.ul_traffic_frames_bfi   = s.traffic_frames.err_alltime;
        s.extended.air.traffic_bfi_rate        = s.traffic_frames.error_rate();
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Record a timeslot occupancy sample. Called each TDMA frame from cc_bs tick.
/// `ts` is 2, 3, or 4. `occupied` = true when an active call holds this slot.
pub fn record_ts_sample(ts: u8, occupied: bool) {
    if ts < 2 || ts > 4 { return; }
    let idx = (ts - 2) as usize;
    if let Ok(mut s) = state().lock() {
        s.ts_accum[idx].total += 1;
        if occupied { s.ts_accum[idx].occupied += 1; }
    }
}

/// Record that an unknown (not provisioned / rejected) ISSI was seen.
pub fn record_unknown_issi(issi: u32, event: &str) {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        // Deduplicate: update timestamp if already present, else prepend
        if let Some(existing) = s.extended.unknown_issi_log.iter_mut().find(|e| e.issi == issi && e.event == event) {
            existing.timestamp_unix_ms = now;
        } else {
            s.extended.unknown_issi_log.insert(0, UnknownIssiEntry {
                issi,
                timestamp_unix_ms: now,
                event: event.to_string(),
            });
            if s.extended.unknown_issi_log.len() > 100 {
                s.extended.unknown_issi_log.truncate(100);
            }
        }
        s.extended.updated_unix_ms = now;
    }
}

/// Replace the live active-call list. Called from cc_bs publish_webui_stats.
pub fn set_active_call_details(calls: Vec<ActiveCallDetail>) {
    if let Ok(mut s) = state().lock() {
        s.extended.active_calls = calls;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Record a completed call for an ISSI (updates per-ISSI stats).
pub fn record_issi_call(issi: u32, duration_ms: u64) {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        let entry = s.issi_stats.entry(issi).or_insert_with(|| IssiStats { issi, ..Default::default() });
        entry.total_calls += 1;
        entry.total_air_ms += duration_ms;
        entry.last_seen_unix_ms = now;
    }
}

/// Record an SDS relay for an ISSI (sender side).
pub fn record_issi_sds(issi: u32) {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        let entry = s.issi_stats.entry(issi).or_insert_with(|| IssiStats { issi, ..Default::default() });
        entry.total_sds += 1;
        entry.last_seen_unix_ms = now;
    }
}

/// Set the network identity fields for the stack health panel.
/// Called once at startup from main.rs after config is loaded.
pub fn set_stack_identity(mcc: u16, mnc: u16, colour_code: u8, main_carrier: u16, location_area: u16) {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        let restart_count = s.extended.stack_health.restart_count + 1;
        s.extended.stack_health = StackHealth { mcc, mnc, colour_code, main_carrier, location_area,
            start_unix_ms: now, restart_count };
        s.start_instant = Some(Instant::now());
        s.extended.updated_unix_ms = now;
    }
}

/// Returns uptime as a Duration. Computed from Instant to avoid wall-clock drift.
pub fn uptime() -> Duration {
    state().lock().ok()
        .and_then(|s| s.start_instant.map(|i| i.elapsed()))
        .unwrap_or(Duration::ZERO)
}

#[allow(clippy::too_many_arguments)]
pub fn publish(
    mut registered_issis: Vec<u32>,
    affiliated_group_links: usize,
    groups_with_listeners: usize,
    active_group_calls: usize,
    active_individual_calls: usize,
    total_group_call_setups: u64,
    total_individual_call_setups: u64,
) {
    registered_issis.sort_unstable();
    registered_issis.dedup();
    let count = registered_issis.len() as u32;
    let now = now_unix_ms();
    let snapshot = WebUiStatsSnapshot {
        registered_issi_count: count as u64,
        registered_issis,
        affiliated_group_links: affiliated_group_links as u64,
        groups_with_listeners: groups_with_listeners as u64,
        active_group_calls: active_group_calls as u64,
        active_individual_calls: active_individual_calls as u64,
        total_group_call_setups,
        total_individual_call_setups,
        updated_unix_ms: now,
    };
    if let Ok(mut s) = state().lock() {
        s.snapshot = snapshot;
        update_ms_online_history(&mut s.extended.ms_online_history, count, now);
        update_reg_timeline(&mut s.extended.reg_timeline, count, now);
        // Extract accum rates before borrowing s.extended.chan_util to avoid double-borrow
        let rates = [s.ts_accum[0].rate(), s.ts_accum[1].rate(), s.ts_accum[2].rate()];
        let this_min = min_start_secs(now);
        let hist = &mut s.extended.chan_util;
        if hist.current_min_ts == 0 { hist.current_min_ts = this_min; }
        if this_min > hist.current_min_ts {
            let mins = ((this_min - hist.current_min_ts) / 60).min(60) as usize;
            if mins >= 60 {
                hist.slots = vec![[0.0, 0.0, 0.0]; 60];
            } else {
                hist.slots.rotate_left(mins);
                for sl in hist.slots[60 - mins..].iter_mut() { *sl = [0.0, 0.0, 0.0]; }
            }
            hist.current_min_ts = this_min;
            // Reset accumulators so the new minute starts clean, not carrying
            // occupied counts from the minute that just ended.
            for acc in s.ts_accum.iter_mut() { *acc = TsAccum::default(); }
        }
        hist.slots[59] = rates;
        // Snapshot issi_stats map into the extended snapshot vec
        let mut stats_vec: Vec<IssiStats> = s.issi_stats.values().cloned().collect();
        stats_vec.sort_by_key(|e| std::cmp::Reverse(e.last_seen_unix_ms));
        s.extended.issi_stats = stats_vec;
        s.extended.updated_unix_ms = now;
    }
}

pub fn snapshot() -> WebUiStatsSnapshot {
    state().lock().map(|s| s.snapshot.clone())
        .unwrap_or_else(|_| WebUiStatsSnapshot { updated_unix_ms: now_unix_ms(), ..Default::default() })
}

pub fn snapshot_json() -> String {
    serde_json::to_string(&snapshot()).unwrap_or_else(|_| "{}".to_string())
}

pub fn extended_snapshot() -> WebUiExtendedSnapshot {
    state().lock().map(|s| s.extended.clone())
        .unwrap_or_else(|_| WebUiExtendedSnapshot { updated_unix_ms: now_unix_ms(), ..Default::default() })
}

pub fn extended_snapshot_json() -> String {
    serde_json::to_string(&extended_snapshot()).unwrap_or_else(|_| "{}".to_string())
}
