use std::collections::{HashMap, VecDeque};
use std::sync::{Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

use serde::Serialize;

/// Status of a provisioned MS (radio)
#[derive(Clone, Debug, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum MsStatus {
    Offline,
    Online,
    OnCall,
    Error,
}

impl Default for MsStatus {
    fn default() -> Self {
        MsStatus::Offline
    }
}

/// A provisioned radio with ISSI and key presence indicator
#[derive(Clone, Debug, Default, Serialize)]
pub struct ProvisionedRadio {
    pub issi: u32,
    pub has_key: bool,
    pub status: MsStatus,
}

/// A single call/SDS log entry
#[derive(Clone, Debug, Serialize)]
pub struct CallLogEntry {
    pub timestamp_unix_ms: u64,
    pub entry_type: String,
    pub from_issi: u32,
    pub to_issi_or_gssi: u32,
    pub call_type: String,
    pub duration_ms: Option<u64>,
    pub is_live: bool,
    pub gssi: Option<u32>,
    pub call_id: Option<u64>,
}

/// Air interface statistics (rolling + all-time)
#[derive(Clone, Debug, Default, Serialize)]
pub struct AirStats {
    /// Total UL control-channel frames received (all-time)
    pub ul_ctrl_frames_total: u64,
    /// UL control-channel frames with CRC error (all-time)
    pub ul_ctrl_frames_crc_err: u64,
    /// Total UL traffic-channel frames received (all-time)
    pub ul_traffic_frames_total: u64,
    /// UL traffic-channel frames with Bad Frame Indicator (all-time)
    pub ul_traffic_frames_bfi: u64,
    /// Control-channel CRC error rate over last 1000 frames (0.0–1.0)
    pub ctrl_crc_error_rate: f32,
    /// Traffic BFI rate over last 1000 frames (0.0–1.0)
    pub traffic_bfi_rate: f32,
}

/// A pending outbound SDS command queued by the web UI
#[derive(Debug, Clone)]
pub struct PendingSdsCommand {
    pub from_issi: u32,
    pub to_issi: u32,
    pub text: String,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiStatsSnapshot {
    pub registered_issi_count: u64,
    pub registered_issis: Vec<u32>,
    pub affiliated_group_links: u64,
    pub groups_with_listeners: u64,
    pub active_group_calls: u64,
    pub active_individual_calls: u64,
    pub total_group_call_setups: u64,
    pub total_individual_call_setups: u64,
    pub updated_unix_ms: u64,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct WebUiExtendedSnapshot {
    pub provisioned_radios: Vec<ProvisionedRadio>,
    pub call_log: Vec<CallLogEntry>,
    pub active_talkgroups: Vec<u32>,
    pub sds_sent: u64,
    pub sds_delivered: u64,
    pub air: AirStats,
    pub updated_unix_ms: u64,
}

// ─── Rolling-window frame counter ─────────────────────────────────────────────

const ROLLING_WINDOW: usize = 1000;

#[derive(Default)]
struct FrameStats {
    total_alltime: u64,
    err_alltime: u64,
    /// Ring buffer tracking errors in the last ROLLING_WINDOW frames
    window: VecDeque<bool>,
    window_err_count: usize,
}

impl FrameStats {
    fn record(&mut self, is_error: bool) {
        self.total_alltime += 1;
        if is_error {
            self.err_alltime += 1;
        }
        self.window.push_back(is_error);
        if is_error {
            self.window_err_count += 1;
        }
        if self.window.len() > ROLLING_WINDOW {
            if let Some(evicted) = self.window.pop_front() {
                if evicted {
                    self.window_err_count = self.window_err_count.saturating_sub(1);
                }
            }
        }
    }

    fn error_rate(&self) -> f32 {
        let n = self.window.len();
        if n == 0 { 0.0 } else { self.window_err_count as f32 / n as f32 }
    }
}

// ─── Global state ─────────────────────────────────────────────────────────────

#[derive(Default)]
struct WebUiStatsState {
    snapshot: WebUiStatsSnapshot,
    extended: WebUiExtendedSnapshot,
    ctrl_frames: FrameStats,
    traffic_frames: FrameStats,
    pending_sds: VecDeque<PendingSdsCommand>,
}

fn state() -> &'static Mutex<WebUiStatsState> {
    static STATE: OnceLock<Mutex<WebUiStatsState>> = OnceLock::new();
    STATE.get_or_init(|| Mutex::new(WebUiStatsState::default()))
}

fn now_unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

// ─── Public API ───────────────────────────────────────────────────────────────

/// Called by CcBsSubentity::new() on stack init. Preserves the provisioned radio
/// list (which comes from config) but resets all other state.
pub fn reset() {
    if let Ok(mut s) = state().lock() {
        let now = now_unix_ms();
        s.snapshot = WebUiStatsSnapshot { updated_unix_ms: now, ..Default::default() };
        let reset_radios: Vec<ProvisionedRadio> = std::mem::take(&mut s.extended.provisioned_radios)
            .into_iter()
            .map(|mut r| { r.status = MsStatus::Offline; r })
            .collect();
        // Air stats (FrameStats) are intentionally not reset — they are cumulative
        // and survive stack re-init. pending_sds is also preserved so a queued
        // dashboard command issued right at startup is not silently dropped.
        s.extended = WebUiExtendedSnapshot {
            updated_unix_ms: now,
            provisioned_radios: reset_radios,
            ..Default::default()
        };
    }
}

pub fn set_provisioned_radios(radios: Vec<(u32, bool)>) {
    if let Ok(mut s) = state().lock() {
        let old_statuses: HashMap<u32, MsStatus> = s.extended.provisioned_radios
            .iter()
            .map(|r| (r.issi, r.status.clone()))
            .collect();
        let mut new_radios: Vec<ProvisionedRadio> = radios.into_iter().map(|(issi, has_key)| {
            ProvisionedRadio {
                issi,
                has_key,
                status: old_statuses.get(&issi).cloned().unwrap_or(MsStatus::Offline),
            }
        }).collect();
        new_radios.sort_by_key(|r| r.issi);
        s.extended.provisioned_radios = new_radios;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_ms_status(issi: u32, status: MsStatus) {
    if let Ok(mut s) = state().lock() {
        if let Some(radio) = s.extended.provisioned_radios.iter_mut().find(|r| r.issi == issi) {
            radio.status = status;
            s.extended.updated_unix_ms = now_unix_ms();
        }
    }
}

pub fn append_call_log(entry: CallLogEntry) {
    if let Ok(mut s) = state().lock() {
        s.extended.call_log.insert(0, entry);
        if s.extended.call_log.len() > 200 {
            s.extended.call_log.truncate(200);
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn finalize_call_log(call_id: u64, ended_at_unix_ms: u64) {
    if let Ok(mut s) = state().lock() {
        for entry in s.extended.call_log.iter_mut() {
            if entry.call_id == Some(call_id) && entry.is_live {
                entry.is_live = false;
                entry.duration_ms = Some(ended_at_unix_ms.saturating_sub(entry.timestamp_unix_ms));
                break;
            }
        }
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn set_active_talkgroups(mut gssis: Vec<u32>) {
    gssis.sort_unstable();
    gssis.dedup();
    if let Ok(mut s) = state().lock() {
        s.extended.active_talkgroups = gssis;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn inc_sds_sent() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_sent += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

pub fn inc_sds_delivered() {
    if let Ok(mut s) = state().lock() {
        s.extended.sds_delivered += 1;
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Record a UL control-channel frame. Called from lmac_bs for every decoded
/// signalling block regardless of CRC outcome.
pub fn record_ctrl_frame(crc_ok: bool) {
    if let Ok(mut s) = state().lock() {
        s.ctrl_frames.record(!crc_ok);
        let air = &mut s.extended.air;
        air.ul_ctrl_frames_total = s.ctrl_frames.total_alltime;
        air.ul_ctrl_frames_crc_err = s.ctrl_frames.err_alltime;
        air.ctrl_crc_error_rate = s.ctrl_frames.error_rate();
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Record a UL traffic-channel frame. Called from lmac_bs for every decoded
/// voice block regardless of BFI (Bad Frame Indicator).
pub fn record_traffic_frame(crc_ok: bool) {
    if let Ok(mut s) = state().lock() {
        s.traffic_frames.record(!crc_ok);
        let air = &mut s.extended.air;
        air.ul_traffic_frames_total = s.traffic_frames.total_alltime;
        air.ul_traffic_frames_bfi = s.traffic_frames.err_alltime;
        air.traffic_bfi_rate = s.traffic_frames.error_rate();
        s.extended.updated_unix_ms = now_unix_ms();
    }
}

/// Enqueue an outbound SDS command from the web UI. Thread-safe; the stack
/// drains this queue on each tick via `drain_pending_sds`.
pub fn enqueue_sds(cmd: PendingSdsCommand) {
    if let Ok(mut s) = state().lock() {
        s.pending_sds.push_back(cmd);
    }
}

/// Drain all pending SDS commands. Called by CmceBs::tick_start each tick.
pub fn drain_pending_sds() -> Vec<PendingSdsCommand> {
    state().lock().map(|mut s| s.pending_sds.drain(..).collect()).unwrap_or_default()
}

#[allow(clippy::too_many_arguments)]
pub fn publish(
    mut registered_issis: Vec<u32>,
    affiliated_group_links: usize,
    groups_with_listeners: usize,
    active_group_calls: usize,
    active_individual_calls: usize,
    total_group_call_setups: u64,
    total_individual_call_setups: u64,
) {
    registered_issis.sort_unstable();
    registered_issis.dedup();
    let snapshot = WebUiStatsSnapshot {
        registered_issi_count: registered_issis.len() as u64,
        registered_issis,
        affiliated_group_links: affiliated_group_links as u64,
        groups_with_listeners: groups_with_listeners as u64,
        active_group_calls: active_group_calls as u64,
        active_individual_calls: active_individual_calls as u64,
        total_group_call_setups,
        total_individual_call_setups,
        updated_unix_ms: now_unix_ms(),
    };
    if let Ok(mut s) = state().lock() {
        s.snapshot = snapshot;
    }
}

pub fn snapshot() -> WebUiStatsSnapshot {
    state().lock().map(|s| s.snapshot.clone())
        .unwrap_or_else(|_| WebUiStatsSnapshot { updated_unix_ms: now_unix_ms(), ..Default::default() })
}

pub fn snapshot_json() -> String {
    serde_json::to_string(&snapshot()).unwrap_or_else(|_| "{}".to_string())
}

pub fn extended_snapshot() -> WebUiExtendedSnapshot {
    state().lock().map(|s| s.extended.clone())
        .unwrap_or_else(|_| WebUiExtendedSnapshot { updated_unix_ms: now_unix_ms(), ..Default::default() })
}

pub fn extended_snapshot_json() -> String {
    serde_json::to_string(&extended_snapshot()).unwrap_or_else(|_| "{}".to_string())
}
