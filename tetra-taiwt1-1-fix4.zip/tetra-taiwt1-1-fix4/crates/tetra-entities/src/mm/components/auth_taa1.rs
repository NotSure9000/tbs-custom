// Port of TA11/TA12 primitives and required HURDLE internals from
// https://github.com/MidnightBlueLabs/TETRA_crypto (Apache-2.0).

const HURDLE_SBOX: [u8; 256] = [
    0xF4, 0x65, 0x01, 0x00, 0xBA, 0x7A, 0xA7, 0x47, 0x98, 0xDD, 0x9D, 0xAD, 0x96, 0x5D, 0xAA, 0x3D,
    0x58, 0xC0, 0x72, 0xD8, 0x66, 0x4C, 0x3E, 0xE0, 0x80, 0x55, 0xDE, 0x90, 0x2A, 0x4B, 0x83, 0xA0,
    0x51, 0x39, 0xED, 0x6C, 0x8A, 0x2C, 0x56, 0x60, 0x4A, 0x1F, 0xD0, 0x70, 0x6E, 0x33, 0x8B, 0x26,
    0x2E, 0x6F, 0x89, 0x48, 0x5E, 0x40, 0xC3, 0xA4, 0xA9, 0xCF, 0x22, 0x50, 0xE1, 0x15, 0x0C, 0xAB,
    0xD5, 0xF8, 0x5F, 0x36, 0x04, 0xA6, 0x4E, 0x92, 0x1E, 0x2B, 0x88, 0x30, 0x93, 0x45, 0x67, 0x16,
    0x8C, 0x68, 0x23, 0x38, 0x61, 0x25, 0x1A, 0x81, 0x63, 0xCB, 0xC1, 0x13, 0x41, 0x37, 0x0E, 0x97,
    0x5B, 0xCA, 0x57, 0x24, 0x4D, 0x17, 0xC4, 0xB9, 0xB3, 0xEF, 0x8D, 0x52, 0x32, 0x2F, 0xEC, 0x20,
    0xD9, 0x11, 0xD1, 0x28, 0x79, 0xDA, 0xFB, 0xE9, 0xBB, 0x06, 0x77, 0xDB, 0xFC, 0xFE, 0xCD, 0x84,
    0x1D, 0xA1, 0x54, 0x1B, 0xB0, 0xE4, 0xCC, 0x7C, 0x2D, 0x27, 0x31, 0x49, 0xF5, 0x02, 0x69, 0x53,
    0x4F, 0x44, 0xDF, 0x18, 0x5C, 0x0F, 0xBC, 0x9B, 0x94, 0xBD, 0xDC, 0x0B, 0xA2, 0xC7, 0x09, 0xAC,
    0xC6, 0x9F, 0x82, 0x1C, 0x05, 0x46, 0xC2, 0x34, 0x3C, 0x0D, 0x3B, 0xCE, 0xB7, 0xBE, 0x08, 0x9C,
    0x6B, 0xEE, 0xE5, 0x87, 0xAF, 0xBF, 0xF2, 0xEB, 0x7B, 0x07, 0x64, 0xC5, 0xB6, 0xAE, 0x9A, 0x95,
    0x35, 0xA5, 0x59, 0x12, 0x9E, 0xA3, 0xB8, 0x8E, 0x5A, 0xF7, 0x62, 0xD2, 0x3A, 0xA8, 0x7D, 0x85,
    0xF6, 0xC8, 0x71, 0x29, 0xD6, 0xD7, 0x43, 0xF9, 0x78, 0x76, 0x73, 0x10, 0x91, 0x19, 0x0A, 0x99,
    0xF0, 0xE6, 0x3F, 0x14, 0xF1, 0xE2, 0xB1, 0x86, 0xB4, 0xF3, 0x74, 0xFA, 0x6A, 0xB2, 0x21, 0x6D,
    0xEA, 0xB5, 0xE7, 0xE3, 0xC9, 0xD3, 0x8F, 0x03, 0x75, 0xE8, 0xD4, 0x42, 0xFD, 0x7E, 0xFF, 0x7F,
];

const ROTATIONS: [usize; 16] = [5, 5, 5, 5, 5, 3, 7, 5, 5, 5, 5, 7, 3, 5, 5, 5];
const ROUND_CONSTANT: [u8; 16] = [
    0x3C, 0xA7, 0xEC, 0x25, 0x79, 0x57, 0xDF, 0xC0, 0x38, 0x0A, 0x33, 0x1E, 0xF3, 0x8C, 0xF4, 0xF7,
];

#[cfg(target_endian = "little")]
const REORDER: [u32; 16] = [
    0x00000000, 0x80000000, 0x00800000, 0x80800000, 0x00008000, 0x80008000, 0x00808000, 0x80808000, 0x00000080,
    0x80000080, 0x00800080, 0x80800080, 0x00008080, 0x80008080, 0x00808080, 0x80808080,
];

#[cfg(target_endian = "big")]
const REORDER: [u32; 16] = [
    0x00000000, 0x00000080, 0x00008000, 0x00008080, 0x00800000, 0x00800080, 0x00808000, 0x00808080, 0x80000000,
    0x80000080, 0x80008000, 0x80008080, 0x80800000, 0x80800080, 0x80808000, 0x80808080,
];

#[derive(Debug, Clone, Copy)]
pub struct Ta11Ta12Output {
    pub ks: [u8; 16],
    pub res1: [u8; 4],
    pub dck1: [u8; 10],
}

pub fn derive_dck_from_dck1(dck1: &[u8; 10]) -> [u8; 10] {
    let zeros = [0u8; 10];
    tb4(dck1, &zeros)
}

pub fn derive_kso_from_auth_key(k: &[u8], rso: &[u8; 10]) -> Option<[u8; 16]> {
    let key_k: [u8; 16] = k.try_into().ok()?;
    Some(ta11(&key_k, rso))
}

pub fn seal_sck_with_kso(kso: &[u8; 16], sck_vn: u16, sck_n: u8, sck: &[u8; 10]) -> [u8; 15] {
    debug_assert_eq!(sck_n & 0xe0, 0, "SCKN must fit in 5 bits");

    let mut unsealed = [0u8; 11];
    unsealed[..10].copy_from_slice(sck);
    unsealed[10] = sck_n;

    let mut unsealed_padded = [0u8; 16];
    unsealed_padded[..15].copy_from_slice(&transform_88_to_120(&unsealed));
    unsealed_padded[15] = 0;

    let sck_vn_bytes = sck_vn.to_be_bytes();
    let mut adjusted_key = [0u8; 16];
    for i in 0..16 {
        adjusted_key[i] = kso[i] ^ sck_vn_bytes[i & 1];
    }

    let sealed = hurdle_enc_cbc(&unsealed_padded, &adjusted_key);

    let mut out = [0u8; 15];
    out[..7].copy_from_slice(&sealed[..7]);
    out[7..].copy_from_slice(&sealed[8..16]);
    out
}

pub fn tb4(dck1: &[u8; 10], dck2: &[u8; 10]) -> [u8; 10] {
    let mut out = [0u8; 10];
    for i in 0..10 {
        out[i] = dck1[i] ^ dck2[i];
    }
    out
}

pub fn seal_cck_with_dck(dck: &[u8; 10], cck_id: u16, cck: &[u8; 10]) -> [u8; 15] {
    let mut unsealed_padded = [0u8; 16];
    unsealed_padded[..15].copy_from_slice(&transform_80_to_120_alt(cck));
    unsealed_padded[15] = 0;

    let cck_id_bytes = cck_id.to_be_bytes();
    let mut adjusted_dck = [0u8; 10];
    for i in 0..10 {
        adjusted_dck[i] = dck[i] ^ cck_id_bytes[i & 1];
    }

    let hurdle_key = transform_80_to_128(&adjusted_dck);
    let sealed = hurdle_enc_cbc(&unsealed_padded, &hurdle_key);

    let mut out = [0u8; 15];
    out[..7].copy_from_slice(&sealed[..7]);
    out[7..].copy_from_slice(&sealed[8..16]);
    out
}

pub fn compute_ta11_ta12(k: &[u8], rs: &[u8; 10], rand1: &[u8; 10]) -> Option<Ta11Ta12Output> {
    let key_k: [u8; 16] = k.try_into().ok()?;
    let ks = ta11(&key_k, rs);
    let (res1, dck1) = ta12(&ks, rand1);
    Some(Ta11Ta12Output { ks, res1, dck1 })
}

fn ta11(key_k: &[u8; 16], rs: &[u8; 10]) -> [u8; 16] {
    let challenge = transform_80_to_128_alt(rs);
    hurdle_enc_cbc(&challenge, key_k)
}

fn ta12(key_ks: &[u8; 16], rand1: &[u8; 10]) -> ([u8; 4], [u8; 10]) {
    let rand_expanded = transform_80_to_128_alt(rand1);
    let ciphertext = hurdle_enc_cbc(&rand_expanded, key_ks);

    let res = [
        ciphertext[0] ^ ciphertext[3],
        ciphertext[6],
        ciphertext[9],
        ciphertext[12] ^ ciphertext[15],
    ];

    let dck = [
        ciphertext[1],
        ciphertext[2],
        ciphertext[4],
        ciphertext[5],
        ciphertext[7],
        ciphertext[8],
        ciphertext[10],
        ciphertext[11],
        ciphertext[13],
        ciphertext[14],
    ];

    (res, dck)
}

fn transform_80_to_120_alt(input: &[u8; 10]) -> [u8; 15] {
    let mut out = [0u8; 15];
    out[0] = input[0];
    out[1] = input[1];
    out[2] = out[0] ^ out[1];
    out[3] = input[2];
    out[4] = input[3];
    out[5] = out[3] ^ out[4];
    out[6] = input[4];
    out[7] = input[5];
    out[8] = out[6] ^ out[7];
    out[9] = input[6];
    out[10] = input[7];
    out[11] = out[9] ^ out[10];
    out[12] = input[8];
    out[13] = input[9];
    out[14] = out[12] ^ out[13];
    out
}

fn transform_88_to_120(input: &[u8; 11]) -> [u8; 15] {
    let mut out = [0u8; 15];
    out[0] = input[0];
    out[1] = input[1];
    out[2] = input[0] ^ input[1];
    out[3] = input[2];
    out[4] = input[3];
    out[5] = input[4];
    out[6] = input[2] ^ input[3] ^ input[4];
    out[7] = input[5];
    out[8] = input[6];
    out[9] = input[7];
    out[10] = input[5] ^ input[6] ^ input[7];
    out[11] = input[8];
    out[12] = input[9];
    out[13] = input[10];
    out[14] = input[8] ^ input[9] ^ input[10];
    out
}

fn transform_80_to_120(input: &[u8; 10]) -> [u8; 15] {
    let mut out = [0u8; 15];
    out[0] = input[0].wrapping_add(input[9]);
    out[1] = input[0];
    out[2] = input[9];
    out[3] = input[1].wrapping_add(input[8]);
    out[4] = input[1];
    out[5] = input[8];
    out[6] = input[2].wrapping_add(input[7]);
    out[7] = input[2];
    out[8] = input[7];
    out[9] = input[3].wrapping_add(input[6]);
    out[10] = input[3];
    out[11] = input[6];
    out[12] = input[4].wrapping_add(input[5]);
    out[13] = input[4];
    out[14] = input[5];
    out
}

fn transform_80_to_128(input: &[u8; 10]) -> [u8; 16] {
    let mut out = [0u8; 16];
    let t120 = transform_80_to_120(input);
    out[1..16].copy_from_slice(&t120);
    out[0] = out[1] ^ out[4] ^ out[7] ^ out[10] ^ out[13];
    out
}

fn transform_80_to_128_alt(input: &[u8; 10]) -> [u8; 16] {
    let t120 = transform_80_to_120_alt(input);
    let mut out = [0u8; 16];
    out[..15].copy_from_slice(&t120);
    out[15] = out[2]
        .wrapping_add(out[5])
        .wrapping_add(out[8])
        .wrapping_add(out[11])
        .wrapping_add(out[14]);
    out
}

fn hurdle_set_key(key: &[u8; 16]) -> [u8; 256] {
    let mut round_keys = [0u8; 256];
    round_keys[..16].copy_from_slice(key);

    for i in 1..16 {
        let prev = (i - 1) * 16;
        let cur = i * 16;

        for j in 0..16 {
            round_keys[cur + j] = round_keys[prev + ((j + ROTATIONS[i]) & 0x0F)];
        }
        for j in 0..16 {
            round_keys[cur + j] ^= ROUND_CONSTANT[j];
        }
    }

    round_keys
}

fn hurdle_f(rhs: &[u8; 4], round_key: &[u8]) -> [u8; 4] {
    let mut output_bits: u32 = 0;

    let mut s = HURDLE_SBOX[rhs[3].wrapping_add(round_key[15]) as usize];
    s = HURDLE_SBOX[(rhs[2].wrapping_add(round_key[14]) ^ s) as usize];
    s = HURDLE_SBOX[(rhs[1].wrapping_add(round_key[13]) ^ s) as usize];
    s = HURDLE_SBOX[(rhs[0].wrapping_add(round_key[12]) ^ s) as usize];

    s = HURDLE_SBOX[(rhs[3].wrapping_add(round_key[11]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[1].wrapping_add(round_key[10]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[2].wrapping_add(round_key[9]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[0].wrapping_add(round_key[8]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[1].wrapping_add(round_key[7]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[3].wrapping_add(round_key[6]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[0].wrapping_add(round_key[5]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    s = HURDLE_SBOX[(rhs[2].wrapping_add(round_key[4]) ^ s) as usize];
    output_bits >>= 1;
    output_bits |= REORDER[(s & 0x0F) as usize];

    output_bits.to_ne_bytes()
}

fn hurdle_encrypt_block(input: &[u8; 8], round_keys: &[u8; 256], decrypt: bool) -> [u8; 8] {
    let mut lhs = u32::from_ne_bytes([input[0], input[1], input[2], input[3]]);
    let mut rhs = u32::from_ne_bytes([input[4], input[5], input[6], input[7]]);

    let mut rk_index: isize = if decrypt { 15 } else { 0 };
    let rk_step: isize = if decrypt { -1 } else { 1 };

    for _ in 0..16 {
        let rhs_bytes = rhs.to_ne_bytes();
        let mut rhs_arr = [0u8; 4];
        rhs_arr.copy_from_slice(&rhs_bytes);

        let rk_off = rk_index as usize * 16;
        let f_out = hurdle_f(&rhs_arr, &round_keys[rk_off..rk_off + 16]);
        let mut tmp = u32::from_ne_bytes(f_out);

        tmp ^= lhs;
        lhs = rhs;
        rhs = tmp;

        rk_index += rk_step;
    }

    let mut out = [0u8; 8];
    out[..4].copy_from_slice(&rhs.to_ne_bytes());
    out[4..].copy_from_slice(&lhs.to_ne_bytes());
    out
}

fn hurdle_enc_cbc(plaintext: &[u8; 16], key: &[u8; 16]) -> [u8; 16] {
    let round_keys = hurdle_set_key(key);

    let mut pt0 = [0u8; 8];
    pt0.copy_from_slice(&plaintext[..8]);
    let c0 = hurdle_encrypt_block(&pt0, &round_keys, false);

    let mut intermediate = [0u8; 8];
    for i in 0..8 {
        intermediate[i] = c0[i] ^ plaintext[8 + i];
    }
    let c1 = hurdle_encrypt_block(&intermediate, &round_keys, false);

    let mut out = [0u8; 16];
    out[..8].copy_from_slice(&c0);
    out[8..].copy_from_slice(&c1);
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ta11_ta12_ref_vector_1() {
        let k = [
            0x3A, 0x6B, 0xC3, 0xE2, 0x3D, 0x66, 0x41, 0xE4, 0x55, 0x52, 0x45, 0xAE, 0x6C, 0xEA, 0xE2, 0x6D,
        ];
        let rs = [0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0x10, 0x32];
        let rand1 = [0x89, 0x67, 0x45, 0x23, 0x01, 0xFE, 0xDC, 0xBA, 0x98, 0x76];

        let out = compute_ta11_ta12(&k, &rs, &rand1).expect("ta11/ta12 failed");

        assert_eq!(
            out.ks,
            [
                0xF6, 0x37, 0xE2, 0xF1, 0x69, 0x28, 0x18, 0x99, 0x05, 0x28, 0x07, 0x5F, 0x94, 0x02, 0xE4, 0x61,
            ]
        );
        assert_eq!(out.res1, [0xCB, 0x6D, 0x5C, 0xB6]);
        assert_eq!(out.dck1, [0xE0, 0x04, 0x86, 0x0F, 0x87, 0x97, 0xEA, 0x29, 0x68, 0x72]);
    }

    #[test]
    fn ta11_ta12_ref_vector_2() {
        let k = [
            0xF7, 0x31, 0x63, 0xB6, 0x8F, 0xBF, 0xDF, 0x23, 0xC9, 0x0E, 0x8F, 0x0D, 0xDB, 0xD8, 0xA4, 0x15,
        ];
        let rs = [0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33];
        let rand1 = [0x55, 0x44, 0x33, 0x22, 0x11, 0x00, 0x99, 0x88, 0x77, 0x66];

        let out = compute_ta11_ta12(&k, &rs, &rand1).expect("ta11/ta12 failed");

        assert_eq!(
            out.ks,
            [
                0x9D, 0x21, 0x49, 0x6A, 0xAD, 0x04, 0x07, 0x2B, 0xB4, 0x62, 0x02, 0xEF, 0x03, 0xF4, 0x20, 0x5A,
            ]
        );
        assert_eq!(out.res1, [0xF2, 0xF6, 0x62, 0x6D]);
        assert_eq!(out.dck1, [0xD4, 0x95, 0x90, 0x93, 0xD8, 0xF9, 0x7F, 0xDF, 0x39, 0x56]);
    }

    #[test]
    fn tb4_with_zero_second_half() {
        let dck1 = [0xAB, 0x73, 0x38, 0xB2, 0xF3, 0x54, 0x59, 0xD6, 0xB1, 0x26];
        let dck = derive_dck_from_dck1(&dck1);
        assert_eq!(dck, dck1);
    }

    #[test]
    fn ta31_ref_vector() {
        let dck = [0xAB, 0x73, 0x38, 0xB2, 0xF3, 0x54, 0x59, 0xD6, 0xB1, 0x26];
        let cck = [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA];
        let out = seal_cck_with_dck(&dck, 0x1234, &cck);
        assert_eq!(
            out,
            [
                0xCC, 0xF6, 0xAC, 0x5D, 0x21, 0xEB, 0x3E, 0x3B, 0x67, 0x48, 0x99, 0x0A, 0xBD, 0xB7, 0x62,
            ]
        );
    }

    #[test]
    fn ta51_ref_vector() {
        let kso = [
            0x77, 0xE7, 0x9F, 0xEE, 0x7F, 0xC6, 0x54, 0xDC, 0x65, 0x44, 0x64, 0x4F, 0xDF, 0x47, 0x68, 0x15,
        ];
        let sck = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];

        let out = seal_sck_with_kso(&kso, 0x0F6D, 0x0F, &sck);
        assert_eq!(
            out,
            [
                0x08, 0x3D, 0x05, 0xA7, 0x8E, 0x86, 0xFD, 0x5F, 0x46, 0xD6, 0x2B, 0x28, 0x42, 0x2B, 0x0B,
            ]
        );
    }
}
