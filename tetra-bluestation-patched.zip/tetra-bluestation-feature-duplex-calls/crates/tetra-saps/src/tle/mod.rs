// Table 20.16

pub struct TleCancelReq;

pub struct TleReportInd;

pub struct TleUnitdataReq;
pub struct TleUnitdataInd;
pub struct TleUnitdataConf; // Optional??
