// Port of TEA2 primitives from
// https://github.com/MidnightBlueLabs/TETRA_crypto (Apache-2.0).
//
// Key differences vs TEA1:
//   - IV XOR constant: 0x5A6E3278 (TEA1: 0x9672_4FA1)
//   - Key register: 10-byte shift register (TEA1: u32 with SBOX feedback)
//   - IV taps: LUT_A from bits [15:0], LUT_B from bits [39:24], reorder from [47:40]
//             (TEA1:             [23:8],              [55:40],              [39:32])
//   - State word bit extraction: different tap positions (see tea2_state_word_to_newbyte)
//   - New byte XOR: includes extra (iv >> 16) term
//   - Mix byte fed into iv[31:24] (TEA1: iv[39:32])
//   - Warm-up rounds: 51 (TEA1: 54)
//   - SCK key size: still 80-bit / [u8; 10] — identical to TEA1

const TEA2_LUT_A: [u16; 8] = [0x2579, 0x86E5, 0xB6C8, 0x31D6, 0x7394, 0x934D, 0x638E, 0xC68B];
const TEA2_LUT_B: [u16; 8] = [0xD68A, 0x97A1, 0xB2C9, 0x239E, 0x9C71, 0x36E8, 0xC9B2, 0x6CD1];

const TEA2_SBOX: [u8; 256] = [
    0x62, 0xDA, 0xFD, 0xB6, 0xBB, 0x9C, 0xD8, 0x2A, 0xAB, 0x28, 0x6E, 0x42, 0xE7, 0x1C, 0x78, 0x9E,
    0xFC, 0xCA, 0x81, 0x8E, 0x32, 0x3B, 0xB4, 0xEF, 0x9F, 0x8B, 0xDB, 0x94, 0x0F, 0x9A, 0xA2, 0x96,
    0x1B, 0x7A, 0xFF, 0xAA, 0xC5, 0xD6, 0xBC, 0x24, 0xDF, 0x44, 0x03, 0x09, 0x0B, 0x57, 0x90, 0xBA,
    0x7F, 0x1F, 0xCF, 0x71, 0x98, 0x07, 0xF8, 0xA1, 0x60, 0xF7, 0x52, 0x8D, 0xE5, 0xD7, 0x69, 0x87,
    0x14, 0xED, 0x92, 0xEB, 0xB3, 0x2F, 0xE9, 0x3D, 0xC6, 0x50, 0x5A, 0xA7, 0x45, 0x18, 0x11, 0xC4,
    0xCE, 0xAC, 0xF4, 0x1D, 0x82, 0x54, 0x3E, 0x49, 0xD5, 0xEE, 0x84, 0x35, 0x41, 0x3A, 0xEC, 0x34,
    0x17, 0xE0, 0xC9, 0xFE, 0xE8, 0xCB, 0xE6, 0xAE, 0x68, 0xE2, 0x6B, 0x46, 0xC8, 0x47, 0xB2, 0xE3,
    0x97, 0x10, 0x0E, 0xB8, 0x76, 0x5B, 0xBE, 0xF5, 0xA6, 0x3C, 0x8F, 0xF6, 0xD1, 0xAF, 0xC0, 0x5E,
    0x7E, 0xCD, 0x7C, 0x51, 0x6D, 0x74, 0x2C, 0x16, 0xF2, 0xA5, 0x65, 0x64, 0x58, 0x72, 0x1E, 0xF1,
    0x04, 0xA8, 0x13, 0x53, 0x31, 0xB1, 0x20, 0xD3, 0x75, 0x5F, 0xA4, 0x56, 0x06, 0x8A, 0x8C, 0xD9,
    0x70, 0x12, 0x29, 0x61, 0x4F, 0x4C, 0x15, 0x05, 0xD2, 0xBD, 0x7D, 0x9B, 0x99, 0x83, 0x2B, 0x25,
    0xD0, 0x23, 0x48, 0x3F, 0xB0, 0x2E, 0x0D, 0x0C, 0xC7, 0xCC, 0xB7, 0x5C, 0xF0, 0xBF, 0x2D, 0x4E,
    0x40, 0x39, 0x9D, 0x21, 0x37, 0x77, 0x73, 0x4B, 0x4D, 0x5D, 0xFA, 0xDE, 0x00, 0x80, 0x85, 0x6F,
    0x22, 0x91, 0xDC, 0x26, 0x38, 0xE4, 0x4A, 0x79, 0x6A, 0x67, 0x93, 0xF3, 0xFB, 0x19, 0xA0, 0x7B,
    0xF9, 0x95, 0x89, 0x66, 0xB9, 0xD4, 0xC1, 0xDD, 0x63, 0x33, 0xE1, 0xC3, 0xB5, 0xA3, 0xC2, 0x27,
    0x0A, 0x88, 0xA9, 0x1A, 0x6C, 0x43, 0xEA, 0xAD, 0x30, 0x86, 0x36, 0x59, 0x08, 0x55, 0x01, 0x02,
];

fn tea2_expand_iv(short_iv: u32) -> u64 {
    let mut xorred = short_iv ^ 0x5A6E_3278;
    xorred = xorred.rotate_left(8);
    let iv = (u64::from(short_iv) << 32) | u64::from(xorred);
    iv.rotate_right(8)
}

/// Tap positions differ from TEA1:
/// - bit1 of st0 feeds dist[0] (via >> 1 & 1)
/// - bit1 of st0 feeds dist[1] (via >> 1 & 2, same source bit into the next position)
/// - bit5 of st1 feeds dist[2] (via >> 5 & 4)
/// - bit3 of st1 feeds dist[3] (via << 3 & 8, i.e. bit4 shifted — but bit3 at position 0
///   shifted left 3 = position 3, so bit3 into dist[3])
///
/// This matches the C source exactly:
///   bDist = ((bSt0 >> 1) & 0x1) | ((bSt0 >> 1) & 0x2) | ((bSt1 >> 5) & 0x4) | ((bSt1 << 3) & 0x8);
fn tea2_state_word_to_newbyte(st: u16, lut: &[u16; 8]) -> u8 {
    let mut st0 = st as u8;
    let mut st1 = (st >> 8) as u8;
    let mut out = 0u8;

    for (i, tap_lut) in lut.iter().enumerate() {
        let dist = ((st0 >> 1) & 0x1) | ((st0 >> 1) & 0x2) | ((st1 >> 5) & 0x4) | ((st1 << 3) & 0x8);
        if (*tap_lut & (1u16 << dist)) != 0 {
            out |= 1 << i;
        }
        st0 = st0.rotate_right(1);
        st1 = st1.rotate_right(1);
    }

    out
}

fn tea2_reorder_state_byte(st_byte: u8) -> u8 {
    let mut out = 0u8;
    out |= (st_byte << 6) & 0x40;
    out |= (st_byte << 3) & 0x10;
    out |= (st_byte >> 2) & 0x01;
    out |= (st_byte << 2) & 0x20;
    out |= (st_byte << 3) & 0x80;
    out |= (st_byte >> 4) & 0x02;
    out |= (st_byte >> 3) & 0x08;
    out |= (st_byte >> 5) & 0x04;
    out
}

fn tea2_inner(mut iv_reg: u64, mut key_reg: [u8; 10], out: &mut [u8]) {
    let mut skip_rounds = 51;

    for out_b in out.iter_mut() {
        for _ in 0..skip_rounds {
            // Step 1: SBOX feedback into 10-byte shift register
            let sbox_out = TEA2_SBOX[(key_reg[0] ^ key_reg[7]) as usize];
            key_reg.copy_within(1..10, 0); // memmove left by 1
            key_reg[9] = sbox_out;

            // Step 2: Derive bytes from IV state
            // LUT_A taps iv[15:0], LUT_B taps iv[39:24], reorder byte from iv[47:40]
            let deriv_01 = tea2_state_word_to_newbyte((iv_reg & 0xFFFF) as u16, &TEA2_LUT_A);
            let deriv_34 = tea2_state_word_to_newbyte(((iv_reg >> 24) & 0xFFFF) as u16, &TEA2_LUT_B);
            let reord_5 = tea2_reorder_state_byte(((iv_reg >> 40) & 0xFF) as u8);

            // Step 3: Combine — note the extra (iv >> 16) term vs TEA1
            let new_byte = ((iv_reg >> 56) ^ (iv_reg >> 16) ^ u64::from(reord_5) ^ u64::from(deriv_01) ^ u64::from(sbox_out)) as u8;
            let mix_byte = deriv_34;

            // Step 4: Update IV register — mix_byte fed into bits[31:24]
            iv_reg = ((iv_reg << 8) ^ (u64::from(mix_byte) << 24)) | u64::from(new_byte);
        }

        *out_b = (iv_reg >> 56) as u8;
        skip_rounds = 19;
    }
}

/// TEA2 keystream generation.
///
/// `frame_numbers` is the 29-bit TETRA IV built by [`super::tea1::build_iv`] —
/// the IV construction is identical for TEA1 and TEA2.
/// `key` is the 80-bit ECK (derived from the 80-bit SCK via TB5, also shared with TEA1).
pub fn tea2(frame_numbers: u32, key: &[u8; 10], out: &mut [u8]) {
    let iv = tea2_expand_iv(frame_numbers);
    let key_reg: [u8; 10] = *key;
    tea2_inner(iv, key_reg, out);
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Known vectors from MidnightBlueLabs/TETRA_crypto tests.c — test_TEA2()
    #[test]
    fn tea2_known_vectors() {
        let mut out = [0u8; 10];

        // Vector 1: all-zero key
        tea2(0x1234_5678, &[0u8; 10], &mut out);
        assert_eq!(
            out,
            [0xA7, 0x98, 0x39, 0xE4, 0xBA, 0x88, 0xEE, 0x54, 0xA0, 0x29],
            "TEA2 vector 1 (all-zero key) failed"
        );

        // Vector 2: non-trivial key
        tea2(
            0x1234_5678,
            &[0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA],
            &mut out,
        );
        assert_eq!(
            out,
            [0x64, 0x70, 0x4E, 0xA9, 0xD7, 0xDC, 0x25, 0x60, 0x81, 0x39],
            "TEA2 vector 2 (non-trivial key) failed"
        );
    }
}
