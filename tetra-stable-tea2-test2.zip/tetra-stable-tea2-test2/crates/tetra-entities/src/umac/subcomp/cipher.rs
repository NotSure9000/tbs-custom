/// Active air-interface cipher + ECK pair.
///
/// Replaces the bare `Option<[u8; 10]>` (TEA1-only) that was previously threaded
/// through `UmacBs`, `BsChannelScheduler`, and `BsFragger`.  Adding a new TEA
/// variant here is the only change required to the cipher layer.
///
/// Both TEA1 and TEA2 use an 80-bit (10-byte) ECK derived from the 80-bit SCK
/// via TB5 (`tea1::derive_eck_from_ck`).  The derivation function is
/// cipher-agnostic and is reused unchanged.
///
/// `build_iv` and `apply_keystream_segment` live here so callers need only one
/// import regardless of which algorithm is active.
use tetra_core::{BitBuffer, Direction, TdmaTime};

use super::{tea1, tea2};

#[derive(Debug, Clone, Copy)]
pub enum AirCipher {
    Tea1([u8; 10]),
    Tea2([u8; 10]),
}

impl AirCipher {
    /// Returns the ECK bytes regardless of algorithm.
    pub fn eck(&self) -> &[u8; 10] {
        match self {
            AirCipher::Tea1(k) | AirCipher::Tea2(k) => k,
        }
    }

    /// Generate `out.len()` keystream bytes using the appropriate algorithm.
    fn generate_keystream(&self, frame_numbers: u32, out: &mut [u8]) {
        match self {
            AirCipher::Tea1(eck) => tea1::tea1(frame_numbers, eck, out),
            AirCipher::Tea2(eck) => tea2::tea2(frame_numbers, eck, out),
        }
    }

    /// Apply one keystream segment to `bitbuf` in-place (XOR).
    ///
    /// Mirrors the old `tea1::apply_keystream_segment` but dispatches on
    /// the active cipher.  All parameters are identical.
    pub fn apply_keystream_segment(
        &self,
        bitbuf: &mut BitBuffer,
        num_bits: usize,
        time: TdmaTime,
        direction: Direction,
        keystream_skip_bits: usize,
    ) -> bool {
        if num_bits == 0 {
            return true;
        }

        let total_bits = keystream_skip_bits.saturating_add(num_bits);
        let mut ks_bytes = vec![0u8; (total_bits + 7) / 8];
        let iv = tea1::build_iv(time, direction);
        self.generate_keystream(iv, &mut ks_bytes);

        let mut seg_bytes = vec![0u8; (num_bits + 7) / 8];
        for i in 0..num_bits {
            let src_idx = i + keystream_skip_bits;
            let src_bit = (ks_bytes[src_idx / 8] >> (7 - (src_idx % 8))) & 1;
            seg_bytes[i / 8] |= src_bit << (7 - (i % 8));
        }

        bitbuf.xor_bytearr(&seg_bytes, num_bits).is_some()
    }
}
