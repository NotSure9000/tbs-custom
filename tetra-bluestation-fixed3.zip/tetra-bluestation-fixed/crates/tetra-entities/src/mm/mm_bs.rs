use std::collections::HashMap;
use std::fmt::Write as _;

use crate::{MessageQueue, TetraEntityTrait, brew};
use tetra_config::bluestation::SharedConfig;
use tetra_core::tetra_entities::TetraEntity;
use tetra_core::{BitBuffer, Sap, SsiType, TdmaTime, TetraAddress, assert_warn, unimplemented_log};
use tetra_saps::control::brew::{BrewSubscriberAction, MmSubscriberUpdate};
use tetra_saps::lmm::LmmMleUnitdataReq;
use tetra_saps::{SapMsg, SapMsgInner};

use crate::mm::components::client_state::{MmClientMgr, MmClientState};
use crate::mm::components::auth_taa1::compute_ta11_ta12;
use crate::mm::components::not_supported::make_ul_mm_pdu_function_not_supported;
use tetra_pdus::mm::enums::location_update_type::LocationUpdateType;
use tetra_pdus::mm::enums::mm_pdu_type_ul::MmPduTypeUl;
use tetra_pdus::mm::enums::status_uplink::StatusUplink;
use tetra_pdus::mm::fields::group_identity_attachment::GroupIdentityAttachment;
use tetra_pdus::mm::fields::group_identity_downlink::GroupIdentityDownlink;
use tetra_pdus::mm::fields::group_identity_location_accept::GroupIdentityLocationAccept;
use tetra_pdus::mm::fields::group_identity_uplink::GroupIdentityUplink;
use tetra_pdus::mm::pdus::d_authentication::DAuthentication;
use tetra_pdus::mm::pdus::d_attach_detach_group_identity_acknowledgement::DAttachDetachGroupIdentityAcknowledgement;
use tetra_pdus::mm::pdus::d_location_update_accept::DLocationUpdateAccept;
use tetra_pdus::mm::pdus::d_location_update_command::DLocationUpdateCommand;
use tetra_pdus::mm::pdus::d_location_update_reject::DLocationUpdateReject;
use tetra_pdus::mm::pdus::u_attach_detach_group_identity::UAttachDetachGroupIdentity;
use tetra_pdus::mm::pdus::u_authentication::UAuthentication;
use tetra_pdus::mm::pdus::u_itsi_detach::UItsiDetach;
use tetra_pdus::mm::pdus::u_location_update_demand::ULocationUpdateDemand;
use tetra_pdus::mm::pdus::u_mm_status::UMmStatus;

const AUTH_REJECT_CAUSE: u8 = 0; // Unspecified - allows radio to retry; cause 1 "Roaming not supported" would cause radios to blacklist this cell
const AUTH_REJECT_NOT_SUPPORTED: u8 = 0;

#[derive(Clone, Copy, Debug)]
struct PendingAuthChallenge {
    rand1: [u8; 10],
    rs: [u8; 10],
    expected_res1: u32,
    issued_at: TdmaTime,
}

#[derive(Clone, Debug)]
struct PendingLocationUpdate {
    location_update_type: LocationUpdateType,
    group_identity_uplink: Option<Vec<GroupIdentityUplink>>,
    handle: u32,
    issued_at: TdmaTime,
}

pub struct MmBs {
    config: SharedConfig,
    pub client_mgr: MmClientMgr,
    pending_auth: HashMap<u32, PendingAuthChallenge>,
    pending_location_update: HashMap<u32, PendingLocationUpdate>,
    authenticated_ms: HashMap<u32, TdmaTime>,
}

impl MmBs {
    pub fn new(config: SharedConfig) -> Self {
        let this = Self {
            config,
            client_mgr: MmClientMgr::new(),
            pending_auth: HashMap::new(),
            pending_location_update: HashMap::new(),
            authenticated_ms: HashMap::new(),
        };
        this.log_ms_auth_config();
        this
    }

    fn emit_subscriber_update(
        &self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        groups: Vec<u32>,
        action: BrewSubscriberAction,
    ) {
        // If brew is active, take all brew-routable groups and emit an update to brew entity
        if brew::is_active(&self.config) {
            let brew_groups = groups
                .iter()
                .filter(|gssi| brew::is_brew_gssi_routable(&self.config, **gssi))
                .copied()
                .collect::<Vec<u32>>();
            if !brew_groups.is_empty() {
                let brew_update = MmSubscriberUpdate {
                    issi,
                    groups: brew_groups,
                    action,
                };
                let msg = SapMsg {
                    sap: Sap::Control,
                    src: TetraEntity::Mm,
                    dest: TetraEntity::Brew,
                    dltime,
                    msg: SapMsgInner::MmSubscriberUpdate(brew_update),
                };
                queue.push_back(msg);
            }
        }

        // Always emit an update to the Cmce entity
        let mm_update = MmSubscriberUpdate { issi, groups, action };
        let msg = SapMsg {
            sap: Sap::Control,
            src: TetraEntity::Mm,
            dest: TetraEntity::Cmce,
            dltime,
            msg: SapMsgInner::MmSubscriberUpdate(mm_update),
        };
        queue.push_back(msg);
    }

    fn log_ms_auth_config(&self) {
        let cfg = self.config.config();
        let Some(ms_auth) = cfg.ms_auth.as_ref() else {
            tracing::info!("MS auth is disabled (no [ms_auth] config)");
            return;
        };

        if !ms_auth.enabled {
            tracing::info!("MS auth is configured but disabled (ms_auth.enabled=false)");
            return;
        }

        let mut issis: Vec<u32> = ms_auth.subscribers.keys().copied().collect();
        issis.sort_unstable();

        tracing::info!(
            "MS auth enabled: loaded {} key(s), ttl={} slots, log_plain_k={}",
            issis.len(),
            ms_auth.challenge_ttl_slots,
            ms_auth.log_plain_k
        );

        for issi in issis {
            if let Some(k_value) = ms_auth.subscribers.get(&issi) {
                tracing::info!(
                    "MS auth configured key ISSI {}: {}",
                    issi,
                    Self::k_log_value(k_value, ms_auth.log_plain_k)
                );
            }
        }
    }

    fn k_hex(k_value: &[u8]) -> String {
        let mut out = String::with_capacity(k_value.len() * 2);
        for byte in k_value {
            let _ = write!(&mut out, "{:02X}", byte);
        }
        out
    }

    fn k_fingerprint(k_value: &[u8]) -> String {
        let digest = md5::compute(k_value);
        format!("{:02x}{:02x}{:02x}{:02x}", digest.0[0], digest.0[1], digest.0[2], digest.0[3])
    }

    fn k_log_value(k_value: &[u8], log_plain_k: bool) -> String {
        let fp = Self::k_fingerprint(k_value);
        let k_hex = Self::k_hex(k_value);
        if log_plain_k {
            format!("{} (len={} fp={})", k_hex, k_value.len(), fp)
        } else if k_hex.len() <= 8 {
            format!("{} (len={} fp={})", k_hex, k_value.len(), fp)
        } else {
            format!(
                "{}...{} (len={} fp={})",
                &k_hex[..8],
                &k_hex[k_hex.len() - 8..],
                k_value.len(),
                fp
            )
        }
    }

    fn prune_stale_auth_challenges(&mut self, now: TdmaTime, challenge_ttl_slots: i32) {
        self.pending_auth.retain(|_, pending| pending.issued_at.age(now) <= challenge_ttl_slots);
        self.pending_location_update
            .retain(|_, pending| pending.issued_at.age(now) <= challenge_ttl_slots);
        self.authenticated_ms.retain(|_, issued_at| issued_at.age(now) <= challenge_ttl_slots);
    }

    fn send_location_update_auth_challenge(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        rand1: [u8; 10],
        rs: [u8; 10],
    ) {
        let pdu = DAuthentication::Demand { rand1, rs };
        Self::send_d_authentication(queue, dltime, issi, handle, pdu);
    }

    fn send_d_authentication(queue: &mut MessageQueue, dltime: TdmaTime, issi: u32, handle: u32, pdu: DAuthentication) {
        let mut sdu = BitBuffer::new_autoexpand(128);
        pdu.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    /// Returns true when the MS is authenticated for this location update flow.
    /// Returns false when a challenge is sent or the update is rejected.
    fn handle_location_update_auth(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        pdu: &ULocationUpdateDemand,
    ) -> bool {
        let cfg = self.config.config();
        let Some(ms_auth) = cfg.ms_auth.as_ref() else {
            return true;
        };
        if !ms_auth.enabled {
            return true;
        }

        self.prune_stale_auth_challenges(dltime, ms_auth.challenge_ttl_slots);

        let Some(k_value) = ms_auth.subscribers.get(&issi) else {
            tracing::warn!("Rejecting location update for ISSI {}: no K configured", issi);
            self.pending_auth.remove(&issi);
            self.pending_location_update.remove(&issi);
            self.authenticated_ms.remove(&issi);
            Self::send_d_location_update_reject(queue, dltime, issi, handle, pdu.location_update_type, AUTH_REJECT_CAUSE);
            return false;
        };

        tracing::info!(
            "MS auth key for ISSI {}: {}",
            issi,
            Self::k_log_value(k_value, ms_auth.log_plain_k)
        );

        if self.authenticated_ms.remove(&issi).is_some() {
            self.pending_location_update.remove(&issi);
            tracing::info!("ISSI {} passed D/U-AUTHENTICATION and is accepted for location update", issi);
            return true;
        }

        if let Some(pending) = self.pending_auth.get(&issi).copied() {
            let pending_group_identity_uplink = pdu
                .group_identity_location_demand
                .as_ref()
                .and_then(|gild| gild.group_identity_uplink.clone());
            self.pending_location_update.insert(
                issi,
                PendingLocationUpdate {
                    location_update_type: pdu.location_update_type,
                    group_identity_uplink: pending_group_identity_uplink,
                    handle,
                    issued_at: dltime,
                },
            );

            tracing::debug!("ISSI {} has pending D-AUTHENTICATION challenge; re-sending", issi);
            Self::send_location_update_auth_challenge(queue, dltime, issi, handle, pending.rand1, pending.rs);
            return false;
        }

        if pdu.authentication_uplink.is_some() {
            tracing::warn!(
                "ISSI {} sent legacy authentication_uplink type3 element; using D/U-AUTHENTICATION flow instead",
                issi
            );
        }

        let mut rand1 = [0u8; 10];
        for b in rand1.iter_mut() {
            *b = rand::random::<u8>();
        }

        let mut rs = [0u8; 10];
        for b in rs.iter_mut() {
            *b = rand::random::<u8>();
        }

        let Some(auth) = compute_ta11_ta12(k_value, &rs, &rand1) else {
            tracing::warn!(
                "Rejecting ISSI {}: K has invalid length {} for TA11/TA12 (expected 16 bytes)",
                issi,
                k_value.len()
            );
            self.pending_auth.remove(&issi);
            self.pending_location_update.remove(&issi);
            self.authenticated_ms.remove(&issi);
            Self::send_d_location_update_reject(queue, dltime, issi, handle, pdu.location_update_type, AUTH_REJECT_CAUSE);
            return false;
        };

        let expected_res1 = u32::from_be_bytes(auth.res1);

        let pending_group_identity_uplink = pdu
            .group_identity_location_demand
            .as_ref()
            .and_then(|gild| gild.group_identity_uplink.clone());

        self.pending_auth.insert(
            issi,
            PendingAuthChallenge {
                rand1,
                rs,
                expected_res1,
                issued_at: dltime,
            },
        );
        self.pending_location_update.insert(
            issi,
            PendingLocationUpdate {
                location_update_type: pdu.location_update_type,
                group_identity_uplink: pending_group_identity_uplink,
                handle,
                issued_at: dltime,
            },
        );
        tracing::info!(
            "Sending D-AUTHENTICATION demand for ISSI {} (RAND1={}, RS={}, expected_RES1=0x{:08X})",
            issi,
            Self::k_hex(&rand1),
            Self::k_hex(&rs),
            expected_res1
        );
        if ms_auth.log_plain_k {
            tracing::debug!(
                "ISSI {} TA11 result KS={} DCK1={} (for diagnostics)",
                issi,
                Self::k_hex(&auth.ks),
                Self::k_hex(&auth.dck1)
            );
        } else {
            tracing::debug!(
                "ISSI {} TA11 result KS fp={} DCK1 fp={}",
                issi,
                Self::k_fingerprint(&auth.ks),
                Self::k_fingerprint(&auth.dck1)
            );
        }

        Self::send_location_update_auth_challenge(queue, dltime, issi, handle, rand1, rs);
        false
    }

    fn send_d_location_update_accept(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        pdu_response: DLocationUpdateAccept,
    ) {
        let mut sdu = BitBuffer::new_autoexpand(64);
        pdu_response.to_bitbuf(&mut sdu).unwrap(); // we want to know when this happens
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu_response, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn send_d_location_update_reject(
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        location_update_type: LocationUpdateType,
        reject_cause: u8,
    ) {
        let pdu_response = DLocationUpdateReject {
            location_update_type: location_update_type as u8,
            reject_cause,
            cipher_control: false,
            ciphering_parameters: None,
            address_extension: None,
            cell_type_control: None,
            proprietary: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(32);
        pdu_response.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> {} sdu {}", pdu_response, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn rx_u_authentication(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_authentication");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UAuthentication::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UAuthentication: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        let issi = prim.received_address.ssi;

        match pdu {
            UAuthentication::Response {
                res1,
                mutual_authentication,
                rand2,
            } => {
                let Some(pending) = self.pending_auth.get(&issi).copied() else {
                    tracing::warn!("Received U-AUTHENTICATION response for ISSI {} with no pending challenge", issi);
                    self.pending_location_update.remove(&issi);
                    Self::send_d_authentication(
                        queue,
                        message.dltime,
                        issi,
                        prim.handle,
                        DAuthentication::Reject {
                            reject_reason: AUTH_REJECT_NOT_SUPPORTED,
                        },
                    );
                    return;
                };

                if mutual_authentication {
                    tracing::warn!(
                        "ISSI {} requested mutual authentication (RAND2 present: {}), but TA22 is not implemented",
                        issi,
                        rand2.is_some()
                    );
                    self.pending_auth.remove(&issi);
                    self.pending_location_update.remove(&issi);
                    Self::send_d_authentication(
                        queue,
                        message.dltime,
                        issi,
                        prim.handle,
                        DAuthentication::Reject {
                            reject_reason: AUTH_REJECT_NOT_SUPPORTED,
                        },
                    );
                    return;
                }

                if res1 != pending.expected_res1 {
                    tracing::warn!(
                        "ISSI {} failed TA12 verification: provided RES1=0x{:08X}, expected=0x{:08X} (RAND1={}, RS={})",
                        issi,
                        res1,
                        pending.expected_res1,
                        Self::k_hex(&pending.rand1),
                        Self::k_hex(&pending.rs)
                    );

                    self.pending_auth.remove(&issi);
                    self.pending_location_update.remove(&issi);
                    self.authenticated_ms.remove(&issi);

                    Self::send_d_authentication(
                        queue,
                        message.dltime,
                        issi,
                        prim.handle,
                        DAuthentication::Result {
                            r1: false,
                            mutual_authentication: false,
                            res2: None,
                        },
                    );
                    return;
                }

                tracing::info!("ISSI {} passed TA11/TA12 verification (RES1=0x{:08X})", issi, res1);

                self.pending_auth.remove(&issi);

                // Per ETSI EN 300 392-7 §A.7.1.3: after sending D-AUTHENTICATION RESULT
                // with r1=accepted, the SwMI shall immediately continue with the procedure
                // for which authentication was carried out (i.e. location updating).
                // Enqueue D-AUTH RESULT first so it is sent before D-LU-ACCEPT.
                Self::send_d_authentication(
                    queue,
                    message.dltime,
                    issi,
                    prim.handle,
                    DAuthentication::Result {
                        r1: true,
                        mutual_authentication: false,
                        res2: None,
                    },
                );

                // Immediately complete the location update using the saved context.
                // This covers radios that do not re-send U-LU-DEMAND and do not send
                // U-AUTH RESULT after receiving D-AUTH RESULT (the majority of firmware).
                if let Some(pending_lu) = self.pending_location_update.remove(&issi) {
                    tracing::info!(
                        "ISSI {} completing location update immediately after auth success (per ETSI §A.7.1.3)",
                        issi
                    );
                    self.complete_location_update(
                        queue,
                        message.dltime,
                        issi,
                        pending_lu.handle,
                        pending_lu.location_update_type,
                        pending_lu.group_identity_uplink,
                    );
                } else {
                    tracing::warn!(
                        "ISSI {} auth succeeded but no pending location update context found; \
                         D-LU-ACCEPT deferred until next U-LU-DEMAND or U-AUTH RESULT",
                        issi
                    );
                }
            }
            UAuthentication::Reject { reject_reason } => {
                tracing::warn!(
                    "ISSI {} rejected authentication challenge (reason={}), clearing pending state",
                    issi,
                    reject_reason
                );
                self.pending_auth.remove(&issi);
                self.pending_location_update.remove(&issi);
            }
            UAuthentication::Demand { .. } => {
                tracing::warn!(
                    "ISSI {} sent unsupported U-AUTHENTICATION subtype for current BS flow; replying with reject",
                    issi
                );
                Self::send_d_authentication(
                    queue,
                    message.dltime,
                    issi,
                    prim.handle,
                    DAuthentication::Reject {
                        reject_reason: AUTH_REJECT_NOT_SUPPORTED,
                    },
                );
            }
            UAuthentication::Result {
                r2,
                mutual_authentication,
                res1,
            } => {
                // For SwMI-initiated non-mutual authentication, no further action is required here.
                // Some radios still send U-AUTHENTICATION RESULT as a terminal indication.
                if !mutual_authentication {
                    tracing::info!(
                        "ISSI {} sent U-AUTHENTICATION RESULT (r2={}, non-mutual); treating as terminal, no reply",
                        issi,
                        r2
                    );

                    // If we still have a pending location update context, complete it now.
                    if let Some(pending_lu) = self.pending_location_update.remove(&issi) {
                        tracing::info!(
                            "ISSI {} completing deferred location update after authentication result",
                            issi
                        );
                        self.complete_location_update(
                            queue,
                            message.dltime,
                            issi,
                            pending_lu.handle,
                            pending_lu.location_update_type,
                            pending_lu.group_identity_uplink,
                        );
                    }
                    return;
                }

                tracing::warn!(
                    "ISSI {} sent mutual U-AUTHENTICATION RESULT (r2={}, res1_present={}); mutual flow unsupported",
                    issi,
                    r2,
                    res1.is_some()
                );
                // Drain any pending location update defensively - in the normal fixed flow this
                // will already be empty (completed at RES1 verification time), but guard against
                // edge cases where the radio sends U-AUTH RESULT before we processed the challenge.
                if let Some(pending_lu) = self.pending_location_update.remove(&issi) {
                    tracing::info!(
                        "ISSI {} completing deferred location update after mutual auth result (fallback)",
                        issi
                    );
                    self.complete_location_update(
                        queue,
                        message.dltime,
                        issi,
                        pending_lu.handle,
                        pending_lu.location_update_type,
                        pending_lu.group_identity_uplink,
                    );
                }
                // Do not send reject here to avoid forcing MS into auth-failure loop.
            }
        }
    }

    fn rx_u_itsi_detach(&mut self, _queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_itsi_detach");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UItsiDetach::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UItsiDetach: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request, print unsupported stuff
        if !Self::feature_check_u_itsi_detach(&pdu) {
            tracing::error!("Unsupported critical features in UItsiDetach");
            return;
        }

        let ssi = prim.received_address.ssi;
        self.pending_auth.remove(&ssi);
        self.pending_location_update.remove(&ssi);
        self.authenticated_ms.remove(&ssi);
        let detached_client = self.client_mgr.remove_client(ssi);
        if let Some(client) = detached_client {
            if !client.groups.is_empty() {
                let groups: Vec<u32> = client.groups.iter().copied().collect();
                self.emit_subscriber_update(_queue, message.dltime, ssi, groups, BrewSubscriberAction::Deaffiliate);
            }
            self.emit_subscriber_update(_queue, message.dltime, ssi, Vec::new(), BrewSubscriberAction::Deregister);
        } else {
            tracing::warn!("Received UItsiDetach for unknown client with SSI: {}", ssi);
            // return;
        };
    }

    fn rx_u_location_update_demand(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_location_update_demand");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match ULocationUpdateDemand::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing ULocationUpdateDemand: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request, print unsupported stuff
        if !self.feature_check_u_location_update_demand(&pdu) {
            tracing::error!("Unsupported critical features in ULocationUpdateDemand");
            return;
        }

        let issi = prim.received_address.ssi;
        let handle = prim.handle;
        if !self.handle_location_update_auth(queue, message.dltime, issi, handle, &pdu) {
            return;
        }

        let location_update_type = pdu.location_update_type;
        let group_identity_uplink = pdu
            .group_identity_location_demand
            .and_then(|group_identity_location_demand| group_identity_location_demand.group_identity_uplink);

        self.complete_location_update(
            queue,
            message.dltime,
            issi,
            handle,
            location_update_type,
            group_identity_uplink,
        );
    }

    fn complete_location_update(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        handle: u32,
        location_update_type: LocationUpdateType,
        group_identity_uplink: Option<Vec<GroupIdentityUplink>>,
    ) {
        // This location update transaction is now completed.
        self.pending_location_update.remove(&issi);
        self.pending_auth.remove(&issi);
        self.authenticated_ms.remove(&issi);

        // Handle Energy Saving Mode request
        // TODO FIXME this does not yet seem to be functional, and prevents the MS from remaining
        // properly registered.
        // let esi = if let Some(esm) = pdu.energy_saving_mode {
        //     if esm != EnergySavingMode::StayAlive {
        //         unimplemented_log!("Got req for EnergySavingMode {}, overriding with {}", esm, EnergySavingMode::StayAlive);
        //     }
        //     Some(EnergySavingInformation {
        //         energy_saving_mode: EnergySavingMode::StayAlive,
        //         frame_number: None,
        //         multiframe_number: None,
        //     })
        // } else {
        //     None
        // };
        let esi = None;

        // Try to register the client
        let is_new = !self.client_mgr.client_is_known(issi);
        if is_new {
            match self.client_mgr.try_register_client(issi, true) {
                Ok(_) => {
                    self.emit_subscriber_update(queue, dltime, issi, Vec::new(), BrewSubscriberAction::Register);
                }
                Err(e) => {
                    tracing::warn!("Failed registering roaming MS {}: {:?}", issi, e);
                    // unimplemented_log!("Handle failed registration of roaming MS");
                    return;
                }
            }
        } else if let Err(e) = self.client_mgr.set_client_state(issi, MmClientState::Attached) {
            tracing::warn!("Failed updating roaming MS {}: {:?}", issi, e);
            return;
        }

        // Process optional GroupIdentityLocationDemand field
        let gila = if let Some(giu) = group_identity_uplink {
            let accepted_groups = Some(self.try_attach_detach_groups(queue, dltime, issi, &giu));
            let gila = GroupIdentityLocationAccept {
                group_identity_accept_reject: 0, // Accept
                group_identity_downlink: accepted_groups,
            };
            Some(gila)
        } else {
            // No GroupIdentityLocationAccept element present
            None
        };

        // Build D-LOCATION UPDATE ACCEPT pdu
        let pdu_response = DLocationUpdateAccept {
            location_update_accept_type: location_update_type, // Practically identical besides minor migration-related difference
            ssi: Some(issi as u64),
            address_extension: None,
            subscriber_class: None,
            energy_saving_information: esi,
            scch_information_and_distribution_on_18th_frame: None,
            new_registered_area: None,
            security_downlink: None,
            group_identity_location_accept: gila,
            default_group_attachment_lifetime: None,
            authentication_downlink: None,
            group_identity_security_related_information: None,
            cell_type_control: None,
            proprietary: None,
        };

        Self::send_d_location_update_accept(queue, dltime, issi, handle, pdu_response);

        // If this is an unknown returning radio (not ITSI attach), force it to
        // re-register with full group report via D-LOCATION UPDATE COMMAND
        if is_new && location_update_type != LocationUpdateType::ItsiAttach {
            tracing::info!("Sending D-LOCATION UPDATE COMMAND to returning MS {} to request group report", issi);
            Self::send_d_location_update_command(queue, dltime, issi, handle);
        }
    }

    fn rx_u_mm_status(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_mm_status");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let pdu = match UMmStatus::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UItsiDetach: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        let handled = false; // Set to true for properly handled U-MM STATUS messages
        match pdu.status_uplink {
            StatusUplink::ChangeOfEnergySavingModeRequest
            | StatusUplink::ChangeOfEnergySavingModeResponse
            | StatusUplink::DualWatchModeRequest
            | StatusUplink::TerminatingDualWatchModeRequest
            | StatusUplink::ChangeOfDualWatchModeResponse
            | StatusUplink::StartOfDirectModeOperation
            | StatusUplink::MsFrequencyBandsInformation
            | StatusUplink::RequestToStartDmGatewayOperation
            | StatusUplink::RequestToContinuedmGatewayOperation
            | StatusUplink::RequestToStopDmGatewayOperation
            | StatusUplink::RequestToAddDmMsAddresses
            | StatusUplink::RequestToRemoveDmMsAddresses
            | StatusUplink::RequestToReplaceDmMsAddresses
            | StatusUplink::AcceptanceToRemovalOfDmMsAddresses
            | StatusUplink::AcceptanceToChangeRegistrationLabel
            | StatusUplink::AcceptanceToStopDmGatewayOperation => {
                unimplemented_log!("{:?}", pdu.status_uplink)
            }
            _ => {
                assert_warn!(false, "Unrecognized UMmStatus type {:?}", pdu.status_uplink);
            }
        }

        if !handled {
            // A fairly untested, best-effort way of sending a PDU not supported error back
            // Note that an MS is not required to really do anything with this message.
            let (sapmsg, debug_str) = make_ul_mm_pdu_function_not_supported(
                prim.handle,
                MmPduTypeUl::UMmStatus,
                Some((6, pdu.status_uplink.into())),
                prim.received_address.ssi,
                message.dltime,
            );
            tracing::debug!("-> {}", debug_str);
            queue.push_back(sapmsg);
        }
    }

    fn rx_u_attach_detach_group_identity(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        tracing::trace!("rx_u_attach_detach_group_identity");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let issi = prim.received_address.ssi;

        let pdu = match UAttachDetachGroupIdentity::from_bitbuf(&mut prim.sdu) {
            Ok(pdu) => {
                tracing::debug!("<- {:?}", pdu);
                pdu
            }
            Err(e) => {
                tracing::warn!("Failed parsing UAttachDetachGroupIdentity: {:?} {}", e, prim.sdu.dump_bin());
                return;
            }
        };

        // Check if we can satisfy this request, print unsupported stuff
        if !Self::feature_check_u_attach_detach_group_identity(&pdu) {
            tracing::error!("Unsupported features in UAttachDetachGroupIdentity");
            return;
        }

        // If group_identity_attach_detach_mode == 1, we first detach all groups
        if pdu.group_identity_attach_detach_mode == true {
            if !self.client_mgr.client_is_known(issi) {
                // Client unknown (e.g. never registered via location update).
                // Re-register so group attachment can proceed.
                match self.client_mgr.try_register_client(issi, true) {
                    Ok(_) => {
                        self.emit_subscriber_update(queue, message.dltime, issi, Vec::new(), BrewSubscriberAction::Register);
                    }
                    Err(e) => {
                        tracing::warn!("Failed re-registering MS {} on group attach: {:?}", issi, e);
                        return;
                    }
                }
            } else {
                // Client is known — detach all existing groups first
                let prior_groups: Vec<u32> = self
                    .client_mgr
                    .get_client_by_issi(issi)
                    .map(|client| client.groups.iter().copied().collect())
                    .unwrap_or_default();
                match self.client_mgr.client_detach_all_groups(issi) {
                    Ok(_) => {
                        if !prior_groups.is_empty() {
                            self.emit_subscriber_update(queue, message.dltime, issi, prior_groups, BrewSubscriberAction::Deaffiliate);
                        }
                    }
                    Err(e) => {
                        tracing::warn!("Failed detaching all groups for MS {}: {:?}", issi, e);
                        return;
                    }
                }
            }
        }

        // Try to attach to requested groups, and retrieve list of accepted GroupIdentityDownlink elements
        // We can unwrap since we did compat check earlier
        let accepted_gid = self.try_attach_detach_groups(queue, message.dltime, issi, &pdu.group_identity_uplink.unwrap());

        // Build reply PDU
        let pdu_response = DAttachDetachGroupIdentityAcknowledgement {
            group_identity_accept_reject: 0, // Accept
            reserved: false,                 // TODO FIXME Guessed proper value of reserved field
            proprietary: None,
            group_identity_downlink: Some(accepted_gid),
            group_identity_security_related_information: None,
        };

        // Write to PDU
        let mut sdu = BitBuffer::new_autoexpand(32);
        pdu_response.to_bitbuf(&mut sdu).unwrap(); // We want to know when this happens
        sdu.seek(0);
        tracing::debug!("-> {:?} sdu {}", pdu_response, sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime: message.dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle: prim.handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn rx_lmm_mle_unitdata_ind(&mut self, queue: &mut MessageQueue, mut message: SapMsg) {
        // unimplemented_log!("rx_lmm_mle_unitdata_ind for MM component");
        let SapMsgInner::LmmMleUnitdataInd(prim) = &mut message.msg else {
            panic!()
        };

        let Some(bits) = prim.sdu.peek_bits(4) else {
            tracing::warn!("insufficient bits: {}", prim.sdu.dump_bin());
            return;
        };

        let Ok(pdu_type) = MmPduTypeUl::try_from(bits) else {
            tracing::warn!("invalid pdu type: {} in {}", bits, prim.sdu.dump_bin());
            return;
        };

        match pdu_type {
            MmPduTypeUl::UAuthentication => self.rx_u_authentication(queue, message),
            MmPduTypeUl::UItsiDetach => self.rx_u_itsi_detach(queue, message),
            MmPduTypeUl::ULocationUpdateDemand => self.rx_u_location_update_demand(queue, message),
            MmPduTypeUl::UMmStatus => self.rx_u_mm_status(queue, message),
            MmPduTypeUl::UCkChangeResult => unimplemented_log!("UCkChangeResult"),
            MmPduTypeUl::UOtar => unimplemented_log!("UOtar"),
            MmPduTypeUl::UInformationProvide => unimplemented_log!("UInformationProvide"),
            MmPduTypeUl::UAttachDetachGroupIdentity => self.rx_u_attach_detach_group_identity(queue, message),
            MmPduTypeUl::UAttachDetachGroupIdentityAcknowledgement => unimplemented_log!("UAttachDetachGroupIdentityAcknowledgement"),
            MmPduTypeUl::UTeiProvide => unimplemented_log!("UTeiProvide"),
            MmPduTypeUl::UDisableStatus => unimplemented_log!("UDisableStatus"),
            MmPduTypeUl::MmPduFunctionNotSupported => unimplemented_log!("MmPduFunctionNotSupported"),
        };
    }

    fn try_attach_detach_groups(
        &mut self,
        queue: &mut MessageQueue,
        dltime: TdmaTime,
        issi: u32,
        giu_vec: &Vec<GroupIdentityUplink>,
    ) -> Vec<GroupIdentityDownlink> {
        let mut accepted_groups = Vec::new();
        let mut aff_groups = Vec::new();
        let mut deaff_groups = Vec::new();

        for giu in giu_vec.iter() {
            if giu.gssi.is_none() || giu.vgssi.is_some() || giu.address_extension.is_some() {
                unimplemented_log!("Only support GroupIdentityUplink with address_type 0");
                continue;
            }

            let gssi = giu.gssi.unwrap(); // can't fail
            let is_detach = giu.group_identity_detachment_uplink.is_some();

            if is_detach {
                match self.client_mgr.client_group_attach(issi, gssi, false) {
                    Ok(changed) => {
                        if changed {
                            deaff_groups.push(gssi);
                        }
                        let gid = GroupIdentityDownlink {
                            group_identity_attachment: None,
                            group_identity_detachment_uplink: giu.group_identity_detachment_uplink,
                            gssi: Some(gssi),
                            address_extension: None,
                            vgssi: None,
                        };
                        accepted_groups.push(gid);
                    }
                    Err(e) => {
                        tracing::warn!("Failed detaching MS {} from group {}: {:?}", issi, gssi, e);
                    }
                }
            } else {
                match self.client_mgr.client_group_attach(issi, gssi, true) {
                    Ok(changed) => {
                        if changed {
                            aff_groups.push(gssi);
                        }
                        // We have added the client to this group. Add an entry to the downlink response
                        let gid = GroupIdentityDownlink {
                            group_identity_attachment: Some(GroupIdentityAttachment {
                                group_identity_attachment_lifetime: 1, // re-attach after ITSI attach (ETSI default per clause 16.4.2)
                                class_of_usage: giu.class_of_usage.unwrap_or(0),
                            }),
                            group_identity_detachment_uplink: None,
                            gssi: Some(gssi),
                            address_extension: None,
                            vgssi: None,
                        };
                        accepted_groups.push(gid);
                    }
                    Err(e) => {
                        tracing::warn!("Failed attaching MS {} to group {}: {:?}", issi, gssi, e);
                    }
                }
            }
        }

        if !aff_groups.is_empty() {
            self.emit_subscriber_update(queue, dltime, issi, aff_groups, BrewSubscriberAction::Affiliate);
        }
        if !deaff_groups.is_empty() {
            self.emit_subscriber_update(queue, dltime, issi, deaff_groups, BrewSubscriberAction::Deaffiliate);
        }

        accepted_groups
    }

    /// Sends a D-LOCATION UPDATE COMMAND to force the radio to re-register
    /// with full group identity report
    fn send_d_location_update_command(queue: &mut MessageQueue, dltime: TdmaTime, issi: u32, handle: u32) {
        let pdu = DLocationUpdateCommand {
            group_identity_report: true,
            cipher_control: false,
            ciphering_parameters: None,
            address_extension: None,
            cell_type_control: None,
            proprietary: None,
        };

        let mut sdu = BitBuffer::new_autoexpand(16);
        pdu.to_bitbuf(&mut sdu).unwrap();
        sdu.seek(0);
        tracing::debug!("-> DLocationUpdateCommand sdu {}", sdu.dump_bin());

        let addr = TetraAddress {
            encrypted: false,
            ssi_type: SsiType::Ssi,
            ssi: issi,
        };
        let msg = SapMsg {
            sap: Sap::LmmSap,
            src: TetraEntity::Mm,
            dest: TetraEntity::Mle,
            dltime,
            msg: SapMsgInner::LmmMleUnitdataReq(LmmMleUnitdataReq {
                sdu,
                handle,
                address: addr,
                layer2service: 0,
                stealing_permission: false,
                stealing_repeats_flag: false,
                encryption_flag: false,
                is_null_pdu: false,
                tx_reporter: None,
            }),
        };
        queue.push_back(msg);
    }

    fn feature_check_u_itsi_detach(pdu: &UItsiDetach) -> bool {
        let supported = true;
        if pdu.address_extension.is_some() {
            unimplemented_log!("Unsupported address_extension present");
        };
        if pdu.proprietary.is_some() {
            unimplemented_log!("Unsupported proprietary present");
        };
        supported
    }

    fn feature_check_u_location_update_demand(&self, pdu: &ULocationUpdateDemand) -> bool {
        let mut supported = true;
        if pdu.location_update_type == LocationUpdateType::MigratingLocationUpdating
            || pdu.location_update_type == LocationUpdateType::DisabledMsUpdating
        {
            unimplemented_log!("Unsupported {}", pdu.location_update_type);
            supported = false;
        }
        if pdu.request_to_append_la == true {
            unimplemented_log!("Unsupported request_to_append_la == true");
            supported = false;
        }
        if pdu.cipher_control == true {
            unimplemented_log!("Unsupported cipher_control == true");
            supported = false;
        }
        if pdu.ciphering_parameters.is_some() {
            unimplemented_log!("Unsupported ciphering_parameters present");
            supported = false;
        }
        if pdu.class_of_ms.is_some() {
            unimplemented_log!("Unsupported class_of_ms present");
        }
        if pdu.energy_saving_mode.is_some() {
            unimplemented_log!("Unsupported energy_saving_mode present");
        }
        if pdu.la_information.is_some() {
            unimplemented_log!("Unsupported la_information present");
        }
        if pdu.ssi.is_some() {
            unimplemented_log!("Unsupported ssi present");
        }
        if pdu.address_extension.is_some() {
            unimplemented_log!("Unsupported address_extension present");
        }
        if pdu.group_report_response.is_some() {
            unimplemented_log!("Unsupported group_report_response present");
        }
        if pdu.authentication_uplink.is_some() {
            tracing::warn!(
                "Legacy authentication_uplink type3 field is ignored; D/U-AUTHENTICATION PDU flow is used"
            );
        }
        if pdu.extended_capabilities.is_some() {
            unimplemented_log!("Unsupported extended_capabilities present");
        }
        if pdu.proprietary.is_some() {
            unimplemented_log!("Unsupported proprietary present");
        }

        supported
    }

    /// Check for unsupported features in U-ATTACH/DETACH GROUP IDENTITY
    /// Returns false if a critical feature is missing
    fn feature_check_u_attach_detach_group_identity(pdu: &UAttachDetachGroupIdentity) -> bool {
        let mut supported = true;
        if pdu.group_identity_report == true {
            unimplemented_log!("Unsupported group_identity_report == true");
        }
        if pdu.group_identity_uplink.is_none() {
            unimplemented_log!("Missing group_identity_uplink");
            supported = false;
        }
        if pdu.group_report_response.is_some() {
            unimplemented_log!("Unsupported group_report_response present");
        }
        if pdu.proprietary.is_some() {
            unimplemented_log!("Unsupported proprietary present");
        }

        supported
    }
}

impl TetraEntityTrait for MmBs {
    fn entity(&self) -> TetraEntity {
        TetraEntity::Mm
    }

    fn set_config(&mut self, config: SharedConfig) {
        self.config = config;
        self.pending_auth.clear();
        self.pending_location_update.clear();
        self.authenticated_ms.clear();
        self.log_ms_auth_config();
    }

    fn rx_prim(&mut self, queue: &mut MessageQueue, message: SapMsg) {
        tracing::debug!("rx_prim: {:?}", message);
        // tracing::debug!(ts=%message.dltime, "rx_prim: {:?}", message);

        // There is only one SAP for MM
        assert!(message.sap == Sap::LmmSap);

        match message.msg {
            SapMsgInner::LmmMleUnitdataInd(_) => {
                self.rx_lmm_mle_unitdata_ind(queue, message);
            }
            _ => {
                panic!();
            }
        }
    }
}
