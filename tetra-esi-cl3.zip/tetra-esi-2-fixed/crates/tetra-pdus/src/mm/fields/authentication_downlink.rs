use tetra_core::{BitBuffer, pdu_parse_error::PduParseErr};

fn read_80_bits(buffer: &mut BitBuffer, field: &'static str) -> Result<[u8; 10], PduParseErr> {
    let mut out = [0u8; 10];
    for b in &mut out {
        *b = buffer.read_field(8, field)? as u8;
    }
    Ok(out)
}

fn write_80_bits(buffer: &mut BitBuffer, bytes: &[u8; 10]) {
    for b in bytes {
        buffer.write_bits(*b as u64, 8);
    }
}

fn read_120_bits(buffer: &mut BitBuffer, field: &'static str) -> Result<[u8; 15], PduParseErr> {
    let mut out = [0u8; 15];
    for b in &mut out {
        *b = buffer.read_field(8, field)? as u8;
    }
    Ok(out)
}

fn write_120_bits(buffer: &mut BitBuffer, bytes: &[u8; 15]) {
    for b in bytes {
        buffer.write_bits(*b as u64, 8);
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AuthenticationDownlink {
    pub authentication_result: bool,
    pub tei_request_flag: bool,
    pub ck_provision_information: Option<CkProvisionInformation>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CkProvisionInformation {
    pub sck_information: Option<SckInformation>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SckInformation {
    pub session_key: bool,
    pub random_seed_for_otar: Option<[u8; 10]>,
    pub gsko_vn: Option<u16>,
    pub sck_number: u8,
    pub sck_version_number: u16,
    pub sealed_sck: [u8; 15],
    pub future_key: Option<SckFutureKey>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SckFutureKey {
    pub sck_number: u8,
    pub sck_version_number: u16,
    pub sealed_sck: [u8; 15],
}

impl AuthenticationDownlink {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let authentication_result = buffer.read_field(1, "authentication_result")? != 0;
        let tei_request_flag = buffer.read_field(1, "tei_request_flag")? != 0;
        let ck_provision_flag = buffer.read_field(1, "ck_provision_flag")? != 0;

        let ck_provision_information = if ck_provision_flag {
            let sck_provision_flag = buffer.read_field(1, "sck_provision_flag")? != 0;
            let sck_information = if sck_provision_flag {
                Some(SckInformation::from_bitbuf(buffer)?)
            } else {
                None
            };

            let cck_provision_flag = buffer.read_field(1, "cck_provision_flag")? != 0;
            if cck_provision_flag {
                return Err(PduParseErr::NotImplemented {
                    field: Some("authentication_downlink.cck_provision_information"),
                });
            }

            Some(CkProvisionInformation { sck_information })
        } else {
            None
        };

        Ok(Self {
            authentication_result,
            tei_request_flag,
            ck_provision_information,
        })
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        buffer.write_bits(self.authentication_result as u64, 1);
        buffer.write_bits(self.tei_request_flag as u64, 1);

        let ck_provision_flag = self.ck_provision_information.is_some();
        buffer.write_bits(ck_provision_flag as u64, 1);

        if let Some(ck_provision_information) = &self.ck_provision_information {
            let sck_provision_flag = ck_provision_information.sck_information.is_some();
            buffer.write_bits(sck_provision_flag as u64, 1);
            if let Some(sck_information) = &ck_provision_information.sck_information {
                sck_information.to_bitbuf(buffer)?;
            }

            buffer.write_bits(0, 1);
        }

        Ok(())
    }
}

impl SckInformation {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let session_key = buffer.read_field(1, "session_key")? != 0;
        let random_seed_for_otar = if !session_key {
            Some(read_80_bits(buffer, "random_seed_for_otar")?)
        } else {
            None
        };
        let gsko_vn = if session_key {
            Some(buffer.read_field(16, "gsko_vn")? as u16)
        } else {
            None
        };

        let sck_number = buffer.read_field(5, "sck_number")? as u8;
        let sck_version_number = buffer.read_field(16, "sck_version_number")? as u16;
        let sealed_sck = read_120_bits(buffer, "sealed_sck")?;
        let future_key_flag = buffer.read_field(1, "future_key_flag")? != 0;
        let future_key = if future_key_flag {
            Some(SckFutureKey {
                sck_number: buffer.read_field(5, "future_sck_number")? as u8,
                sck_version_number: buffer.read_field(16, "future_sck_version_number")? as u16,
                sealed_sck: read_120_bits(buffer, "future_sealed_sck")?,
            })
        } else {
            None
        };

        Ok(Self {
            session_key,
            random_seed_for_otar,
            gsko_vn,
            sck_number,
            sck_version_number,
            sealed_sck,
            future_key,
        })
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        if !self.session_key && self.random_seed_for_otar.is_none() {
            return Err(PduParseErr::Inconsistency {
                field: "random_seed_for_otar",
                reason: "missing while session_key=false",
            });
        }
        if self.session_key && self.gsko_vn.is_none() {
            return Err(PduParseErr::Inconsistency {
                field: "gsko_vn",
                reason: "missing while session_key=true",
            });
        }
        if !self.session_key && self.gsko_vn.is_some() {
            return Err(PduParseErr::Inconsistency {
                field: "gsko_vn",
                reason: "present while session_key=false",
            });
        }
        if self.session_key && self.random_seed_for_otar.is_some() {
            return Err(PduParseErr::Inconsistency {
                field: "random_seed_for_otar",
                reason: "present while session_key=true",
            });
        }

        buffer.write_bits(self.session_key as u64, 1);
        if let Some(random_seed_for_otar) = self.random_seed_for_otar {
            write_80_bits(buffer, &random_seed_for_otar);
        }
        if let Some(gsko_vn) = self.gsko_vn {
            buffer.write_bits(gsko_vn as u64, 16);
        }

        buffer.write_bits(self.sck_number as u64, 5);
        buffer.write_bits(self.sck_version_number as u64, 16);
        write_120_bits(buffer, &self.sealed_sck);

        let future_key_flag = self.future_key.is_some();
        buffer.write_bits(future_key_flag as u64, 1);
        if let Some(future_key) = &self.future_key {
            buffer.write_bits(future_key.sck_number as u64, 5);
            buffer.write_bits(future_key.sck_version_number as u64, 16);
            write_120_bits(buffer, &future_key.sealed_sck);
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_authentication_downlink_with_sck_info() {
        let pdu = AuthenticationDownlink {
            authentication_result: true,
            tei_request_flag: false,
            ck_provision_information: Some(CkProvisionInformation {
                sck_information: Some(SckInformation {
                    session_key: false,
                    random_seed_for_otar: Some([0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19]),
                    gsko_vn: None,
                    sck_number: 30,
                    sck_version_number: 1,
                    sealed_sck: [
                        0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E,
                    ],
                    future_key: None,
                }),
            }),
        };

        let mut buf = BitBuffer::new_autoexpand(256);
        pdu.to_bitbuf(&mut buf).unwrap();
        buf.seek(0);

        let parsed = AuthenticationDownlink::from_bitbuf(&mut buf).unwrap();
        assert_eq!(parsed, pdu);
    }
}
