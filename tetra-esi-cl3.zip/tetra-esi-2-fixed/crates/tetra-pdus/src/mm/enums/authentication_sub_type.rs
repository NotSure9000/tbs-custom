/// ETSI EN 300 392-7 A.8.6 Authentication sub-type
/// Bits: 2
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum AuthenticationSubType {
    Demand = 0,
    Response = 1,
    Result = 2,
    Reject = 3,
}

impl std::convert::TryFrom<u64> for AuthenticationSubType {
    type Error = ();

    fn try_from(x: u64) -> Result<Self, Self::Error> {
        match x {
            0 => Ok(AuthenticationSubType::Demand),
            1 => Ok(AuthenticationSubType::Response),
            2 => Ok(AuthenticationSubType::Result),
            3 => Ok(AuthenticationSubType::Reject),
            _ => Err(()),
        }
    }
}

impl AuthenticationSubType {
    pub fn into_raw(self) -> u64 {
        match self {
            AuthenticationSubType::Demand => 0,
            AuthenticationSubType::Response => 1,
            AuthenticationSubType::Result => 2,
            AuthenticationSubType::Reject => 3,
        }
    }
}

impl From<AuthenticationSubType> for u64 {
    fn from(e: AuthenticationSubType) -> Self {
        e.into_raw()
    }
}

impl core::fmt::Display for AuthenticationSubType {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            AuthenticationSubType::Demand => write!(f, "Demand"),
            AuthenticationSubType::Response => write!(f, "Response"),
            AuthenticationSubType::Result => write!(f, "Result"),
            AuthenticationSubType::Reject => write!(f, "Reject"),
        }
    }
}
