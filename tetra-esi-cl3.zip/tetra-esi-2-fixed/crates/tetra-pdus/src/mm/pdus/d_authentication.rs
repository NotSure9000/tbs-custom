use core::fmt;

use tetra_core::expect_pdu_type;
use tetra_core::typed_pdu_fields::delimiters;
use tetra_core::{BitBuffer, pdu_parse_error::PduParseErr};

use crate::mm::enums::authentication_sub_type::AuthenticationSubType;
use crate::mm::enums::mm_pdu_type_dl::MmPduTypeDl;

fn read_80_bits(buffer: &mut BitBuffer, field: &'static str) -> Result<[u8; 10], PduParseErr> {
    let mut out = [0u8; 10];
    for b in out.iter_mut() {
        *b = buffer.read_field(8, field)? as u8;
    }
    Ok(out)
}

fn write_80_bits(buffer: &mut BitBuffer, bytes: &[u8; 10]) {
    for b in bytes {
        buffer.write_bits(*b as u64, 8);
    }
}

/// Representation of the D-AUTHENTICATION PDU family (ETSI EN 300 392-7, A.1.1..A.1.4).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DAuthentication {
    Demand {
        rand1: [u8; 10],
        rs: [u8; 10],
    },
    Reject {
        reject_reason: u8,
    },
    Response {
        rs: [u8; 10],
        res2: u32,
        mutual_authentication: bool,
        rand1: Option<[u8; 10]>,
    },
    Result {
        r1: bool,
        mutual_authentication: bool,
        res2: Option<u32>,
    },
}

impl DAuthentication {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let pdu_type = buffer.read_field(4, "pdu_type")?;
        expect_pdu_type!(pdu_type, MmPduTypeDl::DAuthentication)?;

        let sub_type_raw = buffer.read_field(2, "authentication_sub_type")?;
        let sub_type = AuthenticationSubType::try_from(sub_type_raw).map_err(|_| PduParseErr::InvalidValue {
            field: "authentication_sub_type",
            value: sub_type_raw,
        })?;

        let pdu = match sub_type {
            AuthenticationSubType::Demand => {
                let rand1 = read_80_bits(buffer, "rand1")?;
                let rs = read_80_bits(buffer, "rs")?;
                DAuthentication::Demand { rand1, rs }
            }
            AuthenticationSubType::Reject => {
                let reject_reason = buffer.read_field(3, "authentication_reject_reason")? as u8;
                DAuthentication::Reject { reject_reason }
            }
            AuthenticationSubType::Response => {
                let rs = read_80_bits(buffer, "rs")?;
                let res2 = buffer.read_field(32, "res2")? as u32;
                let mutual_authentication = buffer.read_field(1, "mutual_authentication")? != 0;
                let rand1 = if mutual_authentication {
                    Some(read_80_bits(buffer, "rand1")?)
                } else {
                    None
                };
                DAuthentication::Response {
                    rs,
                    res2,
                    mutual_authentication,
                    rand1,
                }
            }
            AuthenticationSubType::Result => {
                let r1 = buffer.read_field(1, "r1")? != 0;
                let mutual_authentication = buffer.read_field(1, "mutual_authentication")? != 0;
                let res2 = if mutual_authentication {
                    Some(buffer.read_field(32, "res2")? as u32)
                } else {
                    None
                };
                DAuthentication::Result {
                    r1,
                    mutual_authentication,
                    res2,
                }
            }
        };

        // Compatibility: earlier implementations omitted the trailing o-bit.
        // If there are bits remaining, consume o-bit and any optional trailing data.
        if buffer.get_len_remaining() > 0 {
            let obit = delimiters::read_obit(buffer)?;
            if obit {
                let trailing = buffer.get_len_remaining();
                tracing::trace!(
                    "D-AUTHENTICATION has optional extension with {} trailing bit(s), ignoring",
                    trailing
                );
                buffer.seek_rel(trailing as isize);
            } else {
                let trailing = buffer.get_len_remaining();
                if trailing > 0 {
                    tracing::trace!(
                        "D-AUTHENTICATION has {} trailing bit(s) after o-bit, ignoring",
                        trailing
                    );
                    buffer.seek_rel(trailing as isize);
                }
            }
        }

        Ok(pdu)
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        buffer.write_bits(MmPduTypeDl::DAuthentication.into_raw(), 4);

        match self {
            DAuthentication::Demand { rand1, rs } => {
                buffer.write_bits(AuthenticationSubType::Demand.into_raw(), 2);
                write_80_bits(buffer, rand1);
                write_80_bits(buffer, rs);
                delimiters::write_obit(buffer, 0);
            }
            DAuthentication::Reject { reject_reason } => {
                buffer.write_bits(AuthenticationSubType::Reject.into_raw(), 2);
                buffer.write_bits(*reject_reason as u64, 3);
                delimiters::write_obit(buffer, 0);
            }
            DAuthentication::Response {
                rs,
                res2,
                mutual_authentication,
                rand1,
            } => {
                if *mutual_authentication && rand1.is_none() {
                    return Err(PduParseErr::Inconsistency {
                        field: "rand1",
                        reason: "missing while mutual_authentication=true",
                    });
                }
                if !*mutual_authentication && rand1.is_some() {
                    return Err(PduParseErr::Inconsistency {
                        field: "rand1",
                        reason: "present while mutual_authentication=false",
                    });
                }

                buffer.write_bits(AuthenticationSubType::Response.into_raw(), 2);
                write_80_bits(buffer, rs);
                buffer.write_bits(*res2 as u64, 32);
                buffer.write_bits(*mutual_authentication as u64, 1);
                if let Some(rand1) = rand1 {
                    write_80_bits(buffer, rand1);
                }
                delimiters::write_obit(buffer, 0);
            }
            DAuthentication::Result {
                r1,
                mutual_authentication,
                res2,
            } => {
                if *mutual_authentication && res2.is_none() {
                    return Err(PduParseErr::Inconsistency {
                        field: "res2",
                        reason: "missing while mutual_authentication=true",
                    });
                }
                if !*mutual_authentication && res2.is_some() {
                    return Err(PduParseErr::Inconsistency {
                        field: "res2",
                        reason: "present while mutual_authentication=false",
                    });
                }

                buffer.write_bits(AuthenticationSubType::Result.into_raw(), 2);
                buffer.write_bits(*r1 as u64, 1);
                buffer.write_bits(*mutual_authentication as u64, 1);
                if let Some(res2) = res2 {
                    buffer.write_bits(*res2 as u64, 32);
                }
                delimiters::write_obit(buffer, 0);
            }
        }

        Ok(())
    }
}

impl fmt::Display for DAuthentication {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "DAuthentication::{:?}", self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_d_auth_demand() {
        let pdu = DAuthentication::Demand {
            rand1: [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA],
            rs: [0x55, 0xAA, 0x10, 0x20, 0x30, 0x40, 0x42, 0x24, 0x18, 0x81],
        };

        let mut buf = BitBuffer::new_autoexpand(128);
        pdu.to_bitbuf(&mut buf).unwrap();
        buf.seek(0);

        let parsed = DAuthentication::from_bitbuf(&mut buf).unwrap();
        assert_eq!(parsed, pdu);
    }
}
