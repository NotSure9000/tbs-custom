use core::fmt;

use tetra_core::expect_pdu_type;
use tetra_core::typed_pdu_fields::delimiters;
use tetra_core::{BitBuffer, pdu_parse_error::PduParseErr};

use crate::mm::enums::mm_pdu_type_ul::MmPduTypeUl;

const OTAR_SUBTYPE_CCK_DEMAND: u8 = 0;
const OTAR_SUBTYPE_CCK_RESULT: u8 = 1;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum UOtar {
    CckDemand {
        location_area: u16,
    },
    CckResult {
        provision_result: u8,
        future_key_flag: bool,
        provision_result_future: Option<u8>,
    },
    Unsupported {
        otar_sub_type: u8,
    },
}

impl UOtar {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let pdu_type = buffer.read_field(4, "pdu_type")?;
        expect_pdu_type!(pdu_type, MmPduTypeUl::UOtar)?;

        let sub_type = buffer.read_field(4, "otar_sub_type")? as u8;

        let pdu = match sub_type {
            OTAR_SUBTYPE_CCK_DEMAND => {
                let location_area = buffer.read_field(14, "location_area")? as u16;
                UOtar::CckDemand { location_area }
            }
            OTAR_SUBTYPE_CCK_RESULT => {
                let provision_result = buffer.read_field(3, "provision_result")? as u8;
                let future_key_flag = buffer.read_field(1, "future_key_flag")? != 0;
                let provision_result_future = if future_key_flag {
                    Some(buffer.read_field(3, "provision_result_future")? as u8)
                } else {
                    None
                };

                UOtar::CckResult {
                    provision_result,
                    future_key_flag,
                    provision_result_future,
                }
            }
            _ => UOtar::Unsupported { otar_sub_type: sub_type },
        };

        if matches!(pdu, UOtar::Unsupported { .. }) {
            let trailing = buffer.get_len_remaining();
            if trailing > 0 {
                tracing::trace!("U-OTAR unsupported subtype {} with {} trailing bit(s), ignoring", sub_type, trailing);
                buffer.seek_rel(trailing as isize);
            }
            return Ok(pdu);
        }

        if buffer.get_len_remaining() > 0 {
            let obit = delimiters::read_obit(buffer)?;
            if obit {
                let trailing = buffer.get_len_remaining();
                tracing::trace!("U-OTAR has optional extension with {} trailing bit(s), ignoring", trailing);
                buffer.seek_rel(trailing as isize);
            } else {
                let trailing = buffer.get_len_remaining();
                if trailing > 0 {
                    tracing::trace!("U-OTAR has {} trailing bit(s) after o-bit, ignoring", trailing);
                    buffer.seek_rel(trailing as isize);
                }
            }
        }

        Ok(pdu)
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        buffer.write_bits(MmPduTypeUl::UOtar.into_raw(), 4);

        match self {
            UOtar::CckDemand { location_area } => {
                buffer.write_bits(OTAR_SUBTYPE_CCK_DEMAND as u64, 4);
                buffer.write_bits(*location_area as u64, 14);
            }
            UOtar::CckResult {
                provision_result,
                future_key_flag,
                provision_result_future,
            } => {
                if *future_key_flag && provision_result_future.is_none() {
                    return Err(PduParseErr::Inconsistency {
                        field: "provision_result_future",
                        reason: "missing while future_key_flag=true",
                    });
                }
                if !*future_key_flag && provision_result_future.is_some() {
                    return Err(PduParseErr::Inconsistency {
                        field: "provision_result_future",
                        reason: "present while future_key_flag=false",
                    });
                }

                buffer.write_bits(OTAR_SUBTYPE_CCK_RESULT as u64, 4);
                buffer.write_bits(*provision_result as u64, 3);
                buffer.write_bits(*future_key_flag as u64, 1);
                if let Some(v) = provision_result_future {
                    buffer.write_bits(*v as u64, 3);
                }
            }
            UOtar::Unsupported { otar_sub_type } => {
                buffer.write_bits(*otar_sub_type as u64, 4);
            }
        }

        delimiters::write_obit(buffer, 0);
        Ok(())
    }
}

impl fmt::Display for UOtar {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "UOtar::{:?}", self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_u_otar_cck_result() {
        let pdu = UOtar::CckResult {
            provision_result: 0,
            future_key_flag: false,
            provision_result_future: None,
        };

        let mut buf = BitBuffer::new_autoexpand(64);
        pdu.to_bitbuf(&mut buf).unwrap();
        buf.seek(0);

        let parsed = UOtar::from_bitbuf(&mut buf).unwrap();
        assert_eq!(parsed, pdu);
    }
}
