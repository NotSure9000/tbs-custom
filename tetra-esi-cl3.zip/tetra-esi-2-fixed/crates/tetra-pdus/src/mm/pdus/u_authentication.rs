use core::fmt;

use tetra_core::expect_pdu_type;
use tetra_core::typed_pdu_fields::delimiters;
use tetra_core::{BitBuffer, pdu_parse_error::PduParseErr};

use crate::mm::enums::authentication_sub_type::AuthenticationSubType;
use crate::mm::enums::mm_pdu_type_ul::MmPduTypeUl;

fn read_80_bits(buffer: &mut BitBuffer, field: &'static str) -> Result<[u8; 10], PduParseErr> {
    let mut out = [0u8; 10];
    for b in out.iter_mut() {
        *b = buffer.read_field(8, field)? as u8;
    }
    Ok(out)
}

fn write_80_bits(buffer: &mut BitBuffer, bytes: &[u8; 10]) {
    for b in bytes {
        buffer.write_bits(*b as u64, 8);
    }
}

/// Representation of the U-AUTHENTICATION PDU family (ETSI EN 300 392-7, A.1.5..A.1.8).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum UAuthentication {
    Demand {
        rand2: [u8; 10],
    },
    Reject {
        reject_reason: u8,
    },
    Response {
        res1: u32,
        mutual_authentication: bool,
        rand2: Option<[u8; 10]>,
    },
    Result {
        r2: bool,
        mutual_authentication: bool,
        res1: Option<u32>,
    },
}

impl UAuthentication {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let pdu_type = buffer.read_field(4, "pdu_type")?;
        expect_pdu_type!(pdu_type, MmPduTypeUl::UAuthentication)?;

        let sub_type_raw = buffer.read_field(2, "authentication_sub_type")?;
        let sub_type = AuthenticationSubType::try_from(sub_type_raw).map_err(|_| PduParseErr::InvalidValue {
            field: "authentication_sub_type",
            value: sub_type_raw,
        })?;

        let pdu = match sub_type {
            AuthenticationSubType::Demand => {
                let rand2 = read_80_bits(buffer, "rand2")?;
                UAuthentication::Demand { rand2 }
            }
            AuthenticationSubType::Reject => {
                let reject_reason = buffer.read_field(3, "authentication_reject_reason")? as u8;
                UAuthentication::Reject { reject_reason }
            }
            AuthenticationSubType::Response => {
                let res1 = buffer.read_field(32, "res1")? as u32;
                let mutual_authentication = buffer.read_field(1, "mutual_authentication")? != 0;
                let rand2 = if mutual_authentication {
                    Some(read_80_bits(buffer, "rand2")?)
                } else {
                    None
                };
                UAuthentication::Response {
                    res1,
                    mutual_authentication,
                    rand2,
                }
            }
            AuthenticationSubType::Result => {
                let r2 = buffer.read_field(1, "r2")? != 0;
                let mutual_authentication = buffer.read_field(1, "mutual_authentication")? != 0;
                let res1 = if mutual_authentication {
                    Some(buffer.read_field(32, "res1")? as u32)
                } else {
                    None
                };
                UAuthentication::Result {
                    r2,
                    mutual_authentication,
                    res1,
                }
            }
        };

        // Compatibility: earlier implementations omitted the trailing o-bit.
        // If there are bits remaining, consume o-bit and any optional trailing data.
        if buffer.get_len_remaining() > 0 {
            let obit = delimiters::read_obit(buffer)?;
            if obit {
                let trailing = buffer.get_len_remaining();
                tracing::trace!(
                    "U-AUTHENTICATION has optional extension with {} trailing bit(s), ignoring",
                    trailing
                );
                buffer.seek_rel(trailing as isize);
            } else {
                let trailing = buffer.get_len_remaining();
                if trailing > 0 {
                    tracing::trace!(
                        "U-AUTHENTICATION has {} trailing bit(s) after o-bit, ignoring",
                        trailing
                    );
                    buffer.seek_rel(trailing as isize);
                }
            }
        }

        Ok(pdu)
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        buffer.write_bits(MmPduTypeUl::UAuthentication.into_raw(), 4);

        match self {
            UAuthentication::Demand { rand2 } => {
                buffer.write_bits(AuthenticationSubType::Demand.into_raw(), 2);
                write_80_bits(buffer, rand2);
                delimiters::write_obit(buffer, 0);
            }
            UAuthentication::Reject { reject_reason } => {
                buffer.write_bits(AuthenticationSubType::Reject.into_raw(), 2);
                buffer.write_bits(*reject_reason as u64, 3);
                delimiters::write_obit(buffer, 0);
            }
            UAuthentication::Response {
                res1,
                mutual_authentication,
                rand2,
            } => {
                if *mutual_authentication && rand2.is_none() {
                    return Err(PduParseErr::Inconsistency {
                        field: "rand2",
                        reason: "missing while mutual_authentication=true",
                    });
                }
                if !*mutual_authentication && rand2.is_some() {
                    return Err(PduParseErr::Inconsistency {
                        field: "rand2",
                        reason: "present while mutual_authentication=false",
                    });
                }

                buffer.write_bits(AuthenticationSubType::Response.into_raw(), 2);
                buffer.write_bits(*res1 as u64, 32);
                buffer.write_bits(*mutual_authentication as u64, 1);
                if let Some(rand2) = rand2 {
                    write_80_bits(buffer, rand2);
                }
                delimiters::write_obit(buffer, 0);
            }
            UAuthentication::Result {
                r2,
                mutual_authentication,
                res1,
            } => {
                if *mutual_authentication && res1.is_none() {
                    return Err(PduParseErr::Inconsistency {
                        field: "res1",
                        reason: "missing while mutual_authentication=true",
                    });
                }
                if !*mutual_authentication && res1.is_some() {
                    return Err(PduParseErr::Inconsistency {
                        field: "res1",
                        reason: "present while mutual_authentication=false",
                    });
                }

                buffer.write_bits(AuthenticationSubType::Result.into_raw(), 2);
                buffer.write_bits(*r2 as u64, 1);
                buffer.write_bits(*mutual_authentication as u64, 1);
                if let Some(res1) = res1 {
                    buffer.write_bits(*res1 as u64, 32);
                }
                delimiters::write_obit(buffer, 0);
            }
        }

        Ok(())
    }
}

impl fmt::Display for UAuthentication {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "UAuthentication::{:?}", self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_u_auth_response_non_mutual() {
        let pdu = UAuthentication::Response {
            res1: 0xDEADBEEF,
            mutual_authentication: false,
            rand2: None,
        };

        let mut buf = BitBuffer::new_autoexpand(64);
        pdu.to_bitbuf(&mut buf).unwrap();
        buf.seek(0);

        let parsed = UAuthentication::from_bitbuf(&mut buf).unwrap();
        assert_eq!(parsed, pdu);
    }
}
