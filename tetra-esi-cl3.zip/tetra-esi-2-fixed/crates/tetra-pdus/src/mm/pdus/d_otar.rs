use core::fmt;

use tetra_core::expect_pdu_type;
use tetra_core::typed_pdu_fields::delimiters;
use tetra_core::{BitBuffer, pdu_parse_error::PduParseErr};

use crate::mm::enums::mm_pdu_type_dl::MmPduTypeDl;

const OTAR_SUBTYPE_CCK_PROVIDE: u8 = 0;

fn write_120_bits(buffer: &mut BitBuffer, bytes: &[u8; 15]) {
    for b in bytes {
        buffer.write_bits(*b as u64, 8);
    }
}

fn read_120_bits(buffer: &mut BitBuffer, field: &'static str) -> Result<[u8; 15], PduParseErr> {
    let mut out = [0u8; 15];
    for b in out.iter_mut() {
        *b = buffer.read_field(8, field)? as u8;
    }
    Ok(out)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DOtarCckProvide {
    pub cck_provision_flag: bool,
    pub cck_id: Option<u16>,
    pub key_type_flag: Option<bool>,
    pub scck: Option<[u8; 15]>,
    pub cck_location_area_type: Option<u8>,
    pub future_key_flag: Option<bool>,
    pub future_scck: Option<[u8; 15]>,
}

impl DOtarCckProvide {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let pdu_type = buffer.read_field(4, "pdu_type")?;
        expect_pdu_type!(pdu_type, MmPduTypeDl::DOtar)?;

        let sub_type = buffer.read_field(4, "otar_sub_type")? as u8;
        if sub_type != OTAR_SUBTYPE_CCK_PROVIDE {
            return Err(PduParseErr::InvalidValue {
                field: "otar_sub_type",
                value: sub_type as u64,
            });
        }

        let cck_provision_flag = buffer.read_field(1, "cck_provision_flag")? != 0;

        let mut pdu = DOtarCckProvide {
            cck_provision_flag,
            cck_id: None,
            key_type_flag: None,
            scck: None,
            cck_location_area_type: None,
            future_key_flag: None,
            future_scck: None,
        };

        if cck_provision_flag {
            pdu.cck_id = Some(buffer.read_field(16, "cck_id")? as u16);
            pdu.key_type_flag = Some(buffer.read_field(1, "key_type_flag")? != 0);
            pdu.scck = Some(read_120_bits(buffer, "scck")?);

            let la_type = buffer.read_field(2, "cck_location_area_type")? as u8;
            pdu.cck_location_area_type = Some(la_type);
            if la_type != 0 {
                return Err(PduParseErr::NotImplemented {
                    field: Some("cck_location_area_type != 0"),
                });
            }

            let future_key_flag = buffer.read_field(1, "future_key_flag")? != 0;
            pdu.future_key_flag = Some(future_key_flag);
            if future_key_flag {
                pdu.future_scck = Some(read_120_bits(buffer, "future_scck")?);
            }
        }

        if buffer.get_len_remaining() > 0 {
            let obit = delimiters::read_obit(buffer)?;
            if obit {
                let trailing = buffer.get_len_remaining();
                tracing::trace!("D-OTAR has optional extension with {} trailing bit(s), ignoring", trailing);
                buffer.seek_rel(trailing as isize);
            } else {
                let trailing = buffer.get_len_remaining();
                if trailing > 0 {
                    tracing::trace!("D-OTAR has {} trailing bit(s) after o-bit, ignoring", trailing);
                    buffer.seek_rel(trailing as isize);
                }
            }
        }

        Ok(pdu)
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        buffer.write_bits(MmPduTypeDl::DOtar.into_raw(), 4);
        buffer.write_bits(OTAR_SUBTYPE_CCK_PROVIDE as u64, 4);
        buffer.write_bits(self.cck_provision_flag as u64, 1);

        if self.cck_provision_flag {
            let cck_id = self.cck_id.ok_or(PduParseErr::Inconsistency {
                field: "cck_id",
                reason: "missing while cck_provision_flag=true",
            })?;
            let key_type_flag = self.key_type_flag.ok_or(PduParseErr::Inconsistency {
                field: "key_type_flag",
                reason: "missing while cck_provision_flag=true",
            })?;
            let scck = self.scck.ok_or(PduParseErr::Inconsistency {
                field: "scck",
                reason: "missing while cck_provision_flag=true",
            })?;

            let cck_location_area_type = self.cck_location_area_type.unwrap_or(0);
            if cck_location_area_type != 0 {
                return Err(PduParseErr::NotImplemented {
                    field: Some("cck_location_area_type != 0"),
                });
            }

            let future_key_flag = self.future_key_flag.unwrap_or(false);
            if future_key_flag && self.future_scck.is_none() {
                return Err(PduParseErr::Inconsistency {
                    field: "future_scck",
                    reason: "missing while future_key_flag=true",
                });
            }
            if !future_key_flag && self.future_scck.is_some() {
                return Err(PduParseErr::Inconsistency {
                    field: "future_scck",
                    reason: "present while future_key_flag=false",
                });
            }

            buffer.write_bits(cck_id as u64, 16);
            buffer.write_bits(key_type_flag as u64, 1);
            write_120_bits(buffer, &scck);
            buffer.write_bits(cck_location_area_type as u64, 2);
            buffer.write_bits(future_key_flag as u64, 1);
            if let Some(future_scck) = self.future_scck {
                write_120_bits(buffer, &future_scck);
            }
        }

        delimiters::write_obit(buffer, 0);
        Ok(())
    }
}

impl fmt::Display for DOtarCckProvide {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "DOtarCckProvide::{:?}", self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_d_otar_cck_provide_minimal() {
        let pdu = DOtarCckProvide {
            cck_provision_flag: true,
            cck_id: Some(0x1234),
            key_type_flag: Some(false),
            scck: Some([
                0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E,
            ]),
            cck_location_area_type: Some(0),
            future_key_flag: Some(false),
            future_scck: None,
        };

        let mut buf = BitBuffer::new_autoexpand(192);
        pdu.to_bitbuf(&mut buf).unwrap();
        buf.seek(0);

        let parsed = DOtarCckProvide::from_bitbuf(&mut buf).unwrap();
        assert_eq!(parsed, pdu);
    }
}
