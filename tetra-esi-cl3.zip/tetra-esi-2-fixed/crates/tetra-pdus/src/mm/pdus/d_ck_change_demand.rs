use core::fmt;

use tetra_core::expect_pdu_type;
use tetra_core::{BitBuffer, pdu_parse_error::PduParseErr};

use crate::mm::enums::mm_pdu_type_dl::MmPduTypeDl;

/// 16.9.x D-CK CHANGE DEMAND (subset implementation: SCK/TMO).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DCkChangeDemand {
    pub acknowledgement_flag: bool,
    pub change_of_security_class: u8,
    pub key_change_type: u8,
    pub sck_use: Option<bool>,
    pub sck_data: Vec<SckData>,
    pub time_type: u8,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SckData {
    pub sck_number: u8,
    pub sck_version: u16,
}

impl DCkChangeDemand {
    pub fn from_bitbuf(buffer: &mut BitBuffer) -> Result<Self, PduParseErr> {
        let pdu_type = buffer.read_field(4, "pdu_type")?;
        expect_pdu_type!(pdu_type, MmPduTypeDl::DCkChangeDemand)?;

        let acknowledgement_flag = buffer.read_field(1, "acknowledgement_flag")? != 0;
        let change_of_security_class = buffer.read_field(2, "change_of_security_class")? as u8;
        let key_change_type = buffer.read_field(3, "key_change_type")? as u8;

        if key_change_type != 0 {
            return Err(PduParseErr::NotImplemented {
                field: Some("D-CK CHANGE DEMAND key_change_type != SCK"),
            });
        }

        let sck_use = buffer.read_field(1, "sck_use")? != 0;
        let num_scks = buffer.read_field(4, "number_of_scks_changed")? as usize;
        if num_scks == 0 {
            return Err(PduParseErr::NotImplemented {
                field: Some("D-CK CHANGE DEMAND SCK subset mode"),
            });
        }

        let mut sck_data = Vec::with_capacity(num_scks);
        for _ in 0..num_scks {
            let sck_number = buffer.read_field(5, "sck_number")? as u8;
            let sck_version = buffer.read_field(16, "sck_version")? as u16;
            sck_data.push(SckData {
                sck_number,
                sck_version,
            });
        }

        let time_type = buffer.read_field(2, "time_type")? as u8;
        match time_type {
            2 | 3 => {}
            0 | 1 => {
                return Err(PduParseErr::NotImplemented {
                    field: Some("D-CK CHANGE DEMAND time_type absolute/network"),
                });
            }
            _ => {
                return Err(PduParseErr::InvalidValue {
                    field: "time_type",
                    value: time_type as u64,
                });
            }
        }

        let trailing = buffer.get_len_remaining();
        if trailing > 0 {
            tracing::trace!("D-CK CHANGE DEMAND has {} trailing bit(s), ignoring", trailing);
            buffer.seek_rel(trailing as isize);
        }

        Ok(DCkChangeDemand {
            acknowledgement_flag,
            change_of_security_class,
            key_change_type,
            sck_use: Some(sck_use),
            sck_data,
            time_type,
        })
    }

    pub fn to_bitbuf(&self, buffer: &mut BitBuffer) -> Result<(), PduParseErr> {
        buffer.write_bits(MmPduTypeDl::DCkChangeDemand.into_raw(), 4);
        buffer.write_bits(self.acknowledgement_flag as u64, 1);
        buffer.write_bits(self.change_of_security_class as u64, 2);
        buffer.write_bits(self.key_change_type as u64, 3);

        if self.key_change_type != 0 {
            return Err(PduParseErr::NotImplemented {
                field: Some("D-CK CHANGE DEMAND key_change_type != SCK"),
            });
        }

        let Some(sck_use) = self.sck_use else {
            return Err(PduParseErr::Inconsistency {
                field: "sck_use",
                reason: "missing while key_change_type=SCK",
            });
        };
        buffer.write_bits(sck_use as u64, 1);

        if self.sck_data.is_empty() || self.sck_data.len() > 15 {
            return Err(PduParseErr::Inconsistency {
                field: "sck_data",
                reason: "expected 1..15 SCK entries for implemented mode",
            });
        }

        buffer.write_bits(self.sck_data.len() as u64, 4);
        for entry in &self.sck_data {
            buffer.write_bits(entry.sck_number as u64, 5);
            buffer.write_bits(entry.sck_version as u64, 16);
        }

        match self.time_type {
            2 | 3 => buffer.write_bits(self.time_type as u64, 2),
            _ => {
                return Err(PduParseErr::NotImplemented {
                    field: Some("D-CK CHANGE DEMAND time_type absolute/network"),
                });
            }
        }

        Ok(())
    }
}

impl fmt::Display for DCkChangeDemand {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "DCkChangeDemand::{:?}", self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_d_ck_change_sck_single_entry() {
        let pdu = DCkChangeDemand {
            acknowledgement_flag: true,
            change_of_security_class: 2,
            key_change_type: 0,
            sck_use: Some(true),
            sck_data: vec![SckData {
                sck_number: 0,
                sck_version: 1,
            }],
            time_type: 2,
        };

        let mut buf = BitBuffer::new_autoexpand(64);
        pdu.to_bitbuf(&mut buf).unwrap();
        buf.seek(0);

        let parsed = DCkChangeDemand::from_bitbuf(&mut buf).unwrap();
        assert_eq!(parsed, pdu);
    }
}
