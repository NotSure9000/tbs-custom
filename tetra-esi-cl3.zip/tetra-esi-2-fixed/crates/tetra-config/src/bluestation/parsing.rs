use std::collections::HashMap;
use std::fs::File;
use std::io::{BufReader, Read};
use std::path::Path;

use serde::Deserialize;
use toml::Value;

use crate::bluestation::{CellInfoDto, NetInfoDto, cell_dto_to_cfg, net_dto_to_cfg};

use super::config::{SharedConfig, StackConfig, StackMode};
use super::sec_brew::{CfgBrewDto, apply_brew_patch};
use super::sec_ms_auth::{CfgMsAuthDto, apply_ms_auth_patch};
use super::{PhyIoDto, StackState, phy_dto_to_cfg};

/// Build `SharedConfig` from a TOML configuration file
pub fn from_toml_str(toml_str: &str) -> Result<SharedConfig, Box<dyn std::error::Error>> {
    let root: TomlConfigRoot = toml::from_str(toml_str)?;

    // Various sanity checks
    let expected_config_version = "0.5";
    if !root.config_version.eq(expected_config_version) {
        return Err(format!(
            "Unrecognized config_version: {}, expect {}",
            root.config_version, expected_config_version
        )
        .into());
    }
    if !root.extra.is_empty() {
        return Err(format!("Unrecognized top-level fields: {:?}", sorted_keys(&root.extra)).into());
    }

    if !root.phy_io.extra.is_empty() {
        return Err(format!("Unrecognized fields: phy_io::{:?}", sorted_keys(&root.phy_io.extra)).into());
    }
    if let Some(ref soapy) = root.phy_io.soapysdr {
        if !soapy.extra.is_empty() {
            return Err(format!("Unrecognized fields: phy_io.soapysdr::{:?}", sorted_keys(&soapy.extra)).into());
        }
    }
    if !root.net_info.extra.is_empty() {
        return Err(format!("Unrecognized fields in net_info: {:?}", sorted_keys(&root.net_info.extra)).into());
    }
    if !root.cell_info.extra.is_empty() {
        return Err(format!("Unrecognized fields in cell_info: {:?}", sorted_keys(&root.cell_info.extra)).into());
    }

    // Optional brew section
    if let Some(ref brew) = root.brew {
        if !brew.extra.is_empty() {
            return Err(format!("Unrecognized fields in brew config: {:?}", sorted_keys(&brew.extra)).into());
        }
    }

    // Optional ms_auth section
    if let Some(ref ms_auth) = root.ms_auth {
        if !ms_auth.extra.is_empty() {
            return Err(format!("Unrecognized fields in ms_auth config: {:?}", sorted_keys(&ms_auth.extra)).into());
        }
        for (index, sub) in ms_auth.subscribers.iter().enumerate() {
            if !sub.extra.is_empty() {
                return Err(
                    format!(
                        "Unrecognized fields in ms_auth.subscribers[{}]: {:?}",
                        index,
                        sorted_keys(&sub.extra)
                    )
                    .into(),
                );
            }
        }
        for (index, sck) in ms_auth.sck_material.iter().enumerate() {
            if !sck.extra.is_empty() {
                return Err(
                    format!(
                        "Unrecognized fields in ms_auth.sck_material[{}]: {:?}",
                        index,
                        sorted_keys(&sck.extra)
                    )
                    .into(),
                );
            }
        }
    }

    // Build config from required and optional values
    let mut cfg = StackConfig {
        stack_mode: root.stack_mode,
        debug_log: root.debug_log,
        phy_io: phy_dto_to_cfg(root.phy_io),
        net: net_dto_to_cfg(root.net_info),
        cell: cell_dto_to_cfg(root.cell_info),
        brew: None,
        ms_auth: None,
    };

    if let Some(brew) = root.brew {
        cfg.brew = Some(apply_brew_patch(brew));
    }

    if let Some(ms_auth) = root.ms_auth {
        match apply_ms_auth_patch(ms_auth) {
            Ok(ms_auth_cfg) => {
                cfg.ms_auth = Some(ms_auth_cfg);
            }
            Err(e) => {
                return Err(format!("invalid ms_auth config: {}", e).into());
            }
        }
    }

    // Mutable runtime state
    let state = StackState::default();

    Ok(SharedConfig::from_parts(cfg, state))
}

/// Build `SharedConfig` from any reader.
pub fn from_reader<R: Read>(reader: R) -> Result<SharedConfig, Box<dyn std::error::Error>> {
    let mut contents = String::new();
    let mut reader = BufReader::new(reader);
    reader.read_to_string(&mut contents)?;
    from_toml_str(&contents)
}

/// Build `SharedConfig` from a file path.
pub fn from_file<P: AsRef<Path>>(path: P) -> Result<SharedConfig, Box<dyn std::error::Error>> {
    let f = File::open(path)?;
    let r = BufReader::new(f);
    let cfg = from_reader(r)?;
    Ok(cfg)
}

fn sorted_keys(map: &HashMap<String, Value>) -> Vec<&str> {
    let mut v: Vec<&str> = map.keys().map(|s| s.as_str()).collect();
    v.sort_unstable();
    v
}

/// ----------------------- DTOs for input shape -----------------------

#[derive(Deserialize)]
struct TomlConfigRoot {
    config_version: String,
    stack_mode: StackMode,
    debug_log: Option<String>,

    phy_io: PhyIoDto,
    net_info: NetInfoDto,
    cell_info: CellInfoDto,

    brew: Option<CfgBrewDto>,
    ms_auth: Option<CfgMsAuthDto>,

    #[serde(flatten)]
    extra: HashMap<String, Value>,
}
