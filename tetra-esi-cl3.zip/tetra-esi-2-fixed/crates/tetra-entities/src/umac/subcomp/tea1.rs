// Port of TEA1/TB5 primitives from
// https://github.com/MidnightBlueLabs/TETRA_crypto (Apache-2.0).

use tetra_core::{BitBuffer, Direction, TdmaTime};

const TEA1_LUT_A: [u16; 8] = [0xDA86, 0x85E9, 0x29B5, 0x2BC6, 0x8C6B, 0x974C, 0xC671, 0x93E2];
const TEA1_LUT_B: [u16; 8] = [0x85D6, 0x791A, 0xE985, 0xC671, 0x2B9C, 0xEC92, 0xC62B, 0x9C47];

const TEA1_SBOX: [u8; 256] = [
    0x9B, 0xF8, 0x3B, 0x72, 0x75, 0x62, 0x88, 0x22, 0xFF, 0xA6, 0x10, 0x4D, 0xA9, 0x97, 0xC3, 0x7B, 0x9F, 0x78, 0xF3,
    0xB6, 0xA0, 0xCC, 0x17, 0xAB, 0x4A, 0x41, 0x8D, 0x89, 0x25, 0x87, 0xD3, 0xE3, 0xCE, 0x47, 0x35, 0x2C, 0x6D, 0xFC,
    0xE7, 0x6A, 0xB8, 0xB7, 0xFA, 0x8B, 0xCD, 0x74, 0xEE, 0x11, 0x23, 0xDE, 0x39, 0x6C, 0x1E, 0x8E, 0xED, 0x30, 0x73,
    0xBE, 0xBB, 0x91, 0xCA, 0x69, 0x60, 0x49, 0x5F, 0xB9, 0xC0, 0x06, 0x34, 0x2A, 0x63, 0x4B, 0x90, 0x28, 0xAC, 0x50,
    0xE4, 0x6F, 0x36, 0xB0, 0xA4, 0xD2, 0xD4, 0x96, 0xD5, 0xC9, 0x66, 0x45, 0xC5, 0x55, 0xDD, 0xB2, 0xA1, 0xA8, 0xBF,
    0x37, 0x32, 0x2B, 0x3E, 0xB5, 0x5C, 0x54, 0x67, 0x92, 0x56, 0x4C, 0x20, 0x6B, 0x42, 0x9D, 0xA7, 0x58, 0x0E, 0x52,
    0x68, 0x95, 0x09, 0x7F, 0x59, 0x9C, 0x65, 0xB1, 0x64, 0x5E, 0x4F, 0xBA, 0x81, 0x1C, 0xC2, 0x0C, 0x02, 0xB4, 0x31,
    0x5B, 0xFD, 0x1D, 0x0A, 0xC8, 0x19, 0x8F, 0x83, 0x8A, 0xCF, 0x33, 0x9E, 0x3A, 0x80, 0xF2, 0xF9, 0x76, 0x26, 0x44,
    0xF1, 0xE2, 0xC4, 0xF5, 0xD6, 0x51, 0x46, 0x07, 0x14, 0x61, 0xF4, 0xC1, 0x24, 0x7A, 0x94, 0x27, 0x00, 0xFB, 0x04,
    0xDF, 0x1F, 0x93, 0x71, 0x53, 0xEA, 0xD8, 0xBD, 0x3D, 0xD0, 0x79, 0xE6, 0x7E, 0x4E, 0x9A, 0xD7, 0x98, 0x1B, 0x05,
    0xAE, 0x03, 0xC7, 0xBC, 0x86, 0xDB, 0x84, 0xE8, 0xD1, 0xF7, 0x16, 0x21, 0x6E, 0xE5, 0xCB, 0xA3, 0x1A, 0xEC, 0xA2,
    0x7D, 0x18, 0x85, 0x48, 0xDA, 0xAA, 0xF0, 0x08, 0xC6, 0x40, 0xAD, 0x57, 0x0D, 0x29, 0x82, 0x7C, 0xE9, 0x8C, 0xFE,
    0xDC, 0x0F, 0x2D, 0x3C, 0x2E, 0xF6, 0x15, 0x2F, 0xAF, 0xE1, 0xEB, 0x3F, 0x99, 0x43, 0x13, 0x0B, 0xE0, 0xA5, 0x12,
    0x77, 0x5D, 0xB3, 0x38, 0xD9, 0xEF, 0x5A, 0x01, 0x70,
];

fn tea1_expand_iv(short_iv: u32) -> u64 {
    let mut xorred = short_iv ^ 0x9672_4FA1;
    xorred = xorred.rotate_left(8);
    let iv = (u64::from(short_iv) << 32) | u64::from(xorred);
    iv.rotate_right(8)
}

fn tea1_state_word_to_newbyte(st: u16, lut: &[u16; 8]) -> u8 {
    let mut st0 = st as u8;
    let mut st1 = (st >> 8) as u8;
    let mut out = 0u8;

    for (i, tap_lut) in lut.iter().enumerate() {
        let dist = ((st0 >> 7) & 1) | ((st0 << 1) & 2) | ((st1 << 1) & 12);
        if (*tap_lut & (1u16 << dist)) != 0 {
            out |= 1 << i;
        }
        st0 = st0.rotate_right(1);
        st1 = st1.rotate_right(1);
    }

    out
}

fn tea1_reorder_state_byte(st_byte: u8) -> u8 {
    let mut out = 0u8;
    out |= (st_byte << 6) & 0x40;
    out |= (st_byte << 1) & 0x20;
    out |= (st_byte << 2) & 0x08;
    out |= (st_byte >> 3) & 0x14;
    out |= (st_byte >> 2) & 0x01;
    out |= (st_byte >> 5) & 0x02;
    out |= (st_byte << 4) & 0x80;
    out
}

fn tea1_init_key_register(key: &[u8; 10]) -> u32 {
    let mut result = 0u32;
    for b in key {
        let idx = (((result >> 24) ^ result ^ u32::from(*b)) & 0xFF) as usize;
        result = (result << 8) | u32::from(TEA1_SBOX[idx]);
    }
    result
}

fn tea1_inner(mut iv_reg: u64, mut key_reg: u32, out: &mut [u8]) {
    let mut skip_rounds = 54;

    for out_b in out.iter_mut() {
        for _ in 0..skip_rounds {
            let sbox_out = TEA1_SBOX[((key_reg >> 24) ^ key_reg) as usize & 0xFF];
            key_reg = (key_reg << 8) | u32::from(sbox_out);

            let deriv_12 = tea1_state_word_to_newbyte(((iv_reg >> 8) & 0xFFFF) as u16, &TEA1_LUT_A);
            let deriv_56 = tea1_state_word_to_newbyte(((iv_reg >> 40) & 0xFFFF) as u16, &TEA1_LUT_B);
            let reorder_4 = tea1_reorder_state_byte(((iv_reg >> 32) & 0xFF) as u8);

            let new_byte = deriv_56 ^ ((iv_reg >> 56) as u8) ^ reorder_4 ^ sbox_out;
            iv_reg = ((iv_reg << 8) ^ (u64::from(deriv_12) << 32)) | u64::from(new_byte);
        }

        *out_b = (iv_reg >> 56) as u8;
        skip_rounds = 19;
    }
}

pub fn tea1(frame_numbers: u32, key: &[u8; 10], out: &mut [u8]) {
    let iv = tea1_expand_iv(frame_numbers);
    let key_reg = tea1_init_key_register(key);
    tea1_inner(iv, key_reg, out);
}

pub fn build_iv(time: TdmaTime, direction: Direction) -> u32 {
    let dir_bit = if direction == Direction::Ul { 1u32 } else { 0u32 };
    (u32::from(time.t.saturating_sub(1)))
        | (u32::from(time.f) << 2)
        | (u32::from(time.m) << 7)
        | ((u32::from(time.h) & 0x7FFF) << 13)
        | (dir_bit << 28)
}

pub fn derive_eck_from_ck(ck: &[u8; 10], carrier_number: u16, location_area: u16, colour_code: u8) -> [u8; 10] {
    let cn = u32::from(carrier_number & 0x0FFF);
    let la = u32::from(location_area & 0x3FFF);
    let cc = u32::from(colour_code & 0x3F);

    let ck0 = u16::from_be_bytes([ck[0], ck[1]]) as u32;
    let ck1 = u32::from_be_bytes([ck[2], ck[3], ck[4], ck[5]]);
    let ck2 = u32::from_be_bytes([ck[6], ck[7], ck[8], ck[9]]);

    let mask0 = (la << 2) | (cn >> 10);
    let mask1 = (cn << 22) | (cc << 16) | (cn << 4) | (cc >> 2);
    let mask2 = (cc << 30) | (cn << 18) | (cc << 12) | cn;

    let out0 = ck0 ^ mask0;
    let out1 = ck1 ^ mask1;
    let out2 = ck2 ^ mask2;

    let mut out = [0u8; 10];
    out[0..2].copy_from_slice(&(out0 as u16).to_be_bytes());
    out[2..6].copy_from_slice(&out1.to_be_bytes());
    out[6..10].copy_from_slice(&out2.to_be_bytes());
    out
}

pub fn apply_keystream_segment(
    bitbuf: &mut BitBuffer,
    num_bits: usize,
    time: TdmaTime,
    direction: Direction,
    eck: &[u8; 10],
    keystream_skip_bits: usize,
) -> bool {
    if num_bits == 0 {
        return true;
    }

    let total_bits = keystream_skip_bits.saturating_add(num_bits);
    let mut ks_bytes = vec![0u8; (total_bits + 7) / 8];
    let iv = build_iv(time, direction);
    tea1(iv, eck, &mut ks_bytes);

    let mut seg_bytes = vec![0u8; (num_bits + 7) / 8];
    for i in 0..num_bits {
        let src_idx = i + keystream_skip_bits;
        let src_bit = (ks_bytes[src_idx / 8] >> (7 - (src_idx % 8))) & 1;
        seg_bytes[i / 8] |= src_bit << (7 - (i % 8));
    }

    bitbuf.xor_bytearr(&seg_bytes, num_bits).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tea1_known_vectors() {
        let mut out = [0u8; 10];
        tea1(0x1111_1111, &[0, 0, 0, 0, 0, 0, 0, 0, 0, 0], &mut out);
        assert_eq!(out, [0xD3, 0x3F, 0xD8, 0xA6, 0x05, 0xA0, 0xA1, 0xBB, 0x90, 0x23]);

        tea1(
            0x0123_4567,
            &[0xA7, 0x98, 0x39, 0xE4, 0xBA, 0x88, 0xEE, 0x54, 0xA0, 0x29],
            &mut out,
        );
        assert_eq!(out, [0x1D, 0xEC, 0x9C, 0x7E, 0xC6, 0x22, 0x3D, 0x87, 0xC2, 0xCC]);
    }

    #[test]
    fn tb5_known_vector() {
        let ck = [0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0xAA, 0xBB];
        let eck = derive_eck_from_ck(&ck, 0x02BC, 0x1DCC, 0x05);
        assert_eq!(eck, [0x76, 0x13, 0xEA, 0x62, 0xA2, 0x6A, 0x87, 0x1F, 0xF8, 0x07]);
    }
}
